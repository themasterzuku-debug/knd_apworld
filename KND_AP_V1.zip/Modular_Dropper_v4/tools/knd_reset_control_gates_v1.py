from __future__ import annotations

import argparse
import time
import dolphin_memory_engine as dme

VERSION = "KND Reset Control Gates v1"

Y_FIRE_BLOCK_ADDR = 0x8076CE44
Y_ACTION_SUPPRESS_ADDR = 0x807319D8
LOCK_ON_BLOCK_ADDR = 0x8076CE7C
CE50_JUMP_BLOCK_ADDR = 0x8076CE50

ALLOW_VALUE = 0x00000001
CLEAR_VALUE = 0x00000000


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def read_u32(addr: int) -> int:
    return int.from_bytes(bytes(dme.read_bytes(addr, 4)), "big")


def hook() -> None:
    print("[DOLPHIN] Hooking...")
    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()
            _ = read_u32(Y_FIRE_BLOCK_ADDR)
            print("[DOLPHIN] Hooked.")
            return
        except Exception as e:
            print(f"[DOLPHIN] Waiting... ({e})")
            time.sleep(0.5)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--include-l", action="store_true")
    p.add_argument("--include-ce50", action="store_true")
    p.add_argument("--hold", type=float, default=0.0)
    p.add_argument("--poll", type=float, default=0.01)
    args = p.parse_args()

    print("=" * 80)
    print(VERSION)
    print("=" * 80)
    print(f"[RESET] 0x{Y_FIRE_BLOCK_ADDR:08X} = {ALLOW_VALUE:08X}")
    print(f"[RESET] 0x{Y_ACTION_SUPPRESS_ADDR:08X} = {ALLOW_VALUE:08X}")
    if args.include_l:
        print(f"[RESET] 0x{LOCK_ON_BLOCK_ADDR:08X} = {ALLOW_VALUE:08X}")
    if args.include_ce50:
        print(f"[RESET] 0x{CE50_JUMP_BLOCK_ADDR:08X} = {CLEAR_VALUE:08X}")

    hook()

    end = time.time() + args.hold if args.hold > 0 else time.time()
    first = True
    while first or time.time() < end:
        first = False
        write_u32(Y_FIRE_BLOCK_ADDR, ALLOW_VALUE)
        write_u32(Y_ACTION_SUPPRESS_ADDR, ALLOW_VALUE)
        if args.include_l:
            write_u32(LOCK_ON_BLOCK_ADDR, ALLOW_VALUE)
        if args.include_ce50:
            write_u32(CE50_JUMP_BLOCK_ADDR, CLEAR_VALUE)
        time.sleep(args.poll)

    print("[DONE] Control gates reset.")
    print(f"CE44 now: 0x{read_u32(Y_FIRE_BLOCK_ADDR):08X}")
    print(f"319D8 now: 0x{read_u32(Y_ACTION_SUPPRESS_ADDR):08X}")


if __name__ == "__main__":
    main()
