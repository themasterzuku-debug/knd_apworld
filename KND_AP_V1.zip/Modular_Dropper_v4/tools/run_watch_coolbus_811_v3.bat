@echo off
cd /d "%~dp0"
python knd_coolbus_811_v3.py --mode watch
pause
