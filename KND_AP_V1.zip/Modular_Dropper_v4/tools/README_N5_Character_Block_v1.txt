KND N5 Character Block v1

Separate N5-only character block.

Includes:
- N5 Double Jump block through CE50.
- N5 Wall Jump block through CE50 wall-contact timing.
- N5 L / Lock-On block.

No Y/weapon logic is in this file.
N5 has no weapon in Stage 3 or Stage 9.

Addresses:
- Stage 3 / Boogification airborne candidates observed: 0x81309194 (current latest), 0x813095E4 (previous)
- Stage 9 / Ship Shape airborne:    0x8123E5D4
- CE50 jump block:                  0x8076CE50 = 00000001
- Wall contact:                     0x80417C5C
- L / Lock-On block:                0x8076CE7C = 00000000

Rules:
- Missing DoubleJump -> block open-air double jump.
- Missing WallJump -> block wall jump.
- Missing either -> block L.
- Has both -> no movement block and L allowed.

Useful BATs:
- run_n5_stage3_none_v1.bat
- run_n5_stage3_wall_only_v1.bat
- run_n5_stage3_double_only_v1.bat
- run_n5_stage3_both_v1.bat
- run_n5_stage9_none_v1.bat
- run_n5_stage9_wall_only_v1.bat
- run_n5_stage9_double_only_v1.bat
- run_n5_stage9_both_v1.bat
