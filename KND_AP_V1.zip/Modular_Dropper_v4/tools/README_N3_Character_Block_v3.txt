KND N3 Character Block v3

This fixes the Stage 6 starting-tree false-airborne issue seen in v2.

Problem:
- v2 would write movement blocks immediately if the airborne tracker already read 1.
- On Stage 6's starting tree/platform, 0x81382374 can apparently look airborne before a clean grounded baseline has been observed.
- Result: 0-move could block the first jump entirely, and 1-move could block A too early.

Fix:
- v3 waits until the airborne tracker is 0 for 0.150 seconds.
- Only after that clean grounded baseline does movement blocking arm.
- Then the airborne session starts on the next 0 -> 1 transition.
- This keeps the Stage 10 v5 timing but prevents false-start blocking.

Rules:
Stage 6 / Hamsterama:
- Airborne/session candidate pair A: 0x81382374 -> glide block 0x8138237C = 00000001
- Airborne/session candidate pair B: 0x81381F24 -> glide block 0x81381F2C = 00000001
- The Easy Client reads both candidate air trackers and latches the usable 0/1 pair for the current session.
- These are movement/glide addresses only. They must not be mixed with N3 weapon/Y behavior.
- Weapon mirror:    0x81512894

Stage 10 / Brush Off:
- Airborne/session: 0x8120431C
- Glide block:      0x8121BCC4 = 00000000
- Weapon mirror:    0x81512904

Shared:
- A gate:           0x8077AE48 = 00000001
- Y suppress:       0x807319D8 = 00000000
- L suppress:       0x8076CE7C = 00000000

Testing:
1. Start Stage 6 on the tree.
2. Run run_n3_stage6_0move_no_weapon_v3.bat.
3. Wait until it prints:
   [ARM] Clean grounded baseline seen. Movement blocker armed.
4. Then jump.
Expected:
- First jump should not be eaten.
- 0-move should allow launch but block extra air movement.
- 1-move should allow one airborne A/double jump and block glide.

If you want to isolate movement from Y/L:
- run_n3_stage6_1move_no_weapon_NO_YL_v3.bat

There is also a --no-ground-arm option to reproduce the old immediate v2 behavior, but it is not recommended.


RC6.12 Stage 6 note:
- 0x81381F24 was added as an alternate Stage 6 airborne tracker.
- 0x81381F2C was added as its paired Stage 6 glide-block address.
- The Easy Client uses a read-only air-pair latch for Stage 6; it writes only the selected paired glide block address when glide should be blocked.
- The old pair 0x81382374 / 0x8138237C is still kept as candidate A.

RC6.13 note - observed N3 movement pairs:
- Stage 6 / Hamsterama: 0x81382374 -> 0x8138237C and 0x81381F24 -> 0x81381F2C.
- Stage 10 / Brush Off: 0x8121BCC4 -> 0x8121BCCC.
- The left side is the air/read tracker. The right side is the paired glide/block write target.
- Resolver should prefer a candidate pair that shows a real 0->1 airborne transition.
- These are movement-only and should not be mixed with weapon/Y behavior.
