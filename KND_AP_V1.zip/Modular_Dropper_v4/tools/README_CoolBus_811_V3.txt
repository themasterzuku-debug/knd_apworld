KND Cool Bus v3 - corrected 0x811xxxxx addresses

This is the Cool Bus piece separated from the old combined Cool Bus / Weapon Flag Pusher.

Corrected Cool Bus addresses:
- CB1: 0x81100AEC, max 4
- CB2: 0x8118676C, max 5
- CB3: 0x8117A62C, max 5

Gecko examples from testing:
- CB1: 05100AEC 00000001
- CB2: 0518676C 00000002
- CB3: 0517A62C 00000005

Important:
- This script writes U32 values, not byte values.
- That matches the Gecko-style 05xxxxxx 0000000N lines above.
- These appear to update/take effect when the player fills the meter and uses the X-button explosion/shield.

Main arguments:
- --cb1-count 0..4
- --cb2-count 0..5
- --cb3-count 0..5
- --mode counts|max_all|lock_all|watch
- --once

Examples:
python knd_coolbus_811_v3.py --cb1-count 4 --cb2-count 5 --cb3-count 5
python knd_coolbus_811_v3.py --mode max_all --once
python knd_coolbus_811_v3.py --mode watch
