@echo off
cd /d "%~dp0"
python knd_n5_character_block_v1.py --stage stage3 --n5-wall
pause
