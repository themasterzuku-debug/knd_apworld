KND Weapon / Stage Flag Pusher v2 - separate from Cool Bus

This is the flag-pusher piece separated from the old combined Cool Bus / Weapon Flag Pusher.
It does NOT include Cool Bus logic.

Main AP intended default:
- normal-weapons = unlock
- stage-unlocks = watch

That means:
- Normal non-Cool-Bus weapon-start flags are forced to 1.
- Stage/slot unlock flags are watched only and not changed.

Important:
- These are byte flags. This script writes single bytes.

Normal weapon start flags forced to 1 by default:
- Gmzka active for Level 2 start: 0x8076F4BF
- Smellmet:                     0x8076F5CF
- Splanker:                     0x8076F58F
- Frappe:                       0x8076F56F
- Scampp:                       0x8076F45F
- Thumper:                      0x8076F47F
- Bajooka:                      0x8076F49F
- Sluggah:                      0x8076F5AF

Stage unlock flags included for watching/testing:
- Stage 2 Unlock:  0x8076F54F
- Stage 3 Unlock:  0x8076F4AF
- Stage 4 Unlock:  0x8076F5BF
- Slot 5 Unlock:   0x8076F4EF
- Slot 6 Unlock:   0x8076F57F
- Slot 7 Unlock:   0x8076F55F
- Slot 8 Unlock:   0x8076F44F
- Slot 9 Unlock:   0x8076F50F
- Slot 10 Unlock:  0x8076F4DF
- Slot 11 Unlock:  0x8076F46F
- Slot 12 Unlock:  0x8076F48F
- Slot 13 Unlock:  0x8076F59F
- Slot 14 Unlock:  0x8076F52F
- Slot 15 Unlock:  0x8076F4CF

Useful commands:
python knd_weapon_flag_pusher_v2_separate.py
python knd_weapon_flag_pusher_v2_separate.py --normal-weapons watch --stage-unlocks watch
python knd_weapon_flag_pusher_v2_separate.py --normal-weapons lock --stage-unlocks watch --once
python knd_weapon_flag_pusher_v2_separate.py --stage-unlocks unlock_up_to --stage-unlock-up-to 5 --once
