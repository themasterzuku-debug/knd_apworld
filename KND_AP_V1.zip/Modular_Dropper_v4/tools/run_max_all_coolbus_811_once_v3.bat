@echo off
cd /d "%~dp0"
python knd_coolbus_811_v3.py --mode max_all --once
pause
