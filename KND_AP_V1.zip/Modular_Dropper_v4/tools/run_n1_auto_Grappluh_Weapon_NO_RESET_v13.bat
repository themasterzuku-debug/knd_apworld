@echo off
cd /d "%~dp0"
python knd_n1_grappluh_sabotage_v13.py --stage auto --grappluh --stage2-weapon --stage7-weapon --stage11-weapon --disable-owned-reset-once
pause
