@echo off
cd /d "%~dp0"
python knd_coolbus_811_v3.py --cb1-count 4 --cb2-count 5 --cb3-count 5
pause
