from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import dolphin_memory_engine as dme


VERSION = "KND N3 CHARACTER BLOCK v3 - GROUNDED ARMING FIX"

# ---------------------------------------------------------------------------
# WHY v3 EXISTS
# ---------------------------------------------------------------------------
#
# v2 could engage the Stage 6 movement block immediately if 0x81382374 already
# read as airborne/1 when the script started. On Stage 6's starting tree/platform,
# that can make 0-move block the first jump and make 1-move block A too early.
#
# v3 fixes that by refusing to do movement writes until it has seen a CLEAN
# grounded baseline first:
#
#   1. active stage detected
#   2. wait until airborne tracker is 0 for STABLE_GROUND_SECONDS
#   3. only then arm movement blocking
#   4. only start a session on a 0 -> 1 transition after that grounded baseline
#
# This keeps the Stage 10 v5 movement logic, but prevents false-start blocking
# on Stage 6.
#
# It still uses:
#   Stage 6:  air 0x81382374, glide 0x8138237C = 1
#   Stage 10: air 0x8120431C, glide 0x8121BCC4 = 0
#   AE48:     0x8077AE48 = 1 to block A
#
# Includes Y and L, with switches to disable them during testing.


# ---------------------------------------------------------------------------
# SHARED ADDRESSES
# ---------------------------------------------------------------------------

AE48_A_GATE_ADDR = 0x8077AE48
PLAYER_A_VALUE = 0x00000000
A_BLOCK_VALUE = 0x00000001

Y_ACTION_SUPPRESS_ADDR = 0x807319D8
Y_ACTION_SUPPRESS_VALUE = 0x00000000

LOCK_ON_BLOCK_ADDR = 0x8076CE7C
LOCK_ON_BLOCK_VALUE = 0x00000000

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000


# ---------------------------------------------------------------------------
# TIMING copied from Stage 10 v5, plus grounded arming
# ---------------------------------------------------------------------------

POLL_SECONDS = 0.001
STATUS_EVERY_SECONDS = 1.0

STABLE_GROUND_SECONDS = 0.150
LAUNCH_GRACE_SECONDS = 0.050

RELEASE_STABLE_SECONDS = 0.015
ALLOWED_TAP_PASS_SECONDS = 0.125
AIRBORNE_TAPS_ALLOWED = 1


@dataclass
class StageProfile:
    key: str
    display_name: str
    level_marker: str

    airborne_addr: int
    glide_addr: int
    glide_block_value: int

    weapon_name: str
    weapon_mirror_addr: int

    optional_watch_addr: Optional[int] = None
    optional_watch_name: str = ""


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u8(addr: int) -> int:
    return read_bytes(addr, 1)[0]


def read_u32(addr: int) -> int:
    return int.from_bytes(read_bytes(addr, 4), "big")


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def mirror_active(addr: int) -> Tuple[bool, int, int]:
    try:
        b = read_u8(addr)
    except Exception:
        b = 0

    try:
        w = read_u32(addr)
    except Exception:
        w = 0

    return (b == 1 or w == 1), b, w


def make_profiles(args: argparse.Namespace) -> Dict[str, StageProfile]:
    return {
        "stage6": StageProfile(
            key="stage6",
            display_name="Stage 6 / Hamsterama",
            level_marker="Ltreehs3",

            airborne_addr=int(args.stage6_air, 0),
            glide_addr=int(args.stage6_glide, 0),
            glide_block_value=int(args.stage6_glide_value, 0),

            weapon_name="Frappe_Unjammed",
            weapon_mirror_addr=int(args.stage6_weapon_mirror, 0),

            optional_watch_addr=int(args.stage6_watch, 0) if args.stage6_watch else None,
            optional_watch_name="Stage 6 effective-A/watch",
        ),
        "stage10": StageProfile(
            key="stage10",
            display_name="Stage 10 / Brush Off",
            level_marker="Lbkyrd3",

            airborne_addr=int(args.stage10_air, 0),
            glide_addr=int(args.stage10_glide, 0),
            glide_block_value=int(args.stage10_glide_value, 0),

            weapon_name="Thumper_Unjammed",
            weapon_mirror_addr=int(args.stage10_weapon_mirror, 0),

            optional_watch_addr=int(args.stage10_watch, 0) if args.stage10_watch else None,
            optional_watch_name="Stage 10 late-fall/watch",
        ),
    }


def hook_dolphin(profiles: Dict[str, StageProfile]) -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0

    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            _ = read_u32(AE48_A_GATE_ADDR)
            _ = read_u32(Y_ACTION_SUPPRESS_ADDR)
            _ = read_u32(LOCK_ON_BLOCK_ADDR)
            _ = read_bytes(LEVEL_TEXT_SCAN_START, 0x20)

            for p in profiles.values():
                _ = read_u32(p.airborne_addr)
                _ = read_u32(p.glide_addr)
                _ = read_u8(p.weapon_mirror_addr)
                _ = read_u32(p.weapon_mirror_addr)
                if p.optional_watch_addr is not None:
                    _ = read_u32(p.optional_watch_addr)

            print("[DOLPHIN] Hooked. KND memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def detect_stage(profiles: Dict[str, StageProfile], forced_stage: str) -> Optional[StageProfile]:
    if forced_stage != "auto":
        return profiles[forced_stage]

    try:
        raw = read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE)
    except Exception:
        return None

    text = raw.decode("latin-1", errors="ignore")
    for p in profiles.values():
        if p.level_marker in text:
            return p

    return None


def movement_mode(count: int) -> str:
    if count <= 0:
        return "single_jump_only"
    if count == 1:
        return "double_jump_no_glide_1tap"
    return "full_movement"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()

    p.add_argument("--stage", choices=["auto", "stage6", "stage10"], default="auto")
    p.add_argument(
        "--n3-movement",
        type=int,
        choices=[0, 1, 2],
        default=1,
        help="Move_N3_Progressive_Movement count. 0=single jump, 1=double/no glide, 2=full movement.",
    )
    p.add_argument(
        "--mode",
        choices=["ap_count", "watch_only", "single_jump_only", "double_jump_no_glide_1tap", "full_movement"],
        default="ap_count",
    )

    p.add_argument("--stage6-weapon", action="store_true")
    p.add_argument("--stage10-weapon", action="store_true")

    p.add_argument("--disable-y-block", action="store_true")
    p.add_argument("--disable-l-block", action="store_true")
    p.add_argument("--disable-movement-block", action="store_true")

    # Testing switch. Default is safe grounded arming.
    p.add_argument("--no-ground-arm", action="store_true", help="Use old immediate behavior. Not recommended.")

    p.add_argument("--stage6-air", default="0x81382374")
    p.add_argument("--stage6-glide", default="0x8138237C")
    p.add_argument("--stage6-glide-value", default="0x00000001")
    p.add_argument("--stage6-watch", default="0x8136A9CC")
    p.add_argument("--stage6-weapon-mirror", default="0x81512894")

    p.add_argument("--stage10-air", default="0x8120431C")
    p.add_argument("--stage10-glide", default="0x8121BCC4")
    p.add_argument("--stage10-glide-value", default="0x00000000")
    p.add_argument("--stage10-watch", default="0x8121BCCC")
    p.add_argument("--stage10-weapon-mirror", default="0x81512904")

    return p.parse_args()


def stage_weapon_owned(args: argparse.Namespace, stage_key: str) -> bool:
    if stage_key == "stage6":
        return bool(args.stage6_weapon)
    if stage_key == "stage10":
        return bool(args.stage10_weapon)
    return False


def main() -> None:
    args = parse_args()
    profiles = make_profiles(args)

    if args.mode == "ap_count":
        mode = movement_mode(args.n3_movement)
    else:
        mode = args.mode

    print("=" * 110)
    print(VERSION)
    print("=" * 110)
    print()
    print("[CONFIG]")
    print(f"  stage:                  {args.stage}")
    print(f"  n3 movement count:      {args.n3_movement}")
    print(f"  resolved movement mode: {mode}")
    print(f"  stage6 weapon owned:    {bool(args.stage6_weapon)}")
    print(f"  stage10 weapon owned:   {bool(args.stage10_weapon)}")
    print(f"  movement disabled:      {bool(args.disable_movement_block)}")
    print(f"  Y block disabled:       {bool(args.disable_y_block)}")
    print(f"  L block disabled:       {bool(args.disable_l_block)}")
    print(f"  grounded arming:        {not bool(args.no_ground_arm)}")
    print()
    print("[STAGE PROFILES]")
    for p in profiles.values():
        print(f"  {p.display_name}:")
        print(f"    marker:               {p.level_marker}")
        print(f"    airborne/session:     0x{p.airborne_addr:08X}")
        print(f"    glide block:          0x{p.glide_addr:08X} = {p.glide_block_value:08X}")
        print(f"    weapon mirror:        0x{p.weapon_mirror_addr:08X} ({p.weapon_name})")
        if p.optional_watch_addr is not None:
            print(f"    watch:                0x{p.optional_watch_addr:08X} ({p.optional_watch_name})")
    print()
    print("[GROUND ARMING]")
    print("  Movement writes wait until the airborne tracker has been 0 for")
    print(f"  {STABLE_GROUND_SECONDS:.3f}s, then only start on the next 0->1 airborne transition.")
    print("  This prevents Stage 6 starting-tree false-airborne from blocking the first jump.")
    print()
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin(profiles)

    last_stage_key: Optional[str] = None
    last_air: Optional[int] = None
    previous_air_for_transition: Optional[int] = None
    last_glide: Optional[int] = None
    last_ae48: Optional[int] = None
    last_watch: Optional[int] = None
    last_weapon_report = None
    last_l_value: Optional[int] = None

    grounded_since: Optional[float] = None
    movement_armed = False

    airborne_session_active = False
    airborne_started_at = 0.0

    airborne_taps_used = 0
    armed_for_new_airborne_tap = False
    release_seen_at: Optional[float] = None
    allowed_tap_pass_until = 0.0

    write_count_ae48 = 0
    write_count_glide = 0
    write_count_y = 0
    write_count_l = 0
    heartbeat_time = time.time()

    while True:
        try:
            now = time.time()
            stage_profile = detect_stage(profiles, args.stage)

            if stage_profile is None:
                if last_stage_key != "none":
                    print("[STAGE] No supported N3 stage detected. No writes.")
                    last_stage_key = "none"
                    last_air = None
                    previous_air_for_transition = None
                    last_glide = None
                    last_ae48 = None
                    last_watch = None
                    last_weapon_report = None
                    last_l_value = None
                    grounded_since = None
                    movement_armed = False
                    airborne_session_active = False
                    airborne_taps_used = 0
                    armed_for_new_airborne_tap = False
                    release_seen_at = None
                    allowed_tap_pass_until = 0.0
                time.sleep(0.050)
                continue

            if stage_profile.key != last_stage_key:
                print(f"[STAGE] Active profile: {stage_profile.display_name}")
                print(
                    f"        air=0x{stage_profile.airborne_addr:08X}, "
                    f"glide=0x{stage_profile.glide_addr:08X} value={stage_profile.glide_block_value:08X}, "
                    f"weapon=0x{stage_profile.weapon_mirror_addr:08X}"
                )
                last_stage_key = stage_profile.key
                last_air = None
                previous_air_for_transition = None
                last_glide = None
                last_ae48 = None
                last_watch = None
                last_weapon_report = None
                last_l_value = None
                grounded_since = None
                movement_armed = False
                airborne_session_active = False
                airborne_taps_used = 0
                armed_for_new_airborne_tap = False
                release_seen_at = None
                allowed_tap_pass_until = 0.0

            air_value = read_u32(stage_profile.airborne_addr)
            glide_value = read_u32(stage_profile.glide_addr)
            ae48_value = read_u32(AE48_A_GATE_ADDR)
            l_value = read_u32(LOCK_ON_BLOCK_ADDR)
            watch_value = (
                read_u32(stage_profile.optional_watch_addr)
                if stage_profile.optional_watch_addr is not None
                else None
            )

            weapon_active, weapon_u8, weapon_u32 = mirror_active(stage_profile.weapon_mirror_addr)
            weapon_owned = stage_weapon_owned(args, stage_profile.key)

            airborne = (air_value == 1)
            grounded = (air_value == 0)
            player_a = (ae48_value == PLAYER_A_VALUE)

            if air_value != last_air:
                state = "AIRBORNE" if airborne else "GROUNDED" if grounded else "UNKNOWN"
                print(f"[AIR]    0x{stage_profile.airborne_addr:08X} = {air_value:08X} ({state})")
                last_air = air_value

            if glide_value != last_glide:
                print(f"[GLIDE]  0x{stage_profile.glide_addr:08X} = {glide_value:08X}")
                last_glide = glide_value

            if ae48_value != last_ae48:
                tag = "PLAYER_A/0" if player_a else "BLOCK/1" if ae48_value == A_BLOCK_VALUE else "OTHER"
                print(f"[AE48]   0x{AE48_A_GATE_ADDR:08X} = {ae48_value:08X} ({tag})")
                last_ae48 = ae48_value

            if watch_value is not None and watch_value != last_watch:
                print(f"[WATCH]  0x{stage_profile.optional_watch_addr:08X} = {watch_value:08X}")
                last_watch = watch_value

            weapon_report = (weapon_active, weapon_u8, weapon_u32, weapon_owned)
            if weapon_report != last_weapon_report:
                print(
                    f"[WEAPON] 0x{stage_profile.weapon_mirror_addr:08X} "
                    f"active={weapon_active} u8={weapon_u8:02X} u32={weapon_u32:08X} owned={weapon_owned}"
                )
                last_weapon_report = weapon_report

            if l_value != last_l_value:
                print(f"[L]      0x{LOCK_ON_BLOCK_ADDR:08X} = {l_value:08X}")
                last_l_value = l_value

            # ---------------------------------------------------------------
            # Grounded arming fix.
            # ---------------------------------------------------------------
            if args.no_ground_arm:
                movement_armed = True
            else:
                if grounded:
                    if grounded_since is None:
                        grounded_since = now
                    elif not movement_armed and now - grounded_since >= STABLE_GROUND_SECONDS:
                        movement_armed = True
                        print("[ARM] Clean grounded baseline seen. Movement blocker armed.")
                else:
                    grounded_since = None

            # Start sessions only if armed, and preferably from a 0->1 transition.
            air_transition_0_to_1 = (previous_air_for_transition == 0 and air_value == 1)
            previous_air_for_transition = air_value

            if movement_armed and airborne and not airborne_session_active:
                if args.no_ground_arm or air_transition_0_to_1:
                    airborne_session_active = True
                    airborne_started_at = now
                    airborne_taps_used = 0
                    armed_for_new_airborne_tap = False
                    release_seen_at = None
                    allowed_tap_pass_until = 0.0
                    print("[SESSION] N3 airborne session started.")

            if grounded and airborne_session_active:
                airborne_session_active = False
                airborne_taps_used = 0
                armed_for_new_airborne_tap = False
                release_seen_at = None
                allowed_tap_pass_until = 0.0
                print("[SESSION] N3 landed. Session reset.")

            should_block_ae48 = False
            should_block_glide = False

            if not args.disable_movement_block and movement_armed:
                if mode == "single_jump_only":
                    # Only write while a real armed airborne session is active.
                    should_block_glide = airborne_session_active
                    if airborne_session_active and (now - airborne_started_at >= LAUNCH_GRACE_SECONDS):
                        should_block_ae48 = True

                elif mode == "double_jump_no_glide_1tap":
                    should_block_glide = airborne_session_active

                    if airborne_session_active:
                        if not armed_for_new_airborne_tap:
                            if not player_a:
                                if release_seen_at is None:
                                    release_seen_at = now
                                elif now - release_seen_at >= RELEASE_STABLE_SECONDS:
                                    armed_for_new_airborne_tap = True
                                    release_seen_at = None
                                    print("[ARM] Airborne A release stable; next A tap can count.")
                            else:
                                release_seen_at = None

                        if armed_for_new_airborne_tap and player_a:
                            airborne_taps_used += 1
                            armed_for_new_airborne_tap = False
                            release_seen_at = None

                            if airborne_taps_used <= AIRBORNE_TAPS_ALLOWED:
                                allowed_tap_pass_until = now + ALLOWED_TAP_PASS_SECONDS
                                print(
                                    f"[A TAP] Allowed airborne tap {airborne_taps_used}/"
                                    f"{AIRBORNE_TAPS_ALLOWED}; pass window {ALLOWED_TAP_PASS_SECONDS:.3f}s."
                                )
                            else:
                                print(
                                    f"[A TAP] BLOCKED extra airborne tap {airborne_taps_used}/"
                                    f"{AIRBORNE_TAPS_ALLOWED}."
                                )

                        in_allowed_pass = now < allowed_tap_pass_until

                        if not in_allowed_pass and airborne_taps_used >= AIRBORNE_TAPS_ALLOWED:
                            should_block_ae48 = True

            # watch_only and full_movement do not write movement.

            if should_block_glide:
                write_u32(stage_profile.glide_addr, stage_profile.glide_block_value)
                write_count_glide += 1

            if should_block_ae48:
                write_u32(AE48_A_GATE_ADDR, A_BLOCK_VALUE)
                write_count_ae48 += 1

            y_blocking = False
            if not args.disable_y_block and weapon_active and not weapon_owned:
                write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                write_count_y += 1
                y_blocking = True

            l_blocking = False
            if not args.disable_l_block and args.n3_movement < 2:
                write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
                write_count_l += 1
                l_blocking = True

            if now - heartbeat_time >= STATUS_EVERY_SECONDS:
                print(
                    f"[STATUS] stage={stage_profile.key} mode={mode} "
                    f"air={air_value} armed={movement_armed} session={airborne_session_active} "
                    f"glide={glide_value:08X} AE48={ae48_value:08X} "
                    f"taps={airborne_taps_used}/{AIRBORNE_TAPS_ALLOWED} "
                    f"weapon_active={weapon_active} weapon_owned={weapon_owned} "
                    f"y_blocking={y_blocking} l_blocking={l_blocking} "
                    f"writes_glide={write_count_glide} writes_ae48={write_count_ae48} "
                    f"writes_y={write_count_y} writes_l={write_count_l}"
                )
                heartbeat_time = now
                write_count_glide = 0
                write_count_ae48 = 0
                write_count_y = 0
                write_count_l = 0

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            print("\n[STOP] N3 character block stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            airborne_session_active = False
            armed_for_new_airborne_tap = False
            release_seen_at = None
            time.sleep(0.50)


if __name__ == "__main__":
    main()
