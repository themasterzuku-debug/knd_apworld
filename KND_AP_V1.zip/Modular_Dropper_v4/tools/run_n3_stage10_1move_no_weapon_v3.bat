@echo off
cd /d "%~dp0"
python knd_n3_character_block_v3.py --stage stage10 --n3-movement 1
pause
