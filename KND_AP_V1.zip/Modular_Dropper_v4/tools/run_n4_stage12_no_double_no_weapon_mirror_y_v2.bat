@echo off
cd /d "%~dp0"
python knd_n4_character_block_v2.py --stage stage12 --n4-y-strategy mirror
pause
