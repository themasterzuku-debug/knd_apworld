@echo off
cd /d "%~dp0"
python knd_n3_character_block_v3.py --stage stage6 --n3-movement 0
pause
