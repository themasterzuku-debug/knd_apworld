from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import dolphin_memory_engine as dme


VERSION = "KND N1 GRAPPLUH SABOTAGE v13 - OWNED RESET ONCE"

# ---------------------------------------------------------------------------
# N1 ONLY - GRAPPLUH-SPECIFIC BLOCKER
# ---------------------------------------------------------------------------
#
# Rule v12:
#   If Grappluh is NOT owned:
#       write 2 to the active stage's Grappluh sabotage/recover address.
#
#   If Grappluh IS owned:
#       write nothing to the Grappluh address.
#
# Reason:
#   Writing 2 appears to kick N1 out of the Grappluh animation immediately,
#   rather than letting him stay stuck.
#
# Result:
#   - B is not globally blocked.
#   - Switches/buttons/children should still be usable.
#   - Missing Grappluh should prevent/abort the Grappluh action.
#   - Owned Grappluh is left alone so the game can handle it normally.
#
# Known stage-specific addresses:
#   Stage 2 / Donutty:      0x811FD074
#   Stage 7 / Spankarific:  0x8128CF24
#   Stage 11 / Cavity Cave: 0x8122BB04
#
# N1 still has Y/weapon suppress using the weapon mirrors.
# N1 still has NO L suppress.
# No hard B block is used in this file.


GRAPPLUH_MISSING_VALUE = 0x00000002
GRAPPLUH_OWNED_RESET_VALUE = 0x00000000

Y_ACTION_SUPPRESS_ADDR = 0x807319D8
Y_ACTION_SUPPRESS_VALUE = 0x00000000

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000

MENU_MARKER_ADDR = 0x80983040
MENU_MARKER_SIZE = 0x200
MENU_MARKERS = [
    "currentIndex_MainMenu",
    "JoystickConnected",
    "Joystick0_AnalogX_stance",
    "szProfileName1",
]

POLL_SECONDS = 0.016
STATUS_EVERY_SECONDS = 1.0


@dataclass
class StageProfile:
    stage_num: int
    key: str
    display_name: str
    level_marker: str
    grappluh_addr: int = 0
    weapon_mirror_addr: int = 0


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u8(addr: int) -> int:
    return read_bytes(addr, 1)[0]


def read_u32(addr: int) -> int:
    return int.from_bytes(read_bytes(addr, 4), "big")


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def mirror_active(addr: int) -> Tuple[bool, int, int]:
    if addr == 0:
        return False, 0, 0
    try:
        b = read_u8(addr)
    except Exception:
        b = 0
    try:
        w = read_u32(addr)
    except Exception:
        w = 0
    return (b == 1 or w == 1), b, w


def make_profiles(args: argparse.Namespace) -> Dict[str, StageProfile]:
    return {
        "stage1": StageProfile(1, "stage1", "Stage 1 / Tutorial", "Ltreehs1", 0, 0),
        "stage2": StageProfile(2, "stage2", "Stage 2 / Donutty", "Lkitchn1", int(args.stage2_grappluh_addr, 0), int(args.stage2_weapon_mirror, 0)),
        "stage7": StageProfile(7, "stage7", "Stage 7 / Spankarific", "Lbkyrd1", int(args.stage7_grappluh_addr, 0), int(args.stage7_weapon_mirror, 0)),
        "stage11": StageProfile(11, "stage11", "Stage 11 / Cavity Cave", "Lcave1", int(args.stage11_grappluh_addr, 0), int(args.stage11_weapon_mirror, 0)),
    }


def hook_dolphin(profiles: Dict[str, StageProfile]) -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0
    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            _ = read_u32(Y_ACTION_SUPPRESS_ADDR)
            _ = read_bytes(LEVEL_TEXT_SCAN_START, 0x20)
            _ = read_bytes(MENU_MARKER_ADDR, 0x20)
            for p in profiles.values():
                if p.grappluh_addr:
                    _ = read_u32(p.grappluh_addr)
                if p.weapon_mirror_addr:
                    _ = read_u8(p.weapon_mirror_addr)
                    _ = read_u32(p.weapon_mirror_addr)
            print("[DOLPHIN] Hooked. KND memory is readable.")
            return
        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def detect_stage(profiles: Dict[str, StageProfile], forced_stage: str) -> Optional[StageProfile]:
    if forced_stage != "auto":
        return profiles[forced_stage]
    try:
        raw = read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE)
    except Exception:
        return None
    text = raw.decode("latin-1", errors="ignore")
    for p in profiles.values():
        if p.level_marker in text:
            return p
    return None


def menu_signature_present() -> Tuple[bool, str]:
    try:
        raw = read_bytes(MENU_MARKER_ADDR, MENU_MARKER_SIZE)
    except Exception:
        return False, ""
    plain = raw.decode("latin-1", errors="ignore")
    stripped = plain.replace("\x00", "")
    try:
        utf16le = raw.decode("utf-16-le", errors="ignore")
    except Exception:
        utf16le = ""
    try:
        utf16be = raw.decode("utf-16-be", errors="ignore")
    except Exception:
        utf16be = ""
    for marker in MENU_MARKERS:
        if marker in plain or marker in stripped or marker in utf16le or marker in utf16be:
            return True, marker
    return False, ""


def weapon_owned_for_stage(args: argparse.Namespace, stage_key: str) -> bool:
    if stage_key == "stage2":
        return bool(args.stage2_weapon)
    if stage_key == "stage7":
        return bool(args.stage7_weapon)
    if stage_key == "stage11":
        return bool(args.stage11_weapon)
    return True


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--stage", choices=["auto", "stage1", "stage2", "stage7", "stage11"], default="auto")
    p.add_argument("--grappluh", action="store_true")
    p.add_argument("--stage2-weapon", action="store_true")
    p.add_argument("--stage7-weapon", action="store_true")
    p.add_argument("--stage11-weapon", action="store_true")
    p.add_argument("--disable-grappluh-sabotage", action="store_true")
    p.add_argument("--owned-reset-once", action="store_true", default=True)
    p.add_argument("--disable-owned-reset-once", action="store_true")
    p.add_argument("--disable-y-block", action="store_true")

    p.add_argument("--stage2-grappluh-addr", default="0x811FD074")
    p.add_argument("--stage7-grappluh-addr", default="0x8128CF24")
    p.add_argument("--stage11-grappluh-addr", default="0x8122BB04")

    p.add_argument("--stage2-weapon-mirror", default="0x815128CC")
    p.add_argument("--stage7-weapon-mirror", default="0x815129AC")
    p.add_argument("--stage11-weapon-mirror", default="0x815127EC")
    p.add_argument("--menu-trigger-mode", choices=["any", "stage_absent"], default="any")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    profiles = make_profiles(args)

    print("=" * 112)
    print(VERSION)
    print("=" * 112)
    print(f"[CONFIG] stage={args.stage} grappluh_owned={args.grappluh} sabotage_disabled={args.disable_grappluh_sabotage}")
    print("[RULE] Missing Grappluh writes 2. Owned Grappluh writes 0 once on stage entry, then stops. No global B block.")
    print(f"[STAGE 2]  0x{profiles['stage2'].grappluh_addr:08X}")
    print(f"[STAGE 7]  0x{profiles['stage7'].grappluh_addr:08X}")
    print(f"[STAGE 11] 0x{profiles['stage11'].grappluh_addr:08X}")
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin(profiles)

    last_stage_key: Optional[str] = None
    last_menu_marker_state: Optional[Tuple[bool, str]] = None
    last_grappluh_report: Optional[Tuple[int, int, bool, bool]] = None
    last_weapon_report = None
    write_count_grappluh = 0
    write_count_y = 0
    heartbeat_time = time.time()
    menu_seen_since_stage = False
    owned_reset_done = False

    while True:
        try:
            now = time.time()
            marker_stage = detect_stage(profiles, "auto")
            stage_profile = detect_stage(profiles, args.stage)

            marker_match, matched_marker = menu_signature_present()
            marker_state = (marker_match, matched_marker)
            if marker_state != last_menu_marker_state:
                if marker_match:
                    print(f"[MENU MARKER] Found {matched_marker!r} near 0x{MENU_MARKER_ADDR:08X}.")
                else:
                    print(f"[MENU MARKER] No menu marker near 0x{MENU_MARKER_ADDR:08X}.")
                last_menu_marker_state = marker_state

            menu_triggered = marker_match and (args.menu_trigger_mode == "any" or marker_stage is None)
            if menu_triggered:
                if not menu_seen_since_stage:
                    print(f"[MENU] Main-menu signature detected via {matched_marker!r}. Waiting for level re-entry.")
                menu_seen_since_stage = True
                last_stage_key = "menu"
                last_grappluh_report = None
                last_weapon_report = None
                owned_reset_done = False
                time.sleep(POLL_SECONDS)
                continue

            if stage_profile is None:
                if last_stage_key != "none":
                    print("[STAGE] No supported N1 stage detected. No writes.")
                last_stage_key = "none"
                last_grappluh_report = None
                last_weapon_report = None
                owned_reset_done = False
                time.sleep(0.050)
                continue

            if stage_profile.key != last_stage_key or menu_seen_since_stage:
                print(f"[STAGE] Active profile: {stage_profile.display_name}")
                last_stage_key = stage_profile.key
                last_grappluh_report = None
                last_weapon_report = None
                owned_reset_done = False
                menu_seen_since_stage = False

            grappluh_current = 0
            grappluh_addr = stage_profile.grappluh_addr
            wrote_grappluh = False
            owned_reset_disabled = bool(args.disable_owned_reset_once)

            if grappluh_addr and not args.disable_grappluh_sabotage:
                grappluh_current = read_u32(grappluh_addr)

                if not args.grappluh:
                    if grappluh_current != GRAPPLUH_MISSING_VALUE:
                        write_u32(grappluh_addr, GRAPPLUH_MISSING_VALUE)
                    wrote_grappluh = True
                    write_count_grappluh += 1

                else:
                    # Owned Grappluh: write 0 once to try to return the value to its normal baseline,
                    # then stop touching it so Grappluh is not forcibly held in any state.
                    if not owned_reset_disabled and not owned_reset_done:
                        write_u32(grappluh_addr, GRAPPLUH_OWNED_RESET_VALUE)
                        wrote_grappluh = True
                        owned_reset_done = True
                        write_count_grappluh += 1
                        print(f"[GRAPPLUH] OWNED RESET ONCE: addr=0x{grappluh_addr:08X} wrote {GRAPPLUH_OWNED_RESET_VALUE:08X}")

            grappluh_report = (grappluh_addr, grappluh_current, bool(args.grappluh), wrote_grappluh, owned_reset_done)
            if grappluh_report != last_grappluh_report:
                if grappluh_addr:
                    if args.grappluh:
                        state = "reset-done" if owned_reset_done else "waiting reset"
                        print(f"[GRAPPLUH] OWNED: no continuous write. addr=0x{grappluh_addr:08X} current={grappluh_current:08X} {state}")
                    else:
                        print(f"[GRAPPLUH] MISSING/BLOCK: addr=0x{grappluh_addr:08X} current={grappluh_current:08X} target={GRAPPLUH_MISSING_VALUE:08X}")
                else:
                    print(f"[GRAPPLUH] No sabotage address configured for {stage_profile.display_name}.")
                last_grappluh_report = grappluh_report

            weapon_active = False
            weapon_owned = weapon_owned_for_stage(args, stage_profile.key)
            weapon_u8 = 0
            weapon_u32 = 0
            if stage_profile.weapon_mirror_addr:
                weapon_active, weapon_u8, weapon_u32 = mirror_active(stage_profile.weapon_mirror_addr)

            weapon_report = (weapon_active, weapon_u8, weapon_u32, weapon_owned)
            if weapon_report != last_weapon_report:
                if stage_profile.weapon_mirror_addr:
                    print(f"[WEAPON] active={weapon_active} u8={weapon_u8:02X} u32={weapon_u32:08X} owned={weapon_owned} mirror=0x{stage_profile.weapon_mirror_addr:08X}")
                else:
                    print("[WEAPON] No N1 weapon mirror for this stage.")
                last_weapon_report = weapon_report

            y_blocking = False
            if not args.disable_y_block and stage_profile.weapon_mirror_addr and weapon_active and not weapon_owned:
                write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                write_count_y += 1
                y_blocking = True

            if now - heartbeat_time >= STATUS_EVERY_SECONDS:
                target_text = f"0x{GRAPPLUH_MISSING_VALUE:08X}" if not args.grappluh and grappluh_addr else "None"
                print(
                    f"[STATUS] stage={stage_profile.key} grappluh_owned={args.grappluh} "
                    f"grappluh_addr={('0x%08X' % grappluh_addr) if grappluh_addr else 'None'} "
                    f"target={target_text} weapon_active={weapon_active} weapon_owned={weapon_owned} "
                    f"Y_blocking={y_blocking} writes_grappluh={write_count_grappluh} writes_y={write_count_y}"
                )
                heartbeat_time = now
                write_count_grappluh = 0
                write_count_y = 0

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            print("\n[STOP] N1 Grappluh sabotage stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
