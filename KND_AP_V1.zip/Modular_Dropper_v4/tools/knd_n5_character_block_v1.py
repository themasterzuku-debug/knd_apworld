from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional

import dolphin_memory_engine as dme


VERSION = "KND N5 CHARACTER BLOCK v1"

# ---------------------------------------------------------------------------
# N5 ONLY
# ---------------------------------------------------------------------------
#
# Includes:
#   - N5 Double Jump block.
#   - N5 Wall Jump block.
#   - N5 L / Lock-On block.
#
# Does NOT include Y/weapon logic.
# N5 has no weapon in Stage 3 or Stage 9.


CE50_JUMP_BLOCK_ADDR = 0x8076CE50
CE50_BLOCK_VALUE = 0x00000001

WALL_CONTACT_ADDR = 0x80417C5C

LOCK_ON_BLOCK_ADDR = 0x8076CE7C
LOCK_ON_BLOCK_VALUE = 0x00000000

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000

POLL_SECONDS = 0.008
STATUS_EVERY_SECONDS = 1.0

ALT_BLOCK_SECONDS = 6.0
WALL_CONTACT_GRACE_SECONDS = 0.350
POST_WALL_GRACE_SECONDS = 0.900
WALL_BLOCK_SECONDS = 1.250
EXTEND_WHILE_WALL_CONTACT = True


@dataclass
class StageProfile:
    key: str
    display_name: str
    level_marker: str
    airborne_addr: int


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u32(addr: int) -> int:
    return int.from_bytes(read_bytes(addr, 4), "big")


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def make_profiles(args: argparse.Namespace) -> Dict[str, StageProfile]:
    return {
        "stage3": StageProfile(
            key="stage3",
            display_name="Stage 3 / Boogification",
            level_marker="Ltreehs5",
            airborne_addr=int(args.stage3_air, 0),
        ),
        "stage9": StageProfile(
            key="stage9",
            display_name="Stage 9 / Ship Shape",
            level_marker="Lrvnge5",
            airborne_addr=int(args.stage9_air, 0),
        ),
    }


def hook_dolphin(profiles: Dict[str, StageProfile]) -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0
    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            _ = read_u32(CE50_JUMP_BLOCK_ADDR)
            _ = read_u32(WALL_CONTACT_ADDR)
            _ = read_u32(LOCK_ON_BLOCK_ADDR)
            _ = read_bytes(LEVEL_TEXT_SCAN_START, 0x20)

            for p in profiles.values():
                _ = read_u32(p.airborne_addr)

            print("[DOLPHIN] Hooked. KND memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def detect_stage(profiles: Dict[str, StageProfile], forced_stage: str) -> Optional[StageProfile]:
    if forced_stage != "auto":
        return profiles[forced_stage]

    try:
        raw = read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE)
    except Exception:
        return None

    text = raw.decode("latin-1", errors="ignore")
    for p in profiles.values():
        if p.level_marker in text:
            return p
    return None


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--stage", choices=["auto", "stage3", "stage9"], default="auto")
    p.add_argument("--n5-double", action="store_true", help="Move_N5_DoubleJump owned.")
    p.add_argument("--n5-wall", action="store_true", help="Move_N5_WallJump owned.")

    p.add_argument("--disable-movement-block", action="store_true")
    p.add_argument("--disable-l-block", action="store_true")

    p.add_argument("--stage3-air", default="0x81309194")  # latest observed Stage 3 airborne; previous was 0x813095E4
    p.add_argument("--stage9-air", default="0x8123E5D4")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    profiles = make_profiles(args)

    print("=" * 96)
    print(VERSION)
    print("=" * 96)
    print()
    print("[CONFIG]")
    print(f"  stage:                  {args.stage}")
    print(f"  N5 DoubleJump owned:    {bool(args.n5_double)}")
    print(f"  N5 WallJump owned:      {bool(args.n5_wall)}")
    print(f"  movement disabled:      {bool(args.disable_movement_block)}")
    print(f"  L block disabled:       {bool(args.disable_l_block)}")
    print()
    print("[ADDRESSES]")
    print(f"  CE50 jump block:        0x{CE50_JUMP_BLOCK_ADDR:08X} -> 00000001")
    print(f"  Wall contact:           0x{WALL_CONTACT_ADDR:08X}")
    print(f"  L / Lock-On block:      0x{LOCK_ON_BLOCK_ADDR:08X} -> 00000000")
    print()
    print("[STAGES]")
    for p in profiles.values():
        print(f"  {p.display_name}: air=0x{p.airborne_addr:08X}")
    print()
    print("[RULES]")
    print("  Missing DoubleJump -> block open-air double jump.")
    print("  Missing WallJump   -> block wall jump.")
    print("  Missing either     -> block L.")
    print("  Has both           -> no movement block and L allowed.")
    print("  N5 has no Y/weapon block.")
    print()
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin(profiles)

    last_stage_key: Optional[str] = None
    last_air: Optional[int] = None
    last_wall: Optional[int] = None
    last_ce50: Optional[int] = None
    last_l: Optional[int] = None

    airborne_session_active = False
    airborne_session_handled = False
    airborne_block_started_at = 0.0

    wall_grace_until = 0.0
    wall_block_until = 0.0

    write_count_ce50 = 0
    write_count_l = 0
    heartbeat_time = time.time()

    while True:
        try:
            now = time.time()
            p = detect_stage(profiles, args.stage)

            if p is None:
                if last_stage_key != "none":
                    print("[STAGE] No supported N5 stage detected. No writes.")
                    last_stage_key = "none"
                    airborne_session_active = False
                    airborne_session_handled = False
                    wall_grace_until = wall_block_until = 0.0
                    last_air = last_wall = last_ce50 = last_l = None
                time.sleep(0.050)
                continue

            if p.key != last_stage_key:
                print(f"[STAGE] Active profile: {p.display_name}")
                last_stage_key = p.key
                airborne_session_active = False
                airborne_session_handled = False
                wall_grace_until = wall_block_until = 0.0
                last_air = last_wall = last_ce50 = last_l = None

            air_value = read_u32(p.airborne_addr)
            wall_value = read_u32(WALL_CONTACT_ADDR)
            ce50_value = read_u32(CE50_JUMP_BLOCK_ADDR)
            l_value = read_u32(LOCK_ON_BLOCK_ADDR)

            airborne = air_value == 1
            grounded = air_value == 0
            wall = wall_value == 1

            wants_double_block = not args.n5_double
            wants_wall_block = not args.n5_wall
            wants_l_block = not (args.n5_double and args.n5_wall)

            if air_value != last_air:
                print(f"[AIR]    0x{p.airborne_addr:08X} = {air_value:08X} ({'AIRBORNE' if airborne else 'GROUNDED' if grounded else 'UNKNOWN'})")
                last_air = air_value

            if wall_value != last_wall:
                print(f"[WALL]   0x{WALL_CONTACT_ADDR:08X} = {wall_value:08X}")
                if wall:
                    wall_grace_until = max(wall_grace_until, now + WALL_CONTACT_GRACE_SECONDS)
                    print(f"[WALL] Contact start: grace {WALL_CONTACT_GRACE_SECONDS:.3f}s.")
                    if wants_wall_block:
                        wall_block_until = max(wall_block_until, now + WALL_BLOCK_SECONDS)
                        print(f"[WALL] Wall block start: {WALL_BLOCK_SECONDS:.3f}s.")
                elif last_wall == 1:
                    wall_grace_until = max(wall_grace_until, now + POST_WALL_GRACE_SECONDS)
                    print(f"[WALL] Contact end: post-wall grace {POST_WALL_GRACE_SECONDS:.3f}s.")
                last_wall = wall_value

            if ce50_value != last_ce50:
                print(f"[CE50]   0x{CE50_JUMP_BLOCK_ADDR:08X} = {ce50_value:08X}")
                last_ce50 = ce50_value

            if l_value != last_l:
                print(f"[L]      0x{LOCK_ON_BLOCK_ADDR:08X} = {l_value:08X}")
                last_l = l_value

            if grounded and airborne_session_handled:
                print("[SESSION] Airborne returned to 0; next airborne=1 can start a new CE50 double block.")
                airborne_session_handled = False

            if (
                not args.disable_movement_block
                and wants_double_block
                and airborne
                and not airborne_session_active
                and not airborne_session_handled
            ):
                airborne_block_started_at = now
                airborne_session_active = True
                airborne_session_handled = True
                print("[DOUBLE BLOCK] session ON (airborne == 1)")

            if airborne_session_active and (now - airborne_block_started_at >= ALT_BLOCK_SECONDS):
                print(f"[DOUBLE BLOCK] session off ({ALT_BLOCK_SECONDS:.1f}s timer ended)")
                airborne_session_active = False

            if airborne_session_active and grounded:
                print("[DOUBLE BLOCK] session off (grounded)")
                airborne_session_active = False

            if (
                not args.disable_movement_block
                and wants_wall_block
                and wall
                and EXTEND_WHILE_WALL_CONTACT
            ):
                wall_block_until = max(wall_block_until, now + WALL_BLOCK_SECONDS)

            wall_block_active = (not args.disable_movement_block) and wants_wall_block and (now < wall_block_until)
            wall_grace_active = wall or now < wall_grace_until

            if wants_double_block and wall_grace_active:
                double_write_active = False
            else:
                double_write_active = airborne_session_active

            should_write_ce50 = (
                not args.disable_movement_block
                and (double_write_active or wall_block_active)
            )

            if should_write_ce50:
                write_u32(CE50_JUMP_BLOCK_ADDR, CE50_BLOCK_VALUE)
                write_count_ce50 += 1

            l_blocking = False
            if not args.disable_l_block and wants_l_block:
                write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
                write_count_l += 1
                l_blocking = True

            if now - heartbeat_time >= STATUS_EVERY_SECONDS:
                double_remaining = max(0.0, ALT_BLOCK_SECONDS - (now - airborne_block_started_at)) if airborne_session_active else 0.0
                wall_remaining = max(0.0, wall_block_until - now) if wants_wall_block else 0.0
                grace_remaining = max(0.0, wall_grace_until - now)
                print(
                    f"[STATUS] stage={p.key} air={air_value} wall={wall_value} CE50={ce50_value:08X} "
                    f"double_lock={wants_double_block} wall_lock={wants_wall_block} "
                    f"double_remaining={double_remaining:.1f}s wall_remaining={wall_remaining:.1f}s "
                    f"wall_grace={grace_remaining:.1f}s writing_ce50={should_write_ce50} "
                    f"l_blocking={l_blocking} writes_ce50={write_count_ce50} writes_l={write_count_l}"
                )
                heartbeat_time = now
                write_count_ce50 = write_count_l = 0

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            print("\n[STOP] N5 character block stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
