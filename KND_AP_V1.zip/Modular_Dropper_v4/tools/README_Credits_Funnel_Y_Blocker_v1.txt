KND Credits Funnel Y Blocker v1

Purpose:
- Test the Credits funnel idea.
- If the roadmap/level list contains Credits twice, block Y while the currently loaded level is Credits.

Simple rule:
- Scan all 15 slot rows.
- Count rows where the 8-byte level name is Credits.
- If Credits count >= 2 AND current loaded level text contains Credits:
    write 0x00000000 to 0x807319D8
- Otherwise do nothing.

Addresses:
- Y suppress: 0x807319D8 = 00000000
- Slot row name offset: row + 0x08
- Level text scan: 0x80414000 size 0x1000

BATs:
- run_credits_funnel_y_blocker_v1.bat
    Normal test.

- run_credits_funnel_y_blocker_print_rows_v1.bat
    Normal test, but prints all slot names when they change.

- run_credits_funnel_y_blocker_always_in_credits_DEBUG_v1.bat
    Blocks Y in Credits even without duplicate Credits. Debug only.

- run_credits_funnel_y_blocker_clear_y_when_not_blocking_TEST_v1.bat
    Experimental: writes 1 to Y when not blocking.
    Most previous KND blockers do not force-clear Y, so only use this if Y stays stuck.
