@echo off
cd /d "%~dp0"
python knd_credits_funnel_y_blocker_v1.py --always-block-in-credits --print-rows
pause
