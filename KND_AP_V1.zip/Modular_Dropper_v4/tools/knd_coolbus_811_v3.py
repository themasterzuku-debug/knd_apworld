from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional

import dolphin_memory_engine as dme

VERSION = "KND COOL BUS v3 - NEW 0x811xxxxx U32 ADDRESSES"

# ---------------------------------------------------------------------------
# PURPOSE
# ---------------------------------------------------------------------------
# Separate Cool Bus helper using the corrected in-level Cool Bus addresses.
#
# Corrected addresses from testing:
#   CoolBus1: 0x81100AEC, range 0..4
#   CoolBus2: 0x8118676C, range 0..5
#   CoolBus3: 0x8117A62C, range 0..5
#
# These correspond to Gecko-style writes like:
#   05100AEC 00000001
#   0518676C 00000002
#   0517A62C 00000005
#
# Because those examples are 32-bit values, this script writes U32 values,
# not single bytes. This is intentionally different from the older combined
# Cool Bus / Weapon Flag Pusher script.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CoolBusTrack:
    key: str
    label: str
    addr: int
    max_value: int


COOLBUS_TRACKS = [
    CoolBusTrack("coolbus1", "Cool Bus 1 / Stage 4", 0x81100AEC, 4),
    CoolBusTrack("coolbus2", "Cool Bus 2",           0x8118676C, 5),
    CoolBusTrack("coolbus3", "Cool Bus 3",           0x8117A62C, 5),
]


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u32(addr: int) -> int:
    data = read_bytes(addr, 4)
    return int.from_bytes(data, byteorder="big", signed=False)


def write_u32(addr: int, value: int) -> None:
    value = int(value) & 0xFFFFFFFF
    dme.write_bytes(addr, value.to_bytes(4, byteorder="big", signed=False))


def hook_dolphin() -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0
    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            for track in COOLBUS_TRACKS:
                _ = read_u32(track.addr)

            print("[DOLPHIN] Hooked. KND Cool Bus memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="KND Cool Bus v3 helper using corrected 0x811xxxxx addresses.")

    p.add_argument("--cb1-count", type=int, choices=range(0, 5), default=0)
    p.add_argument("--cb2-count", type=int, choices=range(0, 6), default=0)
    p.add_argument("--cb3-count", type=int, choices=range(0, 6), default=0)

    p.add_argument(
        "--mode",
        choices=["counts", "max_all", "lock_all", "watch"],
        default="counts",
        help="counts uses --cb1-count/--cb2-count/--cb3-count.",
    )
    p.add_argument("--once", action="store_true", help="Write once and exit.")
    p.add_argument("--poll", type=float, default=0.250, help="Seconds between repeated writes.")
    p.add_argument("--status-every", type=float, default=2.0)

    return p.parse_args()


def target_for_track(track: CoolBusTrack, args: argparse.Namespace) -> Optional[int]:
    if args.mode == "watch":
        return None
    if args.mode == "lock_all":
        return 0
    if args.mode == "max_all":
        return track.max_value

    if track.key == "coolbus1":
        return min(max(args.cb1_count, 0), track.max_value)
    if track.key == "coolbus2":
        return min(max(args.cb2_count, 0), track.max_value)
    if track.key == "coolbus3":
        return min(max(args.cb3_count, 0), track.max_value)
    return None


def write_or_watch(track: CoolBusTrack, target: Optional[int]) -> int:
    current = read_u32(track.addr)
    if target is not None:
        target = max(0, min(int(target), track.max_value))
        if current != target:
            write_u32(track.addr, target)
            current = target
    return current


def main() -> None:
    args = parse_args()

    print("=" * 96)
    print(VERSION)
    print("=" * 96)
    print()
    print("[CONFIG]")
    print(f"  CB1 count:    {args.cb1_count}/4")
    print(f"  CB2 count:    {args.cb2_count}/5")
    print(f"  CB3 count:    {args.cb3_count}/5")
    print(f"  Mode:         {args.mode}")
    print(f"  Once:         {bool(args.once)}")
    print()
    print("[IMPORTANT]")
    print("  Uses corrected 0x811xxxxx Cool Bus addresses.")
    print("  Writes U32 values to match Gecko-style 05xxxxxx 0000000N lines.")
    print("  These values may visibly update/take effect when the meter fills and X explosion/shield is used.")
    print()
    print("[TRACKS]")
    for track in COOLBUS_TRACKS:
        print(f"  {track.label:24s} 0x{track.addr:08X} max={track.max_value}")
    print()
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin()

    last_values: Dict[str, int] = {}
    heartbeat = time.time()

    while True:
        try:
            for track in COOLBUS_TRACKS:
                target = target_for_track(track, args)
                val = write_or_watch(track, target)
                if last_values.get(track.key) != val:
                    action = "target" if target is not None else "watch"
                    print(f"[COOLBUS] {track.label:24s} 0x{track.addr:08X} = {val} / {track.max_value} ({action})")
                    last_values[track.key] = val

            now = time.time()
            if now - heartbeat >= args.status_every:
                state = ", ".join(f"{t.key}={last_values.get(t.key, '?')}/{t.max_value}" for t in COOLBUS_TRACKS)
                print(f"[STATUS] {state} mode={args.mode}")
                heartbeat = now

            if args.once:
                print("[DONE] Once mode complete.")
                return

            time.sleep(args.poll)

        except KeyboardInterrupt:
            print("\n[STOP] Cool Bus helper stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
