from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import dolphin_memory_engine as dme


VERSION = "KND N4 CHARACTER BLOCK v2 - COMPLETE AUTO BATS / Stage5 air candidates noted"

# ---------------------------------------------------------------------------
# N4 ONLY
# ---------------------------------------------------------------------------
#
# Includes:
#   - N4 Double Jump block through CE50.
#   - N4 wall/ledge grace helper using 0x80417C5C.
#   - N4 Y / weapon block.
#   - N4 L / Lock-On block.
#
# Does NOT include any N5 logic.


CE50_JUMP_BLOCK_ADDR = 0x8076CE50
CE50_BLOCK_VALUE = 0x00000001

WALL_CONTACT_ADDR = 0x80417C5C

LOCK_ON_BLOCK_ADDR = 0x8076CE7C
LOCK_ON_BLOCK_VALUE = 0x00000000

Y_ACTION_SUPPRESS_ADDR = 0x807319D8
Y_ACTION_SUPPRESS_VALUE = 0x00000000

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000

POLL_SECONDS = 0.008
STATUS_EVERY_SECONDS = 1.0

ALT_BLOCK_SECONDS = 6.0
WALL_CONTACT_GRACE_SECONDS = 0.350
POST_WALL_GRACE_SECONDS = 0.900


@dataclass
class StageProfile:
    key: str
    display_name: str
    level_marker: str
    airborne_addr: int
    weapon_item: str
    weapon_mirror_addr: int


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u8(addr: int) -> int:
    return read_bytes(addr, 1)[0]


def read_u32(addr: int) -> int:
    return int.from_bytes(read_bytes(addr, 4), "big")


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def mirror_active(addr: int) -> Tuple[bool, int, int]:
    if addr == 0:
        return False, 0, 0
    try:
        b = read_u8(addr)
    except Exception:
        b = 0
    try:
        w = read_u32(addr)
    except Exception:
        w = 0
    return (b == 1 or w == 1), b, w


def make_profiles(args: argparse.Namespace) -> Dict[str, StageProfile]:
    return {
        "stage5": StageProfile(
            key="stage5",
            display_name="Stage 5 / Spank Happy",
            level_marker="Ltrehs4A",
            airborne_addr=int(args.stage5_air, 0),
            weapon_item="Splanker_Unjammed",
            weapon_mirror_addr=int(args.stage5_weapon_mirror, 0),
        ),
        "stage12": StageProfile(
            key="stage12",
            display_name="Stage 12 / Overflow",
            level_marker="Ltrehs4B",
            airborne_addr=int(args.stage12_air, 0),
            weapon_item="Sluggah_Unjammed",
            weapon_mirror_addr=int(args.stage12_weapon_mirror, 0),
        ),
    }


def hook_dolphin(profiles: Dict[str, StageProfile]) -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0
    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            _ = read_u32(CE50_JUMP_BLOCK_ADDR)
            _ = read_u32(WALL_CONTACT_ADDR)
            _ = read_u32(LOCK_ON_BLOCK_ADDR)
            _ = read_u32(Y_ACTION_SUPPRESS_ADDR)
            _ = read_bytes(LEVEL_TEXT_SCAN_START, 0x20)

            for p in profiles.values():
                _ = read_u32(p.airborne_addr)
                _ = read_u8(p.weapon_mirror_addr)
                _ = read_u32(p.weapon_mirror_addr)

            print("[DOLPHIN] Hooked. KND memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def detect_stage(profiles: Dict[str, StageProfile], forced_stage: str) -> Optional[StageProfile]:
    if forced_stage != "auto":
        return profiles[forced_stage]

    try:
        raw = read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE)
    except Exception:
        return None

    text = raw.decode("latin-1", errors="ignore")
    for p in profiles.values():
        if p.level_marker in text:
            return p
    return None


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--stage", choices=["auto", "stage5", "stage12"], default="auto")
    p.add_argument("--n4-double", action="store_true", help="Move_N4_DoubleJump owned.")

    p.add_argument("--stage5-weapon", action="store_true")
    p.add_argument("--stage12-weapon", action="store_true")

    p.add_argument("--disable-movement-block", action="store_true")
    p.add_argument("--disable-y-block", action="store_true")
    p.add_argument("--disable-l-block", action="store_true")
    p.add_argument("--disable-wall-grace", action="store_true")

    p.add_argument("--n4-y-strategy", choices=["always", "mirror"], default="always")

    p.add_argument("--stage5-air", default="0x81469754")
    p.add_argument("--stage12-air", default="0x8135A254")

    p.add_argument("--stage5-weapon-mirror", default="0x81512974")
    p.add_argument("--stage12-weapon-mirror", default="0x81512824")
    return p.parse_args()


def weapon_owned_for_stage(args: argparse.Namespace, stage_key: str) -> bool:
    if stage_key == "stage5":
        return bool(args.stage5_weapon)
    if stage_key == "stage12":
        return bool(args.stage12_weapon)
    return False


def main() -> None:
    args = parse_args()
    profiles = make_profiles(args)

    print("=" * 96)
    print(VERSION)
    print("=" * 96)
    print()
    print("[CONFIG]")
    print(f"  stage:                  {args.stage}")
    print(f"  N4 DoubleJump owned:    {bool(args.n4_double)}")
    print(f"  N4 Y strategy:          {args.n4_y_strategy}")
    print(f"  movement disabled:      {bool(args.disable_movement_block)}")
    print(f"  Y block disabled:       {bool(args.disable_y_block)}")
    print(f"  L block disabled:       {bool(args.disable_l_block)}")
    print(f"  wall/ledge grace:       {not bool(args.disable_wall_grace)}")
    print()
    print("[ADDRESSES]")
    print(f"  CE50 jump block:        0x{CE50_JUMP_BLOCK_ADDR:08X} -> 00000001")
    print(f"  Wall/ledge contact:     0x{WALL_CONTACT_ADDR:08X}")
    print(f"  L / Lock-On block:      0x{LOCK_ON_BLOCK_ADDR:08X} -> 00000000")
    print(f"  Y suppress:             0x{Y_ACTION_SUPPRESS_ADDR:08X} -> 00000000")
    print()
    print("[STAGES]")
    for p in profiles.values():
        print(f"  {p.display_name}: air=0x{p.airborne_addr:08X}, weapon_mirror=0x{p.weapon_mirror_addr:08X}")
    print()
    print("[RULES]")
    print("  Missing N4 DoubleJump -> CE50 double block + L block.")
    print("  Owned N4 DoubleJump   -> no movement block + L allowed.")
    print("  Missing N4 weapon     -> Y suppressed during N4 stage.")
    print()
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin(profiles)

    last_stage_key: Optional[str] = None
    last_air: Optional[int] = None
    last_wall: Optional[int] = None
    last_ce50: Optional[int] = None
    last_l: Optional[int] = None
    last_weapon_report = None

    airborne_session_active = False
    airborne_session_handled = False
    airborne_block_started_at = 0.0
    wall_grace_until = 0.0

    write_count_ce50 = 0
    write_count_y = 0
    write_count_l = 0
    heartbeat_time = time.time()

    while True:
        try:
            now = time.time()
            p = detect_stage(profiles, args.stage)

            if p is None:
                if last_stage_key != "none":
                    print("[STAGE] No supported N4 stage detected. No writes.")
                    last_stage_key = "none"
                    airborne_session_active = False
                    airborne_session_handled = False
                    wall_grace_until = 0.0
                    last_air = last_wall = last_ce50 = last_l = None
                    last_weapon_report = None
                time.sleep(0.050)
                continue

            if p.key != last_stage_key:
                print(f"[STAGE] Active profile: {p.display_name}")
                last_stage_key = p.key
                airborne_session_active = False
                airborne_session_handled = False
                wall_grace_until = 0.0
                last_air = last_wall = last_ce50 = last_l = None
                last_weapon_report = None

            air_value = read_u32(p.airborne_addr)
            wall_value = read_u32(WALL_CONTACT_ADDR)
            ce50_value = read_u32(CE50_JUMP_BLOCK_ADDR)
            l_value = read_u32(LOCK_ON_BLOCK_ADDR)
            weapon_active, weapon_u8, weapon_u32 = mirror_active(p.weapon_mirror_addr)
            weapon_owned = weapon_owned_for_stage(args, p.key)

            airborne = air_value == 1
            grounded = air_value == 0
            wall = wall_value == 1

            if air_value != last_air:
                print(f"[AIR]    0x{p.airborne_addr:08X} = {air_value:08X} ({'AIRBORNE' if airborne else 'GROUNDED' if grounded else 'UNKNOWN'})")
                last_air = air_value

            if wall_value != last_wall:
                print(f"[WALL]   0x{WALL_CONTACT_ADDR:08X} = {wall_value:08X}")
                if not args.disable_wall_grace:
                    if wall:
                        wall_grace_until = max(wall_grace_until, now + WALL_CONTACT_GRACE_SECONDS)
                        print(f"[WALL] Contact start: no-write grace {WALL_CONTACT_GRACE_SECONDS:.3f}s.")
                    elif last_wall == 1:
                        wall_grace_until = max(wall_grace_until, now + POST_WALL_GRACE_SECONDS)
                        print(f"[WALL] Contact end: post-wall no-write grace {POST_WALL_GRACE_SECONDS:.3f}s.")
                last_wall = wall_value

            if ce50_value != last_ce50:
                print(f"[CE50]   0x{CE50_JUMP_BLOCK_ADDR:08X} = {ce50_value:08X}")
                last_ce50 = ce50_value

            if l_value != last_l:
                print(f"[L]      0x{LOCK_ON_BLOCK_ADDR:08X} = {l_value:08X}")
                last_l = l_value

            weapon_report = (weapon_active, weapon_u8, weapon_u32, weapon_owned)
            if weapon_report != last_weapon_report:
                print(
                    f"[WEAPON] active={weapon_active} u8={weapon_u8:02X} "
                    f"u32={weapon_u32:08X} owned={weapon_owned} mirror=0x{p.weapon_mirror_addr:08X}"
                )
                last_weapon_report = weapon_report

            wants_double_block = not args.n4_double
            wants_l_block = not args.n4_double

            if grounded and airborne_session_handled:
                print("[SESSION] Airborne returned to 0; next airborne=1 can start a new CE50 block.")
                airborne_session_handled = False

            if (
                not args.disable_movement_block
                and wants_double_block
                and airborne
                and not airborne_session_active
                and not airborne_session_handled
            ):
                airborne_block_started_at = now
                airborne_session_active = True
                airborne_session_handled = True
                print("[DOUBLE BLOCK] session ON (airborne == 1)")

            if airborne_session_active and (now - airborne_block_started_at >= ALT_BLOCK_SECONDS):
                print(f"[DOUBLE BLOCK] session off ({ALT_BLOCK_SECONDS:.1f}s timer ended)")
                airborne_session_active = False

            if airborne_session_active and grounded:
                print("[DOUBLE BLOCK] session off (grounded)")
                airborne_session_active = False

            wall_grace_active = (not args.disable_wall_grace) and (wall or now < wall_grace_until)
            double_write_active = airborne_session_active and not wall_grace_active
            should_write_ce50 = (not args.disable_movement_block) and wants_double_block and double_write_active

            if should_write_ce50:
                write_u32(CE50_JUMP_BLOCK_ADDR, CE50_BLOCK_VALUE)
                write_count_ce50 += 1

            y_blocking = False
            if not args.disable_y_block and not weapon_owned:
                if args.n4_y_strategy == "always":
                    write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                    write_count_y += 1
                    y_blocking = True
                elif args.n4_y_strategy == "mirror" and weapon_active:
                    write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                    write_count_y += 1
                    y_blocking = True

            l_blocking = False
            if not args.disable_l_block and wants_l_block:
                write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
                write_count_l += 1
                l_blocking = True

            if now - heartbeat_time >= STATUS_EVERY_SECONDS:
                remaining = max(0.0, ALT_BLOCK_SECONDS - (now - airborne_block_started_at)) if airborne_session_active else 0.0
                grace_remaining = max(0.0, wall_grace_until - now)
                print(
                    f"[STATUS] stage={p.key} air={air_value} wall={wall_value} CE50={ce50_value:08X} "
                    f"double_lock={wants_double_block} double_remaining={remaining:.1f}s "
                    f"wall_grace={grace_remaining:.1f}s writing_ce50={should_write_ce50} "
                    f"weapon_owned={weapon_owned} y_blocking={y_blocking} l_blocking={l_blocking} "
                    f"writes_ce50={write_count_ce50} writes_y={write_count_y} writes_l={write_count_l}"
                )
                heartbeat_time = now
                write_count_ce50 = write_count_y = write_count_l = 0

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            print("\n[STOP] N4 character block stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
