@echo off
cd /d "%~dp0"
python knd_coolbus_811_v3.py --cb1-count 0 --cb2-count 1 --cb3-count 0
pause
