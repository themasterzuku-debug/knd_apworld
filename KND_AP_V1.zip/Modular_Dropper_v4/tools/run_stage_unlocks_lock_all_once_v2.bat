@echo off
cd /d "%~dp0"
python knd_weapon_flag_pusher_v2_separate.py --normal-weapons watch --stage-unlocks lock_all --once
pause
