@echo off
cd /d "%~dp0"
python knd_n5_character_block_v1.py --stage auto --n5-double --n5-wall
pause
