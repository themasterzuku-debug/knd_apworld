@echo off
cd /d "%~dp0"
python knd_n3_character_block_v3.py --stage auto --n3-movement 1 --stage6-weapon --stage10-weapon
pause
