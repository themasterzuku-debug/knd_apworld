@echo off
cd /d "%~dp0"
python knd_n1_grappluh_sabotage_v13.py --stage stage7 --grappluh --stage7-weapon --disable-owned-reset-once
pause
