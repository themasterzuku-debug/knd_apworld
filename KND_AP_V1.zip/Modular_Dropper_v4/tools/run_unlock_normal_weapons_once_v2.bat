@echo off
cd /d "%~dp0"
python knd_weapon_flag_pusher_v2_separate.py --normal-weapons unlock --stage-unlocks watch --once
pause
