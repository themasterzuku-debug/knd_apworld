from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from typing import Dict, Optional

import dolphin_memory_engine as dme

VERSION = "KND WEAPON / STAGE FLAG PUSHER v2 - SEPARATE FROM COOL BUS"

# ---------------------------------------------------------------------------
# PURPOSE
# ---------------------------------------------------------------------------
# Separate flag pusher based on the original combined v2 script, but with all
# Cool Bus logic removed.
#
# Controls byte flags for:
#   - normal non-Cool-Bus weapon-start flags
#   - optional stage/slot unlock watching/testing
#
# Main intended AP default:
#   normal-weapons=unlock, stage-unlocks=watch
#
# Important:
#   These are byte flags. This script writes single bytes.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Flag:
    key: str
    label: str
    addr: int
    max_value: int = 1


STAGE_UNLOCK_FLAGS = [
    Flag("stage2_unlock",  "Stage 2 Unlock",  0x8076F54F),
    Flag("stage3_unlock",  "Stage 3 Unlock",  0x8076F4AF),
    Flag("stage4_unlock",  "Stage 4 Unlock",  0x8076F5BF),
    Flag("slot5_unlock",   "Slot 5 Unlock",   0x8076F4EF),
    Flag("slot6_unlock",   "Slot 6 Unlock",   0x8076F57F),
    Flag("slot7_unlock",   "Slot 7 Unlock",   0x8076F55F),
    Flag("slot8_unlock",   "Slot 8 Unlock",   0x8076F44F),
    Flag("slot9_unlock",   "Slot 9 Unlock",   0x8076F50F),
    Flag("slot10_unlock",  "Slot 10 Unlock",  0x8076F4DF),
    Flag("slot11_unlock",  "Slot 11 Unlock",  0x8076F46F),
    Flag("slot12_unlock",  "Slot 12 Unlock",  0x8076F48F),
    Flag("slot13_unlock",  "Slot 13 Unlock",  0x8076F59F),
    Flag("slot14_unlock",  "Slot 14 Unlock",  0x8076F52F),
    Flag("slot15_unlock",  "Slot 15 Unlock",  0x8076F4CF),
]

NORMAL_WEAPON_FLAGS = [
    Flag("gmzka",    "Gmzka active for Level 2 start", 0x8076F4BF),
    Flag("smellmet", "Smellmet start flag",            0x8076F5CF),
    Flag("splanker", "Splanker start flag",            0x8076F58F),
    Flag("frappe",   "Frappe start flag",              0x8076F56F),
    Flag("scampp",   "Scampp start flag",              0x8076F45F),
    Flag("thumper",  "Thumper start flag",             0x8076F47F),
    Flag("bajooka",  "Bajooka start flag",             0x8076F49F),
    Flag("sluggah",  "Sluggah start flag",             0x8076F5AF),
]


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def read_u8(addr: int) -> int:
    return read_bytes(addr, 1)[0]


def write_u8(addr: int, value: int) -> None:
    dme.write_bytes(addr, bytes([int(value) & 0xFF]))


def hook_dolphin() -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0
    all_flags = STAGE_UNLOCK_FLAGS + NORMAL_WEAPON_FLAGS

    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            for flag in all_flags:
                _ = read_u8(flag.addr)

            print("[DOLPHIN] Hooked. KND flag memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="KND weapon/stage flag pusher separated from Cool Bus.")

    p.add_argument(
        "--normal-weapons",
        choices=["unlock", "lock", "watch"],
        default="unlock",
        help="unlock = write normal weapon flags to 1; lock = write them to 0; watch = do not write them.",
    )
    p.add_argument(
        "--stage-unlocks",
        choices=["watch", "unlock_all", "lock_all", "unlock_up_to"],
        default="watch",
        help="Default watch does not touch stage unlock flags.",
    )
    p.add_argument(
        "--stage-unlock-up-to",
        type=int,
        default=1,
        help="Used only with --stage-unlocks unlock_up_to. Example 5 writes unlock flags through Slot/Stage 5.",
    )
    p.add_argument("--once", action="store_true", help="Write once and exit.")
    p.add_argument("--poll", type=float, default=0.250, help="Seconds between repeated writes.")
    p.add_argument("--status-every", type=float, default=2.0)

    return p.parse_args()


def target_for_stage_unlock(flag: Flag, args: argparse.Namespace) -> Optional[int]:
    if args.stage_unlocks == "watch":
        return None
    if args.stage_unlocks == "unlock_all":
        return 1
    if args.stage_unlocks == "lock_all":
        return 0

    num = None
    if flag.key.startswith("stage"):
        try:
            num = int(flag.key[len("stage"):].split("_", 1)[0])
        except Exception:
            pass
    elif flag.key.startswith("slot"):
        try:
            num = int(flag.key[len("slot"):].split("_", 1)[0])
        except Exception:
            pass

    if num is None:
        return None
    return 1 if num <= args.stage_unlock_up_to else 0


def target_for_normal_weapon(_flag: Flag, args: argparse.Namespace) -> Optional[int]:
    if args.normal_weapons == "watch":
        return None
    if args.normal_weapons == "unlock":
        return 1
    if args.normal_weapons == "lock":
        return 0
    return None


def write_or_watch(flag: Flag, target: Optional[int]) -> int:
    current = read_u8(flag.addr)
    if target is not None:
        target = max(0, min(int(target), flag.max_value))
        if current != target:
            write_u8(flag.addr, target)
            current = target
    return current


def main() -> None:
    args = parse_args()

    print("=" * 104)
    print(VERSION)
    print("=" * 104)
    print()
    print("[CONFIG]")
    print(f"  Normal weapons:      {args.normal_weapons}")
    print(f"  Stage unlocks:       {args.stage_unlocks}")
    print(f"  Stage unlock up to:  {args.stage_unlock_up_to}")
    print(f"  Once:                {bool(args.once)}")
    print()
    print("[MAIN AP INTENDED DEFAULT]")
    print("  normal-weapons=unlock, stage-unlocks=watch")
    print("  This means: normal weapons forced on, stage unlock flags watched only and not changed.")
    print()
    print("[FLAGS]")
    print("  Stage unlock flags:")
    for f in STAGE_UNLOCK_FLAGS:
        print(f"    {f.label:32s} 0x{f.addr:08X} max={f.max_value}")
    print("  Normal weapon start flags:")
    for f in NORMAL_WEAPON_FLAGS:
        print(f"    {f.label:32s} 0x{f.addr:08X} max={f.max_value}")
    print()
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin()

    last_values: Dict[str, int] = {}
    heartbeat = time.time()

    while True:
        try:
            for f in STAGE_UNLOCK_FLAGS:
                target = target_for_stage_unlock(f, args)
                val = write_or_watch(f, target)
                if last_values.get(f.key) != val:
                    action = "target" if target is not None else "watch"
                    print(f"[STAGE]  {f.label:31s} 0x{f.addr:08X} = {val:02X} ({action})")
                    last_values[f.key] = val

            for f in NORMAL_WEAPON_FLAGS:
                target = target_for_normal_weapon(f, args)
                val = write_or_watch(f, target)
                if last_values.get(f.key) != val:
                    action = "target" if target is not None else "watch"
                    print(f"[WEAPON] {f.label:31s} 0x{f.addr:08X} = {val:02X} ({action})")
                    last_values[f.key] = val

            now = time.time()
            if now - heartbeat >= args.status_every:
                weapon_on = sum(1 for f in NORMAL_WEAPON_FLAGS if last_values.get(f.key) == 1)
                print(
                    f"[STATUS] normal_weapons_on={weapon_on}/{len(NORMAL_WEAPON_FLAGS)} "
                    f"stage_unlocks_mode={args.stage_unlocks} normal_weapons_mode={args.normal_weapons}"
                )
                heartbeat = now

            if args.once:
                print("[DONE] Once mode complete.")
                return

            time.sleep(args.poll)

        except KeyboardInterrupt:
            print("\n[STOP] Weapon / stage flag pusher stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
