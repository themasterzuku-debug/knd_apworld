@echo off
cd /d "%~dp0"
python knd_n4_character_block_v2.py --stage auto --n4-double --stage5-weapon --stage12-weapon
pause
