@echo off
cd /d "%~dp0"
python knd_n1_grappluh_sabotage_v13.py --stage stage11 --grappluh
pause
