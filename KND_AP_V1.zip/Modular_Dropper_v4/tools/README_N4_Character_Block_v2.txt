KND N4 Character Block v2

This is the same N4-only character block as v1, but with the missing Auto BATs added.

Auto BAT matrix:

- run_n4_auto_no_double_no_weapons_v2.bat
  Missing DoubleJump, missing both N4 weapons.

- run_n4_auto_no_double_all_weapons_v2.bat
  Missing DoubleJump, owns both N4 weapons.

- run_n4_auto_double_no_weapons_v2.bat
  Owns DoubleJump, missing both N4 weapons.

- run_n4_auto_double_all_weapons_v2.bat
  Owns DoubleJump, owns both N4 weapons.

N4 rules:
- Missing Move_N4_DoubleJump:
  block double jump and block L.
- Owned Move_N4_DoubleJump:
  movement allowed and L allowed.
- Missing N4 stage weapon:
  suppress Y.
- Default Y strategy is always: if the N4 weapon is missing, suppress Y in that N4 stage.
- Optional Y strategy mirror only suppresses Y when the weapon mirror is active.

Addresses:
- Stage 5 / Spank Happy airborne: 0x814ABF44 (primary; old 0x81469754 is stale/unstable)
- Stage 12 / Overflow airborne:   0x8135A254
- CE50 jump block:                0x8076CE50 = 00000001
- Wall/ledge contact helper:      0x80417C5C
- L / Lock-On block:              0x8076CE7C = 00000000
- Y suppress:                     0x807319D8 = 00000000
- Stage 5 weapon mirror:          0x81512974
- Stage 12 weapon mirror:         0x81512824

N4 Stage 5 / Spank Happy airborne address note - RC6.11
--------------------------------------------------------
The Stage 5 airborne value may appear at different nearby runtime/mirror addresses depending on game load/session state.
Treat all of these as READ-ONLY candidates. Do not write to them.

Priority/order for Stage 5 airborne tracking:
1. 0x81469754 - original N4 v2 address; can work on some loads, but can also become stale/random/stuck.
2. 0x814ABF44 - newer primary candidate; flips earlier when valid, so it can catch the A/double-jump block sooner.
3. 0x814ABF4C - newer backup/secondary candidate.

Easy Client behavior:
- Reads all three Stage 5 candidates.
- Looks for stable 0/1 values.
- Avoids a lone candidate that disagrees with the other two.
- Latches the best current candidate for the current stage session.
- Resets the latch when leaving/re-entering the stage or when the latched candidate becomes invalid/disagrees too long.

Important separation:
- Airborne tracking is ONLY for N4 DoubleJump/A/CE50 blocking.
- It does not decide N4 Y/weapon behavior.
- N4 Y/weapon behavior should remain mirror-only and separate from airborne tracking.


RC6.13 note - known Stage 5 / Stage 12 airborne candidates:
- Stage 5 / Spank Happy read-only candidates: 0x81469754, 0x81469304, 0x8146930C, 0x814ABF44, 0x814ABF4C.
- Stage 12 / Overflow read-only candidates: 0x8135A254, 0x81359E04.
- These are observed candidates, not proven exhaustive.
- Client should latch behavior, not blindly trust priority.
- These are movement/A/CE50 only. Do not use them for Y or weapon blocking.

RC6.20 N4 airborne latch note:
- N4 airborne candidate addresses are still read-only.
- The Easy Client now requires 5 clean grounded->airborne->grounded cycles before latching an N4 airborne candidate.
- This is specifically to avoid level-load flickers or a stuck 1 being selected as the air tracker, especially in Stage 12 / Overflow.
- N4 airborne/DoubleJump logic remains separate from N4 weapon/Y suppression.
