@echo off
cd /d "%~dp0"
python knd_weapon_flag_pusher_v2_separate.py --normal-weapons lock --stage-unlocks watch --once
pause
