@echo off
cd /d "%~dp0"
python knd_n1_grappluh_sabotage_v13.py --stage stage2 --grappluh --stage2-weapon
pause
