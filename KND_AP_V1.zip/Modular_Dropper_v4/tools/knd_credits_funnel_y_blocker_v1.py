from __future__ import annotations

import argparse
import time
from typing import Dict, List, Tuple

import dolphin_memory_engine as dme


VERSION = "KND CREDITS FUNNEL Y BLOCKER v1"

Y_ACTION_SUPPRESS_ADDR = 0x807319D8
Y_ACTION_SUPPRESS_VALUE = 0x00000000

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000

NAME_OFFSET = 0x08
NAME_SIZE = 8

SLOT_ROW: Dict[int, int] = {
    1:  0x80765E80,
    2:  0x80765EA0,
    3:  0x80765EC0,
    4:  0x80765EE0,
    5:  0x80765F00,
    6:  0x80765F20,
    7:  0x80765F40,
    8:  0x80765F70,
    9:  0x80765F90,
    10: 0x80765FB0,
    11: 0x80765FE0,
    12: 0x80766010,
    13: 0x80766030,
    14: 0x80766050,
    15: 0x80766070,
}

POLL_SECONDS = 0.016
STATUS_EVERY_SECONDS = 1.0


def read_bytes(addr: int, size: int) -> bytes:
    return bytes(dme.read_bytes(addr, size))


def write_u32(addr: int, value: int) -> None:
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def decode_slot_name(raw: bytes) -> str:
    return raw.decode("latin-1", errors="ignore").replace("\x00", "").strip()


def read_slot_rows() -> List[Tuple[int, int, bytes, str]]:
    out: List[Tuple[int, int, bytes, str]] = []
    for slot, row in SLOT_ROW.items():
        addr = row + NAME_OFFSET
        raw = read_bytes(addr, NAME_SIZE)
        out.append((slot, addr, raw, decode_slot_name(raw)))
    return out


def credits_slots(rows: List[Tuple[int, int, bytes, str]]) -> List[int]:
    found: List[int] = []
    for slot, _addr, raw, name in rows:
        if raw.startswith(b"Credits") or name == "Credits":
            found.append(slot)
    return found


def current_level_is_credits() -> bool:
    try:
        raw = read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE)
    except Exception:
        return False

    text = raw.decode("latin-1", errors="ignore")
    return "Credits" in text


def hook_dolphin() -> None:
    print("[DOLPHIN] Hooking...")
    last_msg = 0.0

    while True:
        try:
            if hasattr(dme, "is_hooked"):
                try:
                    if not dme.is_hooked():
                        dme.hook()
                except Exception:
                    dme.hook()
            else:
                dme.hook()

            _ = read_bytes(LEVEL_TEXT_SCAN_START, 0x20)
            _ = read_slot_rows()
            print("[DOLPHIN] Hooked. KND memory is readable.")
            return

        except KeyboardInterrupt:
            raise
        except Exception as e:
            now = time.time()
            if now - last_msg >= 2.0:
                print(f"[DOLPHIN] Waiting for KND memory... ({e})")
                last_msg = now
            time.sleep(0.50)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--print-rows", action="store_true")
    p.add_argument("--block-if-credits-count", type=int, default=2)
    p.add_argument("--always-block-in-credits", action="store_true")
    p.add_argument("--clear-y-when-not-blocking", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    print("=" * 100)
    print(VERSION)
    print("=" * 100)
    print(f"[RULE] Block Y while current level is Credits AND Credits count >= {args.block_if_credits_count}.")
    print("[RULE] Duplicate Credits in the slot-row list is treated as the funnel signal.")
    print(f"[WRITE] Y suppress: 0x{Y_ACTION_SUPPRESS_ADDR:08X} -> {Y_ACTION_SUPPRESS_VALUE:08X}")
    print("[STOP] Ctrl+C")
    print()

    hook_dolphin()

    last_rows_report = None
    last_condition_report = None
    heartbeat = time.time()
    writes_y = 0

    while True:
        try:
            now = time.time()

            rows = read_slot_rows()
            cslots = credits_slots(rows)
            ccount = len(cslots)
            in_credits = current_level_is_credits()

            if args.print_rows:
                rows_report = tuple((slot, name) for slot, _addr, _raw, name in rows)
                if rows_report != last_rows_report:
                    print("[ROWS]")
                    for slot, addr, raw, name in rows:
                        print(f"  Slot {slot:02d}: addr=0x{addr:08X} raw={raw.hex()} name={name!r}")
                    last_rows_report = rows_report

            should_block = in_credits and (
                args.always_block_in_credits or ccount >= args.block_if_credits_count
            )

            condition_report = (in_credits, tuple(cslots), should_block)
            if condition_report != last_condition_report:
                print(
                    f"[CONDITION] in_credits={in_credits} credits_slots={cslots} "
                    f"credits_count={ccount} block_y={should_block}"
                )
                last_condition_report = condition_report

            if should_block:
                write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                writes_y += 1
            elif args.clear_y_when_not_blocking:
                write_u32(Y_ACTION_SUPPRESS_ADDR, 0x00000001)

            if now - heartbeat >= STATUS_EVERY_SECONDS:
                print(
                    f"[STATUS] in_credits={in_credits} credits_slots={cslots} "
                    f"block_y={should_block} writes_y={writes_y}"
                )
                heartbeat = now
                writes_y = 0

            time.sleep(POLL_SECONDS)

        except KeyboardInterrupt:
            print("\n[STOP] Credits funnel Y blocker stopped.")
            return
        except Exception as e:
            print(f"[WAIT] Memory read/write failed; retrying... ({e})")
            time.sleep(0.50)


if __name__ == "__main__":
    main()
