KND N1 Grappluh Sabotage v13 - Owned Reset Once

Change from v12:
- Missing Grappluh still writes 2 continuously to the active stage Grappluh address.
- Owned Grappluh now writes 0 ONCE on stage entry/re-entry, then stops touching the address.

Reason:
- Owned/no-write was leaving the Grappluh state stuck from the previous blocked value.
- This test tries to put the value back to normal/baseline without force-holding it there.

Stage-specific addresses:
- Stage 2 / Donutty:      0x811FD074
- Stage 7 / Spankarific:  0x8128CF24
- Stage 11 / Cavity Cave: 0x8122BB04

Y / weapon remains:
- Stage 2 weapon mirror:  0x815128CC
- Stage 7 weapon mirror:  0x815129AC
- Stage 11 weapon mirror: 0x815127EC
- Y suppress:             0x807319D8 = 00000000

No L suppress.
No hard B block.
No B counter.
No Grappluh latch.

Four config types exist for Auto and for Stage 2 / 7 / 11:
- No Grappluh / No Weapon
- Grappluh / No Weapon
- No Grappluh / Weapon
- Grappluh / Weapon

If the owned reset once causes problems, use:
--disable-owned-reset-once
