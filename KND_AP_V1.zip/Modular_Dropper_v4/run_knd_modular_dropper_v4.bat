@echo off
cd /d "%~dp0"
python knd_modular_dropper_v4.py
pause
