KND Modular Dropper v4 - protected launcher/manual test supervisor
==================================================================

Default AP-safe setup:
- Run Easy Client v15: ON
- Manual standalone stage supervisor: OFF
- Standalone CoolBus: OFF
- Weapon/Stage Flag Pusher: OFF

Why supervisor defaults OFF:
Easy Client v15 already contains the AP item-state blockers for N1/N2/N3/N4/N5. Running the standalone character scripts at the same time can cause duplicate memory writers and make good scripts fight each other.

Manual testing:
- Turn Easy Client v15 OFF if you only want standalone script testing.
- Turn Manual standalone stage supervisor ON.
- Enable the specific character checkboxes/options you want to test.

CoolBus fix:
The v3 Dropper used wrong CoolBus args. v4 calls the tested knd_coolbus_811_v3.py script correctly:
- watch -> --mode watch
- counts -> --mode counts --cb1-count # --cb2-count # --cb3-count #
- lock all once -> --mode lock_all --once
- max all once -> --mode max_all --once


CREDITS FUNNEL Y BLOCKER ADDED IN RC5
- The Modular Dropper now has a separate Credits Funnel checkbox.
- Normal mode launches knd_credits_funnel_y_blocker_v1.py with no debug flags.
- Its rule is: if current loaded level text contains Credits AND Credits appears at least twice in the 15 slot rows, write 0 to 0x807319D8.
- It does not force-clear Y in normal mode, so it should not fight normal stage blockers outside funnel Credits.
- Debug/test modes are available from the dropdown but should not be used for normal AP play.
