from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import ttk, messagebox
from typing import Dict, List, Optional, Tuple

try:
    import dolphin_memory_engine as dme  # type: ignore
except Exception:
    dme = None  # type: ignore

BASE = Path(__file__).resolve().parent
TOOLS = BASE / "tools"
CREATE_NEW_CONSOLE = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)

SCRIPT_CORE = TOOLS / "knd_easy_client_clean_v15.py"
SCRIPT_N1 = TOOLS / "knd_n1_grappluh_sabotage_v13.py"
SCRIPT_N3 = TOOLS / "knd_n3_character_block_v3.py"
SCRIPT_N4 = TOOLS / "knd_n4_character_block_v2.py"
SCRIPT_N5 = TOOLS / "knd_n5_character_block_v1.py"
SCRIPT_FLAG = TOOLS / "knd_weapon_flag_pusher_v2_separate.py"
SCRIPT_COOLBUS = TOOLS / "knd_coolbus_811_v3.py"
SCRIPT_CREDITS_FUNNEL = TOOLS / "knd_credits_funnel_y_blocker_v1.py"

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x1000

Y_FIRE_BLOCK_ADDR = 0x8076CE44
Y_ACTION_SUPPRESS_ADDR = 0x807319D8
LOCK_ON_BLOCK_ADDR = 0x8076CE7C
CE50_JUMP_BLOCK_ADDR = 0x8076CE50
GATE_ALLOW_VALUE = 0x00000001
CE50_ALLOW_VALUE = 0x00000000


@dataclass(frozen=True)
class StageRoute:
    stage_id: str
    display: str
    marker: str
    character: str
    forced_stage_arg: Optional[str]


STAGE_ROUTES: Tuple[StageRoute, ...] = (
    StageRoute("stage2",  "Stage 2 / Donutty",       "Lkitchn1", "N1", "stage2"),
    StageRoute("stage7",  "Stage 7 / Spankarific",   "Lbkyrd1",  "N1", "stage7"),
    StageRoute("stage11", "Stage 11 / Cavity Cave",  "Lcave1",   "N1", "stage11"),

    StageRoute("stage6",  "Stage 6 / Hamsterama",    "Ltreehs3", "N3", "stage6"),
    StageRoute("stage10", "Stage 10 / Brush Off",    "Lbkyrd3",  "N3", "stage10"),

    StageRoute("stage5",  "Stage 5 / Spank Happy",   "Ltrehs4A", "N4", "stage5"),
    StageRoute("stage12", "Stage 12 / Overflow",     "Ltrehs4B", "N4", "stage12"),

    StageRoute("stage3",  "Stage 3 / Boogification", "Ltreehs5", "N5", "stage3"),
    StageRoute("stage9",  "Stage 9 / Ship Shape",    "Lrvnge5",  "N5", "stage9"),
)

# Non-character levels where the supervisor should stop character blockers.
NON_CHARACTER_MARKERS = (
    "Ltreehs1",  # Tutorial
    "Lsky2A",   # SnotBomber
    "Lsky2B",   # Tarpoon
    "Lspace2",  # MoonTrip
    "LmoonAll", # Lunarumble
    "Credits",
)


def read_level_text() -> str:
    if dme is None:
        raise RuntimeError("dolphin_memory_engine is not importable.")
    if hasattr(dme, "is_hooked"):
        try:
            if not dme.is_hooked():
                dme.hook()
        except Exception:
            dme.hook()
    else:
        dme.hook()
    raw = bytes(dme.read_bytes(LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE))
    return raw.decode("latin-1", errors="ignore")


def write_u32(addr: int, value: int) -> None:
    if dme is None:
        return
    dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))


def reset_y_fire_gates_once() -> None:
    try:
        if dme is None:
            return
        if hasattr(dme, "is_hooked"):
            try:
                if not dme.is_hooked():
                    dme.hook()
            except Exception:
                dme.hook()
        else:
            dme.hook()
        write_u32(Y_FIRE_BLOCK_ADDR, GATE_ALLOW_VALUE)
        write_u32(Y_ACTION_SUPPRESS_ADDR, GATE_ALLOW_VALUE)
        write_u32(LOCK_ON_BLOCK_ADDR, GATE_ALLOW_VALUE)
        write_u32(CE50_JUMP_BLOCK_ADDR, CE50_ALLOW_VALUE)
    except Exception:
        pass


def detect_route_from_text(text: str) -> Optional[StageRoute]:
    # Prefer the last explicit load/done-load bracket if present.
    # Examples observed:
    # [APP] Done Loading level [Lrvnge5]
    # [APP] Loading level [Ltreehs5]
    import re
    matches = re.findall(r"(?:Done Loading level|Loading level)\s*\[([^\]]+)\]", text)
    if matches:
        marker = matches[-1].split("\x00", 1)[0]
        for route in STAGE_ROUTES:
            if route.marker == marker:
                return route
        if marker in NON_CHARACTER_MARKERS:
            return None

    # Fallback to marker presence.
    found = [route for route in STAGE_ROUTES if route.marker in text]
    if len(found) == 1:
        return found[0]

    # If multiple stale markers are present, do not guess. Better to stop character blockers
    # than accidentally run the wrong global-input script.
    return None


class ModularDropperV3:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("KND Modular Dropper v4 - Protected Launcher + Manual Test Supervisor")
        self.root.geometry("900x790")

        self.processes: List[subprocess.Popen] = []
        self.core_process: Optional[subprocess.Popen] = None
        self.flag_process: Optional[subprocess.Popen] = None
        self.coolbus_process: Optional[subprocess.Popen] = None
        self.credits_funnel_process: Optional[subprocess.Popen] = None
        self.character_process: Optional[subprocess.Popen] = None
        self.character_route: Optional[StageRoute] = None

        self.supervisor_stop = threading.Event()
        self.supervisor_thread: Optional[threading.Thread] = None

        self.core_var = tk.BooleanVar(value=True)
        self.flag_var = tk.BooleanVar(value=False)
        self.coolbus_var = tk.BooleanVar(value=False)
        # Safe to run in normal AP mode: it only writes Y=0 while current level is Credits AND duplicate Credits is detected.
        self.credits_funnel_var = tk.BooleanVar(value=True)
        self.credits_funnel_mode = tk.StringVar(value="normal")
        # Protected default: Easy Client v15 already contains AP N1/N2/N3/N4/N5 blocking.
        # Keep standalone supervisor off unless doing manual testing, so scripts do not fight each other.
        self.supervisor_var = tk.BooleanVar(value=False)

        self.n1_enable = tk.BooleanVar(value=True)
        self.n3_enable = tk.BooleanVar(value=True)
        self.n4_enable = tk.BooleanVar(value=True)
        self.n5_enable = tk.BooleanVar(value=True)

        self.n1_grappluh = tk.BooleanVar(value=False)
        self.n1_stage2_weapon = tk.BooleanVar(value=False)
        self.n1_stage7_weapon = tk.BooleanVar(value=False)
        self.n1_stage11_weapon = tk.BooleanVar(value=False)

        self.n3_movement = tk.StringVar(value="0")
        self.n3_stage6_weapon = tk.BooleanVar(value=False)
        self.n3_stage10_weapon = tk.BooleanVar(value=False)

        self.n4_double = tk.BooleanVar(value=False)
        self.n4_stage5_weapon = tk.BooleanVar(value=False)
        self.n4_stage12_weapon = tk.BooleanVar(value=False)
        self.n4_y_strategy = tk.StringVar(value="always")

        self.n5_double = tk.BooleanVar(value=False)
        self.n5_wall = tk.BooleanVar(value=False)

        self.flag_normal_weapons = tk.StringVar(value="unlock")
        self.flag_stage_unlocks = tk.StringVar(value="watch")
        self.coolbus_mode = tk.StringVar(value="watch")
        self.coolbus_cb1 = tk.StringVar(value="0")
        self.coolbus_cb2 = tk.StringVar(value="0")
        self.coolbus_cb3 = tk.StringVar(value="0")

        self._build_ui()

    def _build_ui(self) -> None:
        pad = {"padx": 10, "pady": 5}
        frm = ttk.Frame(self.root)
        frm.pack(fill="both", expand=True, **pad)

        ttk.Label(frm, text="KND Modular Dropper v4", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(
            frm,
            text=(
                "Protected AP mode: launch Easy Client v15 by itself. It already handles Easy Run, N1/N2/N3/N4/N5, "
                "stage transfer, and CoolBus AP progressives. The Credits Funnel watcher is separate and safe by default. "
                "Enable the standalone stage supervisor only for manual testing."
            ),
            wraplength=780,
        ).pack(anchor="w", pady=(0, 8))

        nb = ttk.Notebook(frm)
        nb.pack(fill="both", expand=True)

        core = ttk.Frame(nb); nb.add(core, text="Core / Supervisor")
        ttk.Checkbutton(core, text="Run Easy Client v15 (includes Easy Run + AP blockers)", variable=self.core_var).pack(anchor="w", **pad)
        ttk.Checkbutton(core, text="Manual standalone stage supervisor (OFF for normal AP play)", variable=self.supervisor_var).pack(anchor="w", **pad)
        ttk.Checkbutton(core, text="Run Weapon/Stage Flag Pusher", variable=self.flag_var).pack(anchor="w", **pad)

        row = ttk.Frame(core); row.pack(anchor="w", **pad)
        ttk.Label(row, text="Normal weapons:").pack(side="left")
        ttk.Combobox(row, textvariable=self.flag_normal_weapons, values=["unlock", "lock", "watch"], width=12, state="readonly").pack(side="left", padx=5)
        ttk.Label(row, text="Stage unlocks:").pack(side="left", padx=(15, 0))
        ttk.Combobox(row, textvariable=self.flag_stage_unlocks, values=["watch", "unlock_all", "lock_all"], width=12, state="readonly").pack(side="left", padx=5)

        ttk.Checkbutton(core, text="Run Credits Funnel Y Blocker (duplicate Credits -> block Y in Credits)", variable=self.credits_funnel_var).pack(anchor="w", **pad)
        row_cf = ttk.Frame(core); row_cf.pack(anchor="w", **pad)
        ttk.Label(row_cf, text="Credits Funnel mode:").pack(side="left")
        ttk.Combobox(
            row_cf,
            textvariable=self.credits_funnel_mode,
            values=["normal", "print_rows", "always_in_credits_DEBUG", "clear_y_when_not_blocking_TEST"],
            width=32,
            state="readonly",
        ).pack(side="left", padx=5)

        ttk.Checkbutton(core, text="Run CoolBus standalone watcher/pusher (manual counts/tester; AP blocker is in Easy Client)", variable=self.coolbus_var).pack(anchor="w", **pad)
        row2 = ttk.Frame(core); row2.pack(anchor="w", **pad)
        ttk.Label(row2, text="CoolBus mode:").pack(side="left")
        ttk.Combobox(row2, textvariable=self.coolbus_mode, values=["watch", "counts", "lock_all_once", "max_all_once"], width=16, state="readonly").pack(side="left", padx=5)
        ttk.Label(row2, text="CB1:").pack(side="left", padx=(15, 0))
        ttk.Combobox(row2, textvariable=self.coolbus_cb1, values=["0", "1", "2", "3", "4"], width=3, state="readonly").pack(side="left", padx=3)
        ttk.Label(row2, text="CB2:").pack(side="left")
        ttk.Combobox(row2, textvariable=self.coolbus_cb2, values=["0", "1", "2", "3", "4", "5"], width=3, state="readonly").pack(side="left", padx=3)
        ttk.Label(row2, text="CB3:").pack(side="left")
        ttk.Combobox(row2, textvariable=self.coolbus_cb3, values=["0", "1", "2", "3", "4", "5"], width=3, state="readonly").pack(side="left", padx=3)

        chars = ttk.Frame(nb); nb.add(chars, text="Characters")
        ttk.Checkbutton(chars, text="Enable N1 route scripts", variable=self.n1_enable).pack(anchor="w", **pad)
        ttk.Checkbutton(chars, text="Grappluh owned", variable=self.n1_grappluh).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N1 Stage 2 weapon owned", variable=self.n1_stage2_weapon).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N1 Stage 7 weapon owned", variable=self.n1_stage7_weapon).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N1 Stage 11 weapon owned", variable=self.n1_stage11_weapon).pack(anchor="w", padx=35, pady=2)

        ttk.Separator(chars).pack(fill="x", padx=10, pady=8)
        ttk.Checkbutton(chars, text="Enable N3 route scripts", variable=self.n3_enable).pack(anchor="w", **pad)
        row = ttk.Frame(chars); row.pack(anchor="w", padx=35, pady=2)
        ttk.Label(row, text="N3 movement count:").pack(side="left")
        ttk.Combobox(row, textvariable=self.n3_movement, values=["0", "1", "2"], width=4, state="readonly").pack(side="left", padx=5)
        ttk.Checkbutton(chars, text="N3 Stage 6 weapon owned", variable=self.n3_stage6_weapon).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N3 Stage 10 weapon owned", variable=self.n3_stage10_weapon).pack(anchor="w", padx=35, pady=2)

        ttk.Separator(chars).pack(fill="x", padx=10, pady=8)
        ttk.Checkbutton(chars, text="Enable N4 route scripts", variable=self.n4_enable).pack(anchor="w", **pad)
        ttk.Checkbutton(chars, text="N4 DoubleJump owned", variable=self.n4_double).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N4 Stage 5 weapon owned", variable=self.n4_stage5_weapon).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N4 Stage 12 weapon owned", variable=self.n4_stage12_weapon).pack(anchor="w", padx=35, pady=2)
        row = ttk.Frame(chars); row.pack(anchor="w", padx=35, pady=2)
        ttk.Label(row, text="N4 Y strategy:").pack(side="left")
        ttk.Combobox(row, textvariable=self.n4_y_strategy, values=["always", "mirror"], width=8, state="readonly").pack(side="left", padx=5)

        ttk.Separator(chars).pack(fill="x", padx=10, pady=8)
        ttk.Checkbutton(chars, text="Enable N5 route scripts", variable=self.n5_enable).pack(anchor="w", **pad)
        ttk.Checkbutton(chars, text="N5 DoubleJump owned", variable=self.n5_double).pack(anchor="w", padx=35, pady=2)
        ttk.Checkbutton(chars, text="N5 WallJump owned", variable=self.n5_wall).pack(anchor="w", padx=35, pady=2)

        btns = ttk.Frame(frm)
        btns.pack(fill="x", pady=8)
        ttk.Button(btns, text="Start", command=self.start).pack(side="left", padx=5)
        ttk.Button(btns, text="Stop Character Script", command=self.stop_character).pack(side="left", padx=5)
        ttk.Button(btns, text="Reset Y/Fire Gates", command=self.reset_gates_button).pack(side="left", padx=5)
        ttk.Button(btns, text="Stop All", command=self.stop_all).pack(side="left", padx=5)
        ttk.Button(btns, text="Open Tools Folder", command=self.open_tools).pack(side="left", padx=5)
        ttk.Button(btns, text="Quit", command=self.quit).pack(side="right", padx=5)

        self.status = ttk.Label(frm, text="Ready.")
        self.status.pack(anchor="w")

    def _popen(self, label: str, script: Path, args: List[str]) -> Optional[subprocess.Popen]:
        if not script.exists():
            messagebox.showerror("Missing script", f"{label} script missing:\n{script}")
            return None
        cmd = [sys.executable, str(script)] + args
        p = subprocess.Popen(cmd, cwd=str(TOOLS), creationflags=CREATE_NEW_CONSOLE)
        self.processes.append(p)
        self.status.config(text=f"Started {label}: {' '.join(args)}")
        return p

    def start(self) -> None:
        if self.core_var.get() and (self.core_process is None or self.core_process.poll() is not None):
            self.core_process = self._popen("Core Easy Client", SCRIPT_CORE, [])

        if self.flag_var.get() and (self.flag_process is None or self.flag_process.poll() is not None):
            self.flag_process = self._popen(
                "Weapon Flag Pusher",
                SCRIPT_FLAG,
                ["--normal-weapons", self.flag_normal_weapons.get(), "--stage-unlocks", self.flag_stage_unlocks.get()],
            )

        if self.credits_funnel_var.get() and (self.credits_funnel_process is None or self.credits_funnel_process.poll() is not None):
            mode = self.credits_funnel_mode.get()
            args: List[str] = []
            if mode == "print_rows":
                args = ["--print-rows"]
            elif mode == "always_in_credits_DEBUG":
                args = ["--always-block-in-credits", "--print-rows"]
            elif mode == "clear_y_when_not_blocking_TEST":
                args = ["--clear-y-when-not-blocking", "--print-rows"]
            else:
                args = []
            self.credits_funnel_process = self._popen("Credits Funnel Y Blocker", SCRIPT_CREDITS_FUNNEL, args)

        if self.coolbus_var.get() and (self.coolbus_process is None or self.coolbus_process.poll() is not None):
            mode = self.coolbus_mode.get()
            if mode == "watch":
                self.coolbus_process = self._popen("CoolBus", SCRIPT_COOLBUS, ["--mode", "watch"])
            elif mode == "counts":
                self.coolbus_process = self._popen(
                    "CoolBus",
                    SCRIPT_COOLBUS,
                    [
                        "--mode", "counts",
                        "--cb1-count", self.coolbus_cb1.get(),
                        "--cb2-count", self.coolbus_cb2.get(),
                        "--cb3-count", self.coolbus_cb3.get(),
                    ],
                )
            elif mode == "lock_all_once":
                self.coolbus_process = self._popen("CoolBus", SCRIPT_COOLBUS, ["--mode", "lock_all", "--once"])
            elif mode == "max_all_once":
                self.coolbus_process = self._popen("CoolBus", SCRIPT_COOLBUS, ["--mode", "max_all", "--once"])

        if self.supervisor_var.get():
            self.start_supervisor()
        else:
            self.status.config(text="Started core/flags. Supervisor is off.")

    def start_supervisor(self) -> None:
        if self.supervisor_thread and self.supervisor_thread.is_alive():
            self.status.config(text="Supervisor already running.")
            return
        self.supervisor_stop.clear()
        self.supervisor_thread = threading.Thread(target=self._supervisor_loop, daemon=True)
        self.supervisor_thread.start()
        self.status.config(text="Supervisor running.")

    def _supervisor_loop(self) -> None:
        last_stage_id: Optional[str] = None
        last_error_time = 0.0

        while not self.supervisor_stop.is_set():
            try:
                text = read_level_text()
                route = detect_route_from_text(text)

                route_key = route.stage_id if route else None
                if route_key != last_stage_id:
                    last_stage_id = route_key
                    self.root.after(0, self._on_route_change, route)

                time.sleep(0.50)
            except Exception as e:
                now = time.time()
                if now - last_error_time >= 3.0:
                    self.root.after(0, lambda msg=str(e): self.status.config(text=f"Supervisor waiting for Dolphin/KND memory: {msg}"))
                    last_error_time = now
                time.sleep(1.0)

    def _on_route_change(self, route: Optional[StageRoute]) -> None:
        self.stop_character()
        reset_y_fire_gates_once()

        if route is None:
            self.status.config(text="No supported character stage detected; character blocker stopped. Y/fire gates reset once.")
            return

        if route.character == "N1" and not self.n1_enable.get():
            self.status.config(text=f"{route.display} detected, but N1 route scripts are disabled.")
            return
        if route.character == "N3" and not self.n3_enable.get():
            self.status.config(text=f"{route.display} detected, but N3 route scripts are disabled.")
            return
        if route.character == "N4" and not self.n4_enable.get():
            self.status.config(text=f"{route.display} detected, but N4 route scripts are disabled.")
            return
        if route.character == "N5" and not self.n5_enable.get():
            self.status.config(text=f"{route.display} detected, but N5 route scripts are disabled.")
            return

        script, args = self._args_for_route(route)
        self.character_route = route
        self.character_process = self._popen(f"{route.character} blocker for {route.display}", script, args)

    def _args_for_route(self, route: StageRoute) -> Tuple[Path, List[str]]:
        if route.character == "N1":
            args = ["--stage", route.forced_stage_arg or "auto"]
            if self.n1_grappluh.get(): args.append("--grappluh")
            if self.n1_stage2_weapon.get(): args.append("--stage2-weapon")
            if self.n1_stage7_weapon.get(): args.append("--stage7-weapon")
            if self.n1_stage11_weapon.get(): args.append("--stage11-weapon")
            return SCRIPT_N1, args

        if route.character == "N3":
            args = ["--stage", route.forced_stage_arg or "auto", "--n3-movement", self.n3_movement.get()]
            if self.n3_stage6_weapon.get(): args.append("--stage6-weapon")
            if self.n3_stage10_weapon.get(): args.append("--stage10-weapon")
            return SCRIPT_N3, args

        if route.character == "N4":
            args = ["--stage", route.forced_stage_arg or "auto", "--n4-y-strategy", self.n4_y_strategy.get()]
            if self.n4_double.get(): args.append("--n4-double")
            if self.n4_stage5_weapon.get(): args.append("--stage5-weapon")
            if self.n4_stage12_weapon.get(): args.append("--stage12-weapon")
            return SCRIPT_N4, args

        if route.character == "N5":
            args = ["--stage", route.forced_stage_arg or "auto"]
            if self.n5_double.get(): args.append("--n5-double")
            if self.n5_wall.get(): args.append("--n5-wall")
            return SCRIPT_N5, args

        raise ValueError(route.character)

    def stop_character(self) -> None:
        if self.character_process and self.character_process.poll() is None:
            self.character_process.terminate()
        self.character_process = None
        self.character_route = None

    def reset_gates_button(self) -> None:
        reset_y_fire_gates_once()
        self.status.config(text="Reset CE44/319D8/CE7C to 1 and CE50 to 0 once.")

    def stop_all(self) -> None:
        self.supervisor_stop.set()
        self.stop_character()
        alive = 0
        for p in list(self.processes):
            if p.poll() is None:
                alive += 1
                p.terminate()
        self.processes.clear()
        self.core_process = self.flag_process = self.coolbus_process = self.credits_funnel_process = None
        self.status.config(text=f"Stopped {alive} process(es).")

    def open_tools(self) -> None:
        os.startfile(str(TOOLS)) if hasattr(os, "startfile") else subprocess.Popen(["xdg-open", str(TOOLS)])

    def quit(self) -> None:
        self.stop_all()
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    ModularDropperV3().run()


if __name__ == "__main__":
    main()
