@echo off
cd /d "%~dp0"
python knd_easy_client_clean_v15.py
pause
