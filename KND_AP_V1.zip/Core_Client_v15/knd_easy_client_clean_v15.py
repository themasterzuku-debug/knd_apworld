from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import logging
import os
import re
import shutil
import ssl
import time
import zipfile
import uuid as uuidlib
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import dolphin_memory_engine as dme  # type: ignore
import websockets

try:
    import tkinter as tk
    from tkinter import messagebox
except Exception:
    tk = None
    messagebox = None

VERSION = "KND Easy Client Clean v15 - RC6.43 Slot1 native lock + final V1 polish"
GAME_NAME = "Codename: Kids Next Door (GC)"
CLIENT_TAGS = ["KND", "Dolphin", "EasyCleanV15"]
ITEMS_HANDLING = 0b001 | 0b010 | 0b100

BASE_DIR = Path(__file__).resolve().parent
STATE_DIR = BASE_DIR / ".knd_client_state"
PROFILE_DIR = STATE_DIR / "profiles"
STATE_DIR.mkdir(exist_ok=True)
PROFILE_DIR.mkdir(exist_ok=True)
CONFIG_PATH = STATE_DIR / "launcher_config_clean_v5.json"
EASY_RUN_STATE_PATH = STATE_DIR / "integrated_easy_run_state.json"
ACTIVE_GAME_DEFAULT = BASE_DIR / "Active Game"
ARCHIVE_RUNS_DEFAULT = BASE_DIR / "Archived Runs"

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
log = logging.getLogger("KNDCleanV13")

# ---------------------------------------------------------------------------
# Stable memory constants used by this cleaned client.
# ---------------------------------------------------------------------------

VIDEO_BUFFER_START = 0x803523B0
VIDEO_BUFFER_SIZE = 0xA0

LEVEL_TEXT_SCAN_START = 0x80414000
LEVEL_TEXT_SCAN_SIZE = 0x5000

# Cool Bus/N2 vehicle stages do not always put their live stage marker in the
# normal level text area. Stage 4 was observed around 0x80478160 as
# Design\Location\Dsky2A Instance / ...\Dsky2A\Camera...
COOLBUS_TEXT_SCAN_START = 0x80478000
COOLBUS_TEXT_SCAN_SIZE = 0x1000

# Main-menu / stage-select signature block. Used for delayed suppression of
# one-shot Sooper outfit flags after the AP check has already been credited.
MAIN_MENU_TEXT_SCAN_START = 0x80983040
MAIN_MENU_TEXT_SCAN_SIZE = 0x400
MAIN_MENU_TEXT_MARKERS: Tuple[str, ...] = (
    "currentIndex_MainMenu",
    "JoystickConnected",
    "Joystick0_AnalogX_stance",
    "szProfileName1",
)

Y_ACTION_SUPPRESS_ADDR = 0x807319D8
Y_ACTION_SUPPRESS_VALUE = 0x00000000
Y_ACTION_ALLOW_VALUE = 0x00000001

# Y/fire/action gate. Gecko: 0476CE44 00000000 blocks firing.
Y_FIRE_BLOCK_ADDR = 0x8076CE44
Y_FIRE_BLOCK_VALUE = 0x00000000
Y_FIRE_ALLOW_VALUE = 0x00000001

# Roadmap rows / current-slot table.
ROADMAP_SLOT_ROW: Dict[int, int] = {
    1:  0x80765E80,
    2:  0x80765EA0,
    3:  0x80765EC0,
    4:  0x80765EE0,
    5:  0x80765F00,
    6:  0x80765F20,
    7:  0x80765F40,
    8:  0x80765F70,
    9:  0x80765F90,
    10: 0x80765FB0,
    11: 0x80765FE0,
    12: 0x80766010,
    13: 0x80766030,
    14: 0x80766050,
    15: 0x80766070,
}
ROADMAP_NAME_OFFSET = 0x08
ROADMAP_NAME_SIZE = 0x08

STAGE_TO_BYTES: Dict[str, bytes] = {
    "Stage_01_Tutorial":      bytes.fromhex("4c74726565687331"),  # Ltreehs1
    "Stage_02_Donutty":       bytes.fromhex("4c6b697463686e31"),  # Lkitchn1
    "Stage_03_Boogification": bytes.fromhex("4c74726565687335"),  # Ltreehs5
    "Stage_04_SnotBomber":    bytes.fromhex("4c736b7932410035"),  # Lsky2A\0 5
    "Stage_05_Spank_Happy":   bytes.fromhex("4c74726568733441"),  # Ltrehs4A
    "Stage_06_Hamsterama":    bytes.fromhex("4c74726565687333"),  # Ltreehs3
    "Stage_07_Spankarific":   bytes.fromhex("4c626b7972643100"),  # Lbkyrd1\0
    "Stage_08_Tarpoon":       bytes.fromhex("4c736b7932420042"),  # Lsky2B\0 B
    "Stage_09_Ship_Shape":    bytes.fromhex("4c72766e67653500"),  # Lrvnge5\0
    "Stage_10_Brush_Off":     bytes.fromhex("4c626b7972643300"),  # Lbkyrd3\0
    "Stage_11_Cavity_Cave":   bytes.fromhex("4c63617665310042"),  # Lcave1\0 B
    "Stage_12_Overflow":      bytes.fromhex("4c74726568733442"),  # Ltrehs4B
    "Stage_13_MoonTrip":      bytes.fromhex("4c73706163653200"),  # Lspace2\0
    "Stage_14_Lunarumble":    bytes.fromhex("4c6d6f6f6e416c6c"),  # LmoonAll
    "Stage_15_Credits":       bytes.fromhex("4372656469747300"),  # Credits\0
}
BYTES_TO_STAGE: Dict[bytes, str] = {v: k for k, v in STAGE_TO_BYTES.items()}
ALL_ROADMAP_STAGES: List[str] = list(STAGE_TO_BYTES.keys())

ROADMAP_FIXED_SLOT_TO_STAGE: Dict[int, str] = {
    7: "Stage_07_Spankarific",
    10: "Stage_10_Brush_Off",
    11: "Stage_11_Cavity_Cave",
    15: "Stage_14_Lunarumble",
}
MOVABLE_ROADMAP_SLOTS: List[int] = [s for s in range(1, 16) if s not in ROADMAP_FIXED_SLOT_TO_STAGE]

SLOT_TO_COMPLETE_FMV: Dict[int, int] = {
    1: 3, 2: 4, 3: 5, 4: 6, 5: 7, 6: 8, 7: 9,
    8: 10, 9: 11, 10: 12, 11: 13, 12: 14, 13: 15, 14: 16,
}
FMV_TO_COMPLETE_SLOT: Dict[int, int] = {fmv: slot for slot, fmv in SLOT_TO_COMPLETE_FMV.items()}

STAGE_LABEL: Dict[str, str] = {
    "Stage_01_Tutorial": "Level 1 / Tutorial",
    "Stage_02_Donutty": "Level 2 / Donutty",
    "Stage_03_Boogification": "Level 3 / Boogification",
    "Stage_04_SnotBomber": "Level 4 / Snot Bomber",
    "Stage_05_Spank_Happy": "Level 5 / Spank Happy",
    "Stage_06_Hamsterama": "Level 6 / Hamsterama",
    "Stage_07_Spankarific": "Level 7 / Spankarific",
    "Stage_08_Tarpoon": "Level 8 / Tarpoon",
    "Stage_09_Ship_Shape": "Level 9 / Ship Shape",
    "Stage_10_Brush_Off": "Level 10 / Brush Off",
    "Stage_11_Cavity_Cave": "Level 11 / Cavity Cave",
    "Stage_12_Overflow": "Level 12 / Overflow",
    "Stage_13_MoonTrip": "Level 13 / Moon Trip",
    "Stage_14_Lunarumble": "Level 14 / Lunarumble",
    "Stage_15_Credits": "Level 15 / Credits",
}

# Short text markers found in the loaded level text area.  Used to keep
# location polling stage-local so old save data from other stages cannot fire
# AP checks while the player is somewhere else.
LEVEL_MARKER_TO_STAGE: Tuple[Tuple[str, str], ...] = (
    # Cool Bus/N2 fallback markers from the vehicle Design\Location area.
    # Keep these before stale normal-stage markers so a loaded Cool Bus level
    # can override old text that remains from the previous non-vehicle stage.
    ("Dsky2A", "Stage_04_SnotBomber"),
    ("Dsky2B", "Stage_08_Tarpoon"),
    ("Dspace2", "Stage_13_MoonTrip"),
    ("Ltreehs1", "Stage_01_Tutorial"),
    ("Lkitchn1", "Stage_02_Donutty"),
    ("Ltreehs5", "Stage_03_Boogification"),
    ("Lsky2A", "Stage_04_SnotBomber"),
    ("Ltrehs4A", "Stage_05_Spank_Happy"),
    ("Ltreehs3", "Stage_06_Hamsterama"),
    ("Lbkyrd1", "Stage_07_Spankarific"),
    ("Lsky2B", "Stage_08_Tarpoon"),
    ("Lrvnge5", "Stage_09_Ship_Shape"),
    ("Lbkyrd3", "Stage_10_Brush_Off"),
    ("Lcave1", "Stage_11_Cavity_Cave"),
    ("Ltrehs4B", "Stage_12_Overflow"),
    ("Lspace2", "Stage_13_MoonTrip"),
    ("LmoonAll", "Stage_14_Lunarumble"),
    ("Credits", "Stage_15_Credits"),
)

# Current native unlock bytes for received Stage_X_Unlock items. No Stage_01 write.
STAGE_UNLOCK_ADDR: Dict[str, int] = {
    "Stage_02_Donutty_Unlock": 0x8076F4AF,
    "Stage_03_Boogification_Unlock": 0x8076F5BF,
    "Stage_04_SnotBomber_Unlock": 0x8076F4EF,
    "Stage_05_Spank_Happy_Unlock": 0x8076F57F,
    "Stage_06_Hamsterama_Unlock": 0x8076F55F,
    "Stage_07_Spankarific_Unlock": 0x8076F44F,
    "Stage_08_Tarpoon_Unlock": 0x8076F50F,
    "Stage_09_Ship_Shape_Unlock": 0x8076F4DF,
    "Stage_10_Brush_Off_Unlock": 0x8076F46F,
    "Stage_11_Cavity_Cave_Unlock": 0x8076F48F,
    "Stage_12_Overflow_Unlock": 0x8076F59F,
    "Stage_13_MoonTrip_Unlock": 0x8076F52F,
    "Stage_14_Lunarumble_Unlock": 0x8076F54F,
    "Stage_15_Credits_Unlock": 0x8076F4CF,
}

# Normal weapon-start flags. Clean v4 keeps these ON to keep 2x4 pieces irrelevant;
# AP permission is enforced by Y blocking where we have stage weapon mirrors.
NORMAL_WEAPON_FLAG: Dict[str, int] = {
    "Gumzooka_Unjammed": 0x8076F4BF,
    "Splanker_Unjammed": 0x8076F58F,
    "Frappe_Unjammed": 0x8076F56F,
    "Scampp_Unjammed": 0x8076F45F,
    "Thumper_Unjammed": 0x8076F47F,
    "Bajooka_Unjammed": 0x8076F49F,
    "Sluggah_Unjammed": 0x8076F5AF,
}

# N2 native 0/1 Secret Menu / Weapons System Online toggles.
N2_WEAPON_SYSTEM_FLAG: Dict[str, Tuple[int, str, str, int]] = {
    "2x4_N2_SnotBomber_Weapons_System_Online": (0x8076F4FF, "2x4_N2_SnotBomber_Progressive_Upgrade", "cb1", 4),
    "2x4_N2_Tarpoon_Weapons_System_Online": (0x8076F51F, "2x4_N2_Tarpoon_Progressive_Upgrade", "cb2", 5),
    "2x4_N2_MoonTrip_Weapons_System_Online": (0x8076F53F, "2x4_N2_MoonTrip_Progressive_Upgrade", "cb3", 5),
}

# N2 actual U32 0..N progressive values.
COOLBUS_PROGRESSIVE_ADDR: Dict[str, Tuple[int, int]] = {
    "2x4_N2_SnotBomber_Progressive_Upgrade": (0x81100AEC, 4),
    "2x4_N2_Tarpoon_Progressive_Upgrade": (0x8118676C, 5),
    "2x4_N2_MoonTrip_Progressive_Upgrade": (0x8117A62C, 5),
}

# Rainbow Monkey tier locations: native value 1/2/3/4 -> location milestones.
MONKEY_TIER_ADDR: Dict[str, int] = {
    "Stage_02_Donutty": 0x8077020F,
    "Stage_03_Boogification": 0x8077030F,
    "Stage_04_SnotBomber": 0x8077023F,
    "Stage_05_Spank_Happy": 0x807702CF,
    "Stage_06_Hamsterama": 0x8077029F,
    "Stage_07_Spankarific": 0x8077012F,
    "Stage_08_Tarpoon": 0x8077024F,
    "Stage_09_Ship_Shape": 0x8077022F,
    "Stage_10_Brush_Off": 0x8077018F,
    "Stage_11_Cavity_Cave": 0x807701CF,
    "Stage_12_Overflow": 0x807702FF,
    "Stage_13_MoonTrip": 0x8077025F,
    "Stage_15_Credits": 0x8077033F,
}

# Rainbow Monkey Capper suppression.
# Base/no capper allows tier 1 (25 monkeys). Each capper raises the allowed tier by 1.
MONKEY_STAGE_OPERATIVE: Dict[str, str] = {
    "Stage_01_Tutorial": "N1",
    "Stage_02_Donutty": "N1",
    "Stage_03_Boogification": "N5",
    "Stage_04_SnotBomber": "N2",
    "Stage_05_Spank_Happy": "N4",
    "Stage_06_Hamsterama": "N3",
    "Stage_07_Spankarific": "N1",
    "Stage_08_Tarpoon": "N2",
    "Stage_09_Ship_Shape": "N5",
    "Stage_10_Brush_Off": "N3",
    "Stage_11_Cavity_Cave": "N1",
    "Stage_12_Overflow": "N4",
    "Stage_13_MoonTrip": "N2",
    "Stage_15_Credits": "N2",
}

MONKEY_CAPPER_ITEM: Dict[str, str] = {
    "N1": "Progressive_Rainbow_Monkey_Capper_N1",
    "N2": "Progressive_Rainbow_Monkey_Capper_N2",
    "N3": "Progressive_Rainbow_Monkey_Capper_N3",
    "N4": "Progressive_Rainbow_Monkey_Capper_N4",
    "N5": "Progressive_Rainbow_Monkey_Capper_N5",
}


# Known one-off secrets and confirmed Sooper Secret outfit-unlock flags.
# Sooper flags are used as AP check triggers. After the check is credited,
# the vanilla outfit flag is reset later on the main-menu signature so the
# client does not clear the pickup before the game/AP watcher can see it.
# N86 is separate and is not listed here.
SOOPER_SECRET_FLAG_LOCATIONS: Dict[str, int] = {
    "Stage_01_Tutorial_SooperSecret": 0x807715B4,
    "Stage_03_Boogification_SooperSecret_1": 0x807716A4,  # Fire_Place
    "Stage_03_Boogification_SooperSecret_2": 0x807716A0,  # DJ_Booth
    "Stage_05_Spank_Happy_SooperSecret": 0x80771650,
    "Stage_06_Hamsterama_SooperSecret": 0x80771600,
    "Stage_07_Spankarific_SooperSecret_1": 0x80771654,
    "Stage_07_Spankarific_SooperSecret_2": 0x807715B0,
}

FLAG_LOCATIONS: Dict[str, Tuple[int, ...]] = {
    "Stage_01_Tutorial_Secret": (0x8077026C,),
    **{loc: (addr,) for loc, addr in SOOPER_SECRET_FLAG_LOCATIONS.items()},
}

# N1 Grappluh sabotage v13.
GRAPPLUH_MISSING_VALUE = 0x00000002
GRAPPLUH_OWNED_RESET_VALUE = 0x00000000
# Some N1 Grappluh runtime sabotage addresses can shift between a small set
# after a full game/Dolphin reload.  Values are write targets for Grappluh only;
# do not mix these with N3/N4 airborne trackers or weapon/Y mirrors.
N1_GRAPPLUH_STAGE: Dict[str, Tuple[str, Tuple[int, ...]]] = {
    "Stage_02_Donutty": ("Lkitchn1", (0x811FCC24, 0x811FD074)),
    "Stage_07_Spankarific": ("Lbkyrd1", (0x8128CF24,)),
    "Stage_11_Cavity_Cave": ("Lcave1", (0x8122BB04,)),
}

# Known weapon mirror stages. Used for Y-blocking and Weapon_Check activation.
@dataclass(frozen=True)
class WeaponProfile:
    stage: str
    marker: str
    item: str
    location: str
    mirror: int

WEAPON_PROFILES: Tuple[WeaponProfile, ...] = (
    WeaponProfile("Stage_02_Donutty", "Lkitchn1", "Gumzooka_Unjammed", "Stage_02_Donutty_Gumzooka_Unjammed", 0x815128CC),
    WeaponProfile("Stage_07_Spankarific", "Lbkyrd1", "Scampp_Unjammed", "Stage_07_Spankarific_Scampp_Unjammed", 0x815129AC),
    WeaponProfile("Stage_11_Cavity_Cave", "Lcave1", "Bajooka_Unjammed", "Stage_11_Cavity_Cave_Bajooka_Unjammed", 0x815127EC),
    WeaponProfile("Stage_06_Hamsterama", "Ltreehs3", "Frappe_Unjammed", "Stage_06_Hamsterama_Frappe_Unjammed", 0x81512894),
    WeaponProfile("Stage_10_Brush_Off", "Lbkyrd3", "Thumper_Unjammed", "Stage_10_Brush_Off_Thumper_Unjammed", 0x81512904),
    WeaponProfile("Stage_05_Spank_Happy", "Ltrehs4A", "Splanker_Unjammed", "Stage_05_Spank_Happy_Splanker_Unjammed", 0x81512974),
    WeaponProfile("Stage_12_Overflow", "Ltrehs4B", "Sluggah_Unjammed", "Stage_12_Overflow_Sluggah_Unjammed", 0x81512824),
)

# Stage 3 / Boogification spare-parts crafting check for N5's Smellmet.
SMELLMET_CRAFTED_LOCATION = "Stage_03_Boogification_Smellmet_Crafted"
SMELLMET_SPARE_PART_ADDRS: Tuple[int, ...] = (
    0x80983C58,
    0x8115CDA0,
    0x815500DC,
    0x81550134,
    0x816A9788,
)
# Native Stage 3 Smellmet/mask flag. Do NOT keep this forced on like a normal gun.
# It should stay 0 until the Stage 3 spare-parts counter reaches 3 (crafted),
# then stay 1 so the crafted Smellmet remains available.
SMELLMET_CRAFTED_FLAG_ADDR = 0x8076F5CF
SMELLMET_CRAFTED_ITEM = "2x4_N5_Boogification_Smellmet_Crafted"
SMELLMET_STAGE_MARKER = "Ltreehs5"


# N3 movement blocker integrated from knd_n3_character_block_v3.
# AP item count:
#   0 Move_N3_Progressive_Movement = single jump only
#   1 Move_N3_Progressive_Movement = double jump, no glide
#   2 Move_N3_Progressive_Movement = full movement
AE48_A_GATE_ADDR = 0x8077AE48
PLAYER_A_VALUE = 0x00000000
A_BLOCK_VALUE = 0x00000001

LOCK_ON_BLOCK_ADDR = 0x8076CE7C
LOCK_ON_BLOCK_VALUE = 0x00000000
LOCK_ON_ALLOW_VALUE = 0x00000001

N3_STABLE_GROUND_SECONDS = 0.150
N3_LAUNCH_GRACE_SECONDS = 0.050
N3_RELEASE_STABLE_SECONDS = 0.015
N3_ALLOWED_TAP_PASS_SECONDS = 0.125
N3_AIRBORNE_TAPS_ALLOWED = 1
# N3 air trackers can produce an occasional non-binary/garbage u32 sample during
# level-load/streaming even when the same address is visibly the correct 0/1 tracker.
# Once latched, tolerate a short invalid burst instead of immediately unlatching.
N3_AIR_INVALID_UNLATCH_SAMPLES = 60
N3_AIR_FALLBACK_VALID_STREAK = 8


@dataclass(frozen=True)
class N3StageProfile:
    key: str
    stage: str
    marker: str
    airborne_addr: int
    glide_addr: int
    glide_block_value: int
    watch_addr: Optional[int] = None
    # Extra (airborne_tracker, glide_block_addr) pairs for stages whose runtime
    # block can land in a small known set of nearby addresses after reloads.
    # Read the airborne tracker; write only the paired glide block address.
    extra_air_glide_pairs: Tuple[Tuple[int, int], ...] = ()

    @property
    def air_glide_pairs(self) -> Tuple[Tuple[int, int], ...]:
        return ((self.airborne_addr, self.glide_addr),) + self.extra_air_glide_pairs


N3_STAGE_PROFILES: Tuple[N3StageProfile, ...] = (
    N3StageProfile(
        key="stage6",
        stage="Stage_06_Hamsterama",
        marker="Ltreehs3",
        airborne_addr=0x81382374,
        glide_addr=0x8138237C,
        glide_block_value=0x00000001,
        watch_addr=0x8136A9CC,
        extra_air_glide_pairs=((0x81381F24, 0x81381F2C),),
    ),
    N3StageProfile(
        key="stage10",
        stage="Stage_10_Brush_Off",
        marker="Lbkyrd3",
        # Run 1/2 testing showed this stage behaves like the Stage 6 style pair:
        # air/read at +0, paired glide/block write at +8.
        airborne_addr=0x8121BCC4,
        glide_addr=0x8121BCCC,
        glide_block_value=0x00000000,
        watch_addr=None,
    ),
)


# N2 gets a hard per-stage Y/fire lock while its AP online/progressive state is missing.
@dataclass(frozen=True)
class N2WeaponProfile:
    stage: str
    marker: str
    online_item: str
    progressive_item: str
    max_value: int


N2_WEAPON_PROFILES: Tuple[N2WeaponProfile, ...] = (
    N2WeaponProfile("Stage_04_SnotBomber", "Lsky2A", "2x4_N2_SnotBomber_Weapons_System_Online", "2x4_N2_SnotBomber_Progressive_Upgrade", 4),
    N2WeaponProfile("Stage_08_Tarpoon", "Lsky2B", "2x4_N2_Tarpoon_Weapons_System_Online", "2x4_N2_Tarpoon_Progressive_Upgrade", 5),
    N2WeaponProfile("Stage_13_MoonTrip", "Lspace2", "2x4_N2_MoonTrip_Weapons_System_Online", "2x4_N2_MoonTrip_Progressive_Upgrade", 5),
)


# N4/N5 movement use the CE50 double/wall-jump gate.
CE50_JUMP_BLOCK_ADDR = 0x8076CE50
CE50_BLOCK_VALUE = 0x00000001
WALL_CONTACT_ADDR = 0x80417C5C

N4_ALT_BLOCK_SECONDS = 6.0
N4_WALL_CONTACT_GRACE_SECONDS = 0.350
N4_POST_WALL_GRACE_SECONDS = 0.900

N5_ALT_BLOCK_SECONDS = 6.0
N5_WALL_CONTACT_GRACE_SECONDS = 0.350
N5_POST_WALL_GRACE_SECONDS = 0.900
N5_WALL_BLOCK_SECONDS = 1.250
N5_EXTEND_WHILE_WALL_CONTACT = True


@dataclass(frozen=True)
class N4StageProfile:
    key: str
    stage: str
    marker: str
    airborne_addrs: Tuple[int, ...]

    @property
    def airborne_addr(self) -> int:
        # First candidate is the preferred/default display address.
        return self.airborne_addrs[0]


# Stage 5 / Spank Happy airborne can move/mirror between a small known candidate
# pool depending on full game/Dolphin load/session state.  This pool is NOT
# assumed complete; it only contains addresses observed so far.  Keep these
# read-only and latch only a usable 0/1 signal that demonstrates a 0->1 jump
# transition when possible.
N4_STAGE5_AIRBORNE_CANDIDATES: Tuple[int, ...] = (
    0x81469754,  # original/v2 address; valid in some runs, stuck at 1 in others
    0x81469304,  # observed after full close/reopen
    0x8146930C,  # mirror/secondary of 0x81469304 in that boot
    0x814ABF44,  # previous valid candidate; flips earlier when valid
    0x814ABF4C,  # previous backup/secondary
)
N4_AIR_LATCH_MIN_VALID_SAMPLES = 8
# Require multiple full grounded->airborne->grounded cycles before latching.
# This prevents one-frame/level-load flickers from being treated as the real air flag.
N4_AIR_LATCH_REQUIRED_CLEAN_CYCLES = 5
# Fallback: if a candidate had a bad/invalid level-load sample, the strict
# invalid==0 clean-cycle latch can refuse it forever even after it becomes the
# obvious real 0/1 air tracker.  If the same proven 0/1 candidate remains the
# best current candidate for 30 consecutive reads, latch it anyway.
N4_AIR_FALLBACK_CONFIRM_SAMPLES = 30
N4_AIR_FALLBACK_REPORT_EVERY = 5
N4_AIR_DISAGREE_RESET_TICKS = 10

N4_STAGE_PROFILES: Tuple[N4StageProfile, ...] = (
    N4StageProfile("stage5", "Stage_05_Spank_Happy", "Ltrehs4A", N4_STAGE5_AIRBORNE_CANDIDATES),
    # Stage 12 / Overflow shifted between these two observed N4 airborne trackers.
    N4StageProfile("stage12", "Stage_12_Overflow", "Ltrehs4B", (0x8135A254, 0x81359E04)),
)


@dataclass(frozen=True)
class N5StageProfile:
    key: str
    stage: str
    marker: str
    airborne_addrs: Tuple[int, ...]


N5_STAGE_PROFILES: Tuple[N5StageProfile, ...] = (
    # Stage 3 / Boogification has now been observed at two airborne read addresses.
    # Keep 0x81309194 first because it is the current valid address from the latest test.
    N5StageProfile("stage3", "Stage_03_Boogification", "Ltreehs5", (0x81309194, 0x813095E4)),
    N5StageProfile("stage9", "Stage_09_Ship_Shape", "Lrvnge5", (0x8123E5D4,)),
)


POLL_LOCATION_SECONDS = 0.10
POLL_BLOCK_SECONDS = 0.004
STATUS_EVERY_SECONDS = 2.0

# ---------------------------------------------------------------------------
# UI / config helpers
# ---------------------------------------------------------------------------

def load_config() -> Dict[str, Any]:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_config(cfg: Dict[str, Any]) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def normalize_server_input(raw: str) -> str:
    """
    Accepts:
      40873
      archipelago.gg:40873
      wss://archipelago.gg:40873
      /connect archipelago.gg:40873
      localhost:38281

    Rules:
      - archipelago.gg defaults to wss://
      - localhost / 127.0.0.1 defaults to ws://
    """
    s = str(raw or "").strip().strip('"').strip("'").strip("<> ,;")
    s = re.sub(r"^\s*/connect\s+", "", s, flags=re.IGNORECASE).strip()

    for prefix in ("Server:", "Address:", "Connect to:", "Connect:", "Room:"):
        if s.lower().startswith(prefix.lower()):
            s = s[len(prefix):].strip()

    # Guard against the old typo from v5/v6 testing.
    s = s.replace("://rchipelago.gg", "://archipelago.gg")
    if s.lower().startswith("rchipelago.gg"):
        s = "archipelago.gg" + s[len("rchipelago.gg"):]

    if re.fullmatch(r"\d{2,5}", s):
        return f"wss://archipelago.gg:{s}"

    if s.startswith(("ws://", "wss://")):
        if "archipelago.gg" in s and s.startswith("ws://"):
            return "wss://" + s[len("ws://"):]
        return s

    if s.startswith("archipelago://"):
        host_port = s[len("archipelago://"):]
        scheme = "ws" if host_port.startswith(("localhost", "127.0.0.1")) else "wss"
        return f"{scheme}://{host_port}"

    m = re.search(r"([A-Za-z0-9.-]+|localhost|127\.0\.0\.1):(\d{2,5})", s)
    if m:
        host, port = m.group(1), m.group(2)
        if host.lower() == "rchipelago.gg":
            host = "archipelago.gg"
        scheme = "ws" if host in ("localhost", "127.0.0.1") else "wss"
        return f"{scheme}://{host}:{port}"

    if "://" not in s:
        scheme = "ws" if s.startswith(("localhost", "127.0.0.1")) else "wss"
        return f"{scheme}://{s}"
    return s


DEFAULT_AP_SERVER_ENTRY = "wss://archipelago.gg:"


def default_connect_entry(saved: str = "") -> str:
    """Default the server entry to the Archipelago hosted-room prefix.

    Hosted AP rooms change the port every seed, so showing the old saved full room
    just makes the user erase/type more. Leave localhost/private servers possible by
    typing the full address manually.
    """
    return DEFAULT_AP_SERVER_ENTRY


def prompt_settings() -> Dict[str, str]:
    cfg = load_config()
    defaults = {
        "connect": default_connect_entry(str(cfg.get("connect", ""))),
        "player": str(cfg.get("player", "")),
        "password": str(cfg.get("password", "")),
        "profile_override": str(cfg.get("profile_override", "")),
        "ap_output_dir": str(cfg.get("ap_output_dir", "")),
        "active_game_dir": str(cfg.get("active_game_dir", str(ACTIVE_GAME_DEFAULT))),
        "archive_runs_dir": str(cfg.get("archive_runs_dir", str(ARCHIVE_RUNS_DEFAULT))),
    }

    if tk is None:
        connect = input(f"Server / AP port / /connect line [{defaults['connect']}]: ").strip() or defaults["connect"]
        player = input(f"Player [{defaults['player']}]: ").strip() or defaults["player"]
        password = input(f"Password [{defaults['password']}]: ").strip() or defaults["password"]
        profile_override = input(f"Profile override (optional) [{defaults['profile_override']}]: ").strip() or defaults["profile_override"]
        ap_output_dir = input(f"AP output folder (optional) [{defaults['ap_output_dir']}]: ").strip() or defaults["ap_output_dir"]
        active_game_dir = input(f"Active Game temp folder [{defaults['active_game_dir']}]: ").strip() or defaults["active_game_dir"]
        archive_runs_dir = input(f"Archived Runs folder [{defaults['archive_runs_dir']}]: ").strip() or defaults["archive_runs_dir"]
        out = {
            "connect": normalize_server_input(connect),
            "player": player,
            "password": password,
            "profile_override": profile_override,
            "ap_output_dir": ap_output_dir,
            "active_game_dir": active_game_dir,
            "archive_runs_dir": archive_runs_dir,
        }
        save_config(out)
        return out

    result: Dict[str, str] = {}
    root = tk.Tk()
    root.title("KND Easy Client Clean v15")
    root.geometry("720x445")
    root.resizable(False, False)
    entries: Dict[str, tk.Entry] = {}
    labels = [
        ("connect", "Server (port, host:port, /connect line, or wss://...)", defaults["connect"]),
        ("player", "Player name", defaults["player"]),
        ("password", "Password (optional)", defaults["password"]),
        ("profile_override", "Profile name override (optional)", defaults["profile_override"]),
        ("ap_output_dir", "AP output folder / spoiler folder (optional)", defaults["ap_output_dir"]),
        ("active_game_dir", "Active Game temp folder", defaults["active_game_dir"]),
        ("archive_runs_dir", "Archived Runs folder", defaults["archive_runs_dir"]),
    ]
    for row, (key, label, value) in enumerate(labels):
        tk.Label(root, text=label, anchor="w").grid(row=row, column=0, sticky="w", padx=12, pady=(12 if row == 0 else 6, 2))
        ent = tk.Entry(root, width=58)
        ent.insert(0, value)
        if key == "password":
            ent.config(show="*")
        ent.grid(row=row, column=1, padx=12, pady=(12 if row == 0 else 6, 2), sticky="ew")
        entries[key] = ent
    tk.Label(root, text="Clean v15: AP + integrated Easy Run + slot-FMV + N1/N2/N3/N4/N5 blockers.", anchor="w", fg="#444").grid(row=7, column=0, columnspan=2, sticky="w", padx=12, pady=(10, 0))

    def start() -> None:
        result.update({k: e.get().strip() for k, e in entries.items()})
        result["connect"] = normalize_server_input(result.get("connect", ""))
        if not result.get("connect") or not result.get("player"):
            if messagebox:
                messagebox.showerror("Missing info", "Server and Player are required.")
            return
        root.destroy()

    def quit_app() -> None:
        root.destroy()
        raise SystemExit(0)

    btn_frame = tk.Frame(root)
    btn_frame.grid(row=8, column=0, columnspan=2, pady=18)
    tk.Button(btn_frame, text="Start", width=16, command=start).pack(side="left", padx=8)
    tk.Button(btn_frame, text="Cancel", width=16, command=quit_app).pack(side="left", padx=8)
    root.mainloop()
    if not result:
        raise SystemExit(0)
    save_config(result)
    return result

# ---------------------------------------------------------------------------
# Persistent client state
# ---------------------------------------------------------------------------

def _slug(text: str, limit: int = 80) -> str:
    safe = "".join(c if c.isalnum() or c in "-_ ." else "_" for c in text).strip().replace(" ", "_")
    return safe[:limit] or "default"


def _seed_fingerprint(roominfo: Dict[str, Any], url: str) -> str:
    raw = str(roominfo.get("seed_name") or roominfo.get("room_id") or roominfo.get("server_address") or url)
    digest = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:10]
    return f"{_slug(raw, 36)}__{digest}"


def _profile_state_path(player: str, seed_key: str, override: str = "") -> Path:
    if override:
        return PROFILE_DIR / f"{_slug(override, 96)}.json"
    return PROFILE_DIR / f"{_slug(player, 40)}__{_slug(seed_key, 60)}.json"


def _load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")



# ---------------------------------------------------------------------------
# Integrated Easy Run: one startup step for AP output -> slot order -> archive.
# ---------------------------------------------------------------------------

def _easy_expand_path(value: str, fallback: Path) -> Path:
    raw = str(value or "").strip().strip('"')
    return Path(os.path.expandvars(raw)).expanduser() if raw else fallback


def _easy_source_signature(path: Path) -> str:
    try:
        st = path.stat()
        return f"{path.resolve()}|{st.st_size}|{int(st.st_mtime)}"
    except Exception:
        return str(path)


def _easy_source_mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except Exception:
        return 0.0


def _easy_ap_run_id_from_text(value: str) -> Optional[str]:
    m = re.search(r"AP[_ -](\d{8,})", str(value), flags=re.IGNORECASE)
    return m.group(1) if m else None


def _easy_safe_name(value: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in str(value))
    return safe[:180] or "run"


def _easy_run_id_for_source(source: Path, spoiler: Optional[Path] = None) -> str:
    for value in (str(spoiler or ""), str(source), source.stem):
        run_id = _easy_ap_run_id_from_text(value)
        if run_id:
            return run_id
    return _easy_safe_name(source.stem)


def _easy_unique_path(dest: Path) -> Path:
    if not dest.exists():
        return dest
    parent, stem, suffix = dest.parent, dest.stem, dest.suffix
    i = 2
    while True:
        candidate = parent / f"{stem}_{i}{suffix}"
        if not candidate.exists():
            return candidate
        i += 1


def _easy_slot_order_paths() -> List[Path]:
    return [BASE_DIR / "run_knd_slot_order.json", BASE_DIR / "run_knd_slot_order.txt"]


def _easy_copy_slot_order_files_to(folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    for path in _easy_slot_order_paths():
        if path.exists():
            shutil.copy2(path, folder / path.name)


def _easy_archive_existing_slot_order_files(archive_root: Path) -> None:
    existing = [p for p in _easy_slot_order_paths() if p.exists()]
    if not existing:
        return
    old_run_id: Optional[str] = None
    json_path = BASE_DIR / "run_knd_slot_order.json"
    if json_path.exists():
        with contextlib.suppress(Exception):
            old_data = json.loads(json_path.read_text(encoding="utf-8"))
            old_run_id = _easy_ap_run_id_from_text(str(old_data.get("source_spoiler", "")))
    old_run_id = old_run_id or "previous_unknown"
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = archive_root / old_run_id / "slot_order_backup"
    backup_dir.mkdir(parents=True, exist_ok=True)
    for path in existing:
        shutil.copy2(path, backup_dir / f"{path.stem}_{stamp}{path.suffix}")
    print(f"[EASY RUN] Previous slot order backed up -> {backup_dir}")


def _easy_is_inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except Exception:
        return False


def _easy_is_knd_spoiler_text(text: str) -> bool:
    return (
        GAME_NAME in text
        or "KND V1 Slot / Canon Routing Notes" in text
        or "Stage_14_Lunarumble_Complete: Victory" in text
        or "Stage_01_Tutorial_Unlock" in text
        or "Stage_09_Ship_Shape_Unlock" in text
        or re.search(r"Stage_\d{2}_[A-Za-z_]+_Unlock", text) is not None
    )


def _easy_find_knd_spoiler_in_folder(folder: Path) -> Optional[Path]:
    txts = list(folder.rglob("*.txt"))
    txts.sort(key=lambda p: (0 if "spoiler" in p.name.lower() else 1, str(p).lower()))
    for txt in txts:
        try:
            content = txt.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        if _easy_is_knd_spoiler_text(content):
            return txt
    return None


def _easy_extract_zip_to_active(zip_path: Path, active_root: Path) -> Path:
    active_root.mkdir(parents=True, exist_ok=True)
    extract_root = active_root / _easy_run_id_for_source(zip_path)
    if extract_root.exists():
        shutil.rmtree(extract_root, ignore_errors=True)
    extract_root.mkdir(parents=True, exist_ok=True)
    root_resolved = extract_root.resolve()
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            member_name = info.filename.replace("\\", "/").lstrip("/")
            if not member_name:
                continue
            dest = (extract_root / member_name).resolve()
            try:
                dest.relative_to(root_resolved)
            except ValueError:
                print(f"[EASY RUN] Skipped unsafe ZIP member: {info.filename}")
                continue
            if info.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(info))
    return extract_root


def _easy_copy_loose_spoiler_to_active(txt_path: Path, active_root: Path) -> Path:
    active_root.mkdir(parents=True, exist_ok=True)
    extract_root = active_root / _easy_run_id_for_source(txt_path, txt_path)
    if extract_root.exists():
        shutil.rmtree(extract_root, ignore_errors=True)
    extract_root.mkdir(parents=True, exist_ok=True)
    shutil.copy2(txt_path, extract_root / txt_path.name)
    return extract_root


def _easy_archive_extracted_folder(extract_root: Path, archive_root: Path, run_id: str) -> Path:
    archive_root.mkdir(parents=True, exist_ok=True)
    dest = _easy_unique_path(archive_root / run_id)
    shutil.move(str(extract_root), str(dest))
    return dest


def _easy_discover_sources(output_root: Path, active_root: Path, archive_root: Path) -> List[Path]:
    if output_root.is_file():
        return [output_root] if output_root.suffix.lower() in {".zip", ".txt"} else []
    if not output_root.exists() or not output_root.is_dir():
        return []
    sources: List[Path] = []
    for path in output_root.rglob("*"):
        if not path.is_file():
            continue
        if _easy_is_inside(path, active_root) or _easy_is_inside(path, archive_root):
            continue
        parts = {part.lower() for part in path.parts}
        if "archived games" in parts or "archived runs" in parts or ".knd_client_state" in parts:
            continue
        if path.suffix.lower() in {".zip", ".txt"}:
            sources.append(path)
    sources.sort(key=_easy_source_mtime, reverse=True)
    return sources


def _easy_process_source(source: Path, active_root: Path, archive_root: Path) -> Optional[Dict[str, Any]]:
    print(f"[EASY RUN] Checking {source}")
    extract_root: Optional[Path] = None
    try:
        if source.suffix.lower() == ".zip":
            extract_root = _easy_extract_zip_to_active(source, active_root)
            print(f"[EASY RUN] Extracted {source.name} -> {extract_root}")
            spoiler = _easy_find_knd_spoiler_in_folder(extract_root)
        elif source.suffix.lower() == ".txt":
            extract_root = _easy_copy_loose_spoiler_to_active(source, active_root)
            print(f"[EASY RUN] Copied {source.name} -> {extract_root}")
            spoiler = _easy_find_knd_spoiler_in_folder(extract_root)
        else:
            return None

        if spoiler is None:
            print(f"[EASY RUN] No KND spoiler found in {source.name}")
            if extract_root and extract_root.exists():
                shutil.rmtree(extract_root, ignore_errors=True)
            return None

        spoiler_text = spoiler.read_text(encoding="utf-8", errors="replace")
        unlock_order = _parse_unlock_order_from_spoiler(spoiler_text)
        if not unlock_order:
            print(f"[EASY RUN] KND spoiler found, but no Stage unlock order was parsed: {spoiler}")
            return None

        slot_to_stage = _build_slot_order_from_unlock_order(unlock_order)
        run_id = _easy_run_id_for_source(source, spoiler)
        _easy_archive_existing_slot_order_files(archive_root)
        _write_generated_slot_order(slot_to_stage, unlock_order, spoiler)
        if extract_root:
            _easy_copy_slot_order_files_to(extract_root)
        print("[EASY RUN] Built run_knd_slot_order.json/txt")

        archived_to = ""
        if extract_root and extract_root.exists():
            archived_path = _easy_archive_extracted_folder(extract_root, archive_root, run_id)
            _easy_copy_slot_order_files_to(archived_path)
            archived_to = str(archived_path)
            print(f"[EASY RUN] Archived extracted AP run -> {archived_path}")

        return {
            "source": str(source),
            "signature": _easy_source_signature(source),
            "source_mtime": _easy_source_mtime(source),
            "run_id": run_id,
            "spoiler": str(spoiler),
            "archived_extracted_to": archived_to,
            "processed_at": time.time(),
        }
    except Exception as e:
        print(f"[EASY RUN] ERROR while processing {source}: {e}")
        if extract_root and extract_root.exists():
            shutil.rmtree(extract_root, ignore_errors=True)
        return None


def integrated_easy_run_prepare(ap_output_dir: str, active_game_dir: str = "", archive_runs_dir: str = "") -> bool:
    """
    One-shot version of knd_easy_run_v2 baked into the Easy Client.

    It finds the newest AP zip/txt in the configured AP output folder, extracts/copies it
    to Active Game, builds run_knd_slot_order.json/txt, then moves that extracted folder
    to Archived Runs. It skips exact source signatures already processed.
    """
    if not str(ap_output_dir or "").strip():
        return False

    output_root = _easy_expand_path(ap_output_dir, Path(""))
    active_root = _easy_expand_path(active_game_dir, ACTIVE_GAME_DEFAULT)
    archive_root = _easy_expand_path(archive_runs_dir, ARCHIVE_RUNS_DEFAULT)

    if not output_root.exists():
        print(f"[EASY RUN] AP output path does not exist yet: {output_root}")
        return False

    active_root.mkdir(parents=True, exist_ok=True)
    archive_root.mkdir(parents=True, exist_ok=True)

    state = _load_json(EASY_RUN_STATE_PATH)
    processed: Set[str] = set(str(x) for x in state.get("processed_signatures", []))
    last_mtime = float(state.get("last_processed_mtime", 0.0))
    slot_order_missing = not (BASE_DIR / "run_knd_slot_order.json").exists()

    sources = _easy_discover_sources(output_root, active_root, archive_root)
    candidates = [
        src for src in sources
        if (slot_order_missing or _easy_source_mtime(src) >= last_mtime)
        and _easy_source_signature(src) not in processed
    ]
    if not candidates:
        return False

    for source in candidates:
        sig = _easy_source_signature(source)
        result = _easy_process_source(source, active_root, archive_root)
        processed.add(sig)
        if result:
            state["last_processed"] = result
            state["last_processed_mtime"] = max(last_mtime, float(result.get("source_mtime", 0.0)))
            state["processed_signatures"] = sorted(processed)
            _save_json(EASY_RUN_STATE_PATH, state)
            return True

    state["processed_signatures"] = sorted(processed)
    _save_json(EASY_RUN_STATE_PATH, state)
    return False

def ensure_state(profile_path: Path) -> Dict[str, Any]:
    st = _load_json(profile_path)
    if "uuid" not in st:
        st["uuid"] = str(uuidlib.uuid4())
    st.setdefault("last_item_index", -1)
    st.setdefault("sent_location_names", [])
    st.setdefault("received_items", [])
    st.setdefault("manual_counts", {})
    _save_json(profile_path, st)
    return st

# ---------------------------------------------------------------------------
# Dolphin memory wrapper
# ---------------------------------------------------------------------------

class DolphinRW:
    def __init__(self) -> None:
        self._hooked = False

    def ensure_hooked(self) -> bool:
        try:
            if hasattr(dme, "is_hooked") and dme.is_hooked():
                self._hooked = True
                return True
            dme.hook()
            self._hooked = bool(dme.is_hooked()) if hasattr(dme, "is_hooked") else True
            return self._hooked
        except Exception:
            self._hooked = False
            return False

    def read_u8(self, addr: int) -> int:
        return int(dme.read_bytes(addr, 1)[0])

    def read_u32(self, addr: int) -> int:
        return int.from_bytes(bytes(dme.read_bytes(addr, 4)), "big")

    def read_bytes(self, addr: int, size: int) -> bytes:
        return bytes(dme.read_bytes(addr, size))

    def write_u8(self, addr: int, value: int) -> None:
        dme.write_bytes(addr, bytes([value & 0xFF]))

    def write_u32(self, addr: int, value: int) -> None:
        dme.write_bytes(addr, int(value & 0xFFFFFFFF).to_bytes(4, "big"))

    def write_bytes(self, addr: int, data: bytes) -> None:
        dme.write_bytes(addr, bytes(data))

# ---------------------------------------------------------------------------
# Roadmap pusher / reader
# ---------------------------------------------------------------------------

def _asciiish(raw: bytes) -> str:
    return "".join(chr(b) if 32 <= b <= 126 else "." for b in raw)


def _normalize_slot_order(raw: Any) -> Optional[Dict[int, str]]:
    if isinstance(raw, dict):
        out: Dict[int, str] = {}
        for k, v in raw.items():
            try:
                out[int(k)] = str(v)
            except Exception:
                pass
        return out if out else None
    if isinstance(raw, list):
        return {i + 1: str(v) for i, v in enumerate(raw)}
    return None


def _validate_roadmap_slot_order(slot_to_stage: Dict[int, str]) -> None:
    for slot in range(1, 16):
        if slot not in slot_to_stage:
            raise ValueError(f"roadmap slot order missing slot {slot}")
    stages = list(slot_to_stage.values())
    dupes = sorted({s for s in stages if stages.count(s) > 1})
    if dupes:
        raise ValueError(f"roadmap slot order has duplicate stages: {dupes}")
    unknown = [s for s in stages if s not in STAGE_TO_BYTES]
    if unknown:
        raise ValueError(f"roadmap slot order has unknown stages: {unknown}")
    for slot, expected in ROADMAP_FIXED_SLOT_TO_STAGE.items():
        got = slot_to_stage.get(slot)
        if got != expected:
            raise ValueError(f"roadmap fixed slot {slot} expected {expected}, got {got}")


def _unique_in_order(values: Iterable[str]) -> List[str]:
    seen: Set[str] = set()
    out: List[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out


STAGE_UNLOCK_TO_STAGE = {f"{stage}_Unlock": stage for stage in ALL_ROADMAP_STAGES}

# Native KND stage unlock bytes do not open the stage named by the AP item.
# Testing showed they behave as "the stage in the current/previous slot may open the
# next roadmap slot."  The AP item remains target-stage-named, but the client
# translates it through the current slot order before writing memory.
# Example: if Stage_06 is in Slot 2, receiving Stage_06_Unlock writes the native
# next-slot flag for whatever stage is in Slot 1.
NATIVE_NEXT_UNLOCK_ADDR_BY_STAGE: Dict[str, int] = {
    stage: STAGE_UNLOCK_ADDR[item_name]
    for item_name, stage in STAGE_UNLOCK_TO_STAGE.items()
    if item_name in STAGE_UNLOCK_ADDR
}
# Stage 01/Tutorial does not have a clean direct Stage_01_Unlock byte in the old
# table. Current testing suggests the missing Tutorial next-slot flag is the byte
# that had been treated as the Lunarumble/slot-14 unlock. This is only used when
# Tutorial is the previous slot; Lunarumble itself is fixed final, so it should
# not need to open a later slot in normal AP play.
NATIVE_NEXT_UNLOCK_ADDR_BY_STAGE.setdefault("Stage_01_Tutorial", STAGE_UNLOCK_ADDR["Stage_14_Lunarumble_Unlock"])


def _spoiler_section(text: str, start: str, ends: List[str]) -> str:
    i = text.find(start)
    if i == -1:
        return ""
    i += len(start)
    end_positions = [text.find(e, i) for e in ends if text.find(e, i) != -1]
    j = min(end_positions) if end_positions else len(text)
    return text[i:j]


def _parse_unlock_order_from_spoiler(spoiler_text: str) -> List[str]:
    unlocks: List[str] = []
    for part in (
        _spoiler_section(spoiler_text, "Starting Items:", ["Locations:", "Playthrough:"]),
        _spoiler_section(spoiler_text, "Playthrough:", []),
        _spoiler_section(spoiler_text, "Locations:", ["Playthrough:"]),
    ):
        unlocks.extend(re.findall(r"Stage_\d{2}_[A-Za-z_]+_Unlock", part))
    return _unique_in_order(unlocks)


def _build_slot_order_from_unlock_order(unlock_order: List[str]) -> Dict[int, str]:
    fixed_stages = set(ROADMAP_FIXED_SLOT_TO_STAGE.values())
    ordered: List[str] = []
    for unlock in unlock_order:
        stage = STAGE_UNLOCK_TO_STAGE.get(unlock)
        if stage and stage not in fixed_stages:
            ordered.append(stage)
    for stage in ALL_ROADMAP_STAGES:
        if stage not in fixed_stages:
            ordered.append(stage)
    movable = _unique_in_order([s for s in ordered if s not in fixed_stages])
    if len(movable) != len(MOVABLE_ROADMAP_SLOTS):
        raise ValueError(f"Expected {len(MOVABLE_ROADMAP_SLOTS)} movable stages, got {len(movable)}: {movable}")
    out: Dict[int, str] = dict(ROADMAP_FIXED_SLOT_TO_STAGE)
    for slot, stage in zip(MOVABLE_ROADMAP_SLOTS, movable):
        out[slot] = stage
    out = dict(sorted(out.items()))
    _validate_roadmap_slot_order(out)
    return out


def _write_generated_slot_order(slot_to_stage: Dict[int, str], unlock_order: List[str], source: Path) -> None:
    credits_slot = next((slot for slot, stage in slot_to_stage.items() if stage == "Stage_15_Credits"), None)
    payload = {
        "slot_to_stage": {str(slot): stage for slot, stage in slot_to_stage.items()},
        "fixed_slot_to_stage": {str(slot): stage for slot, stage in ROADMAP_FIXED_SLOT_TO_STAGE.items()},
        "credits_slot": credits_slot,
        "unlock_order_used": unlock_order,
        "source_spoiler": str(source),
        "generated_by": "knd_easy_client_clean_v15.py",
    }
    (BASE_DIR / "run_knd_slot_order.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = ["KND AP Auto Slot Order", "", f"Source Spoiler: {source.name}", ""]
    for slot in range(1, 16):
        stage = slot_to_stage[slot]
        tags: List[str] = []
        if slot in ROADMAP_FIXED_SLOT_TO_STAGE:
            tags.append("FIXED")
        if stage == "Stage_15_Credits":
            tags.append("CREDITS")
        suffix = f" [{' / '.join(tags)}]" if tags else ""
        lines.append(f"Slot {slot:02d}: {stage}{suffix}")
    lines += ["", f"Credits Slot: {credits_slot}", "", "Unlock Order Used:"]
    lines += [f"  {i:02d}. {unlock}" for i, unlock in enumerate(unlock_order, 1)]
    (BASE_DIR / "run_knd_slot_order.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _is_knd_spoiler(path: Path) -> bool:
    try:
        sample = path.read_text(encoding="utf-8", errors="replace")[:50000]
    except Exception:
        return False
    return GAME_NAME in sample or "KND V1 Slot" in sample or "Stage_14_Lunarumble_Complete: Victory" in sample


def _candidate_ap_output_roots(configured_output_dir: str = "") -> List[Path]:
    roots: List[Path] = []
    def add(p: Path) -> None:
        try:
            p = p.expanduser()
        except Exception:
            pass
        if str(p) and p not in roots:
            roots.append(p)
    if configured_output_dir:
        add(Path(os.path.expandvars(configured_output_dir)))
    add(BASE_DIR)
    add(BASE_DIR / "output")
    add(BASE_DIR.parent)
    add(Path.cwd())
    add(Path.home() / "Downloads")
    add(Path.home() / "Documents" / "Archipelago" / "output")
    for env_name in ("APPDATA", "LOCALAPPDATA", "USERPROFILE"):
        env_val = os.environ.get(env_name, "")
        if env_val:
            root = Path(env_val)
            add(root / "Archipelago" / "output")
            add(root / "Archipelago" / "Players")
            add(root / "Archipelago")
    return roots


def _spoiler_candidates_in_root(root: Path) -> List[Path]:
    candidates: List[Path] = []
    if root.is_file():
        return [root] if "Spoiler" in root.name and root.suffix.lower() == ".txt" else []
    if not root.exists() or not root.is_dir():
        return []
    for pattern in ("AP_*_Spoiler.txt", "*Spoiler*.txt"):
        candidates.extend(root.glob(pattern))
    try:
        for child in root.iterdir():
            if child.is_dir():
                for pattern in ("AP_*_Spoiler.txt", "*Spoiler*.txt"):
                    candidates.extend(child.glob(pattern))
    except Exception:
        pass
    return candidates


def _find_latest_knd_spoiler(configured_output_dir: str = "") -> Optional[Path]:
    found: List[Path] = []
    seen: Set[Path] = set()
    for root in _candidate_ap_output_roots(configured_output_dir):
        for path in _spoiler_candidates_in_root(root):
            if path in seen:
                continue
            seen.add(path)
            if _is_knd_spoiler(path):
                found.append(path)
    return max(found, key=lambda p: p.stat().st_mtime) if found else None


def resolve_roadmap_slot_order(slot_data: Any, configured_output_dir: str = "") -> Tuple[Optional[Dict[int, str]], str]:
    spoiler = _find_latest_knd_spoiler(configured_output_dir)
    if spoiler:
        txt = spoiler.read_text(encoding="utf-8", errors="replace")
        unlock_order = _parse_unlock_order_from_spoiler(txt)
        if unlock_order:
            order = _build_slot_order_from_unlock_order(unlock_order)
            _write_generated_slot_order(order, unlock_order, spoiler)
            return order, f"auto-built from AP spoiler: {spoiler.name}"
    if isinstance(slot_data, dict):
        for key in ("slot_to_stage", "roadmap_slot_order", "stage_slot_order", "knd_slot_order", "slot_order"):
            if key in slot_data:
                order = _normalize_slot_order(slot_data.get(key))
                if order:
                    _validate_roadmap_slot_order(order)
                    return order, "AP slot_data fallback"
    path = BASE_DIR / "run_knd_slot_order.json"
    if path.exists():
        data = _load_json(path)
        order = _normalize_slot_order(data.get("slot_to_stage")) if isinstance(data, dict) else None
        if order:
            _validate_roadmap_slot_order(order)
            return order, "existing run_knd_slot_order.json fallback"
    return None, ""


class RoadmapPusher:
    def __init__(self, rw: DolphinRW, slot_to_stage: Dict[int, str], source: str):
        self.rw = rw
        self.slot_to_stage = slot_to_stage
        self.source = source

    def _wanted_for_slot(self, slot: int) -> bytes:
        return STAGE_TO_BYTES[self.slot_to_stage[slot]]

    def _looks_like_knd_table(self) -> bool:
        try:
            probe = self.rw.read_bytes(0x80765E68, 4)
            return probe == b"FMV0" or probe.startswith(b"FMV")
        except Exception:
            return False

    def write_once(self) -> int:
        changed = 0
        for slot in range(1, 16):
            addr = ROADMAP_SLOT_ROW[slot] + ROADMAP_NAME_OFFSET
            wanted = self._wanted_for_slot(slot)
            try:
                current = self.rw.read_bytes(addr, ROADMAP_NAME_SIZE)
            except Exception:
                continue
            if current != wanted:
                self.rw.write_bytes(addr, wanted)
                changed += 1
        return changed

    async def run_loop(self) -> None:
        log.info(f"[ROADMAP] Slot order source: {self.source}")
        fast_until = asyncio.get_running_loop().time() + 30.0
        wrote_once = False
        while True:
            try:
                if not self.rw.ensure_hooked():
                    await asyncio.sleep(0.5)
                    continue
                if not self._looks_like_knd_table():
                    await asyncio.sleep(0.5)
                    continue
                changed = self.write_once()
                if changed or not wrote_once:
                    log.info(f"[ROADMAP] Applied slot order ({changed} field(s) changed).")
                    wrote_once = True
                await asyncio.sleep(0.25 if asyncio.get_running_loop().time() < fast_until else 5.0)
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.info(f"[ROADMAP] Waiting/retry after error: {e}")
                await asyncio.sleep(1.0)


def read_current_slot_order(rw: DolphinRW) -> Optional[Dict[int, str]]:
    try:
        out: Dict[int, str] = {}
        for slot, row in ROADMAP_SLOT_ROW.items():
            raw = rw.read_bytes(row + ROADMAP_NAME_OFFSET, ROADMAP_NAME_SIZE)
            stage = BYTES_TO_STAGE.get(raw)
            if not stage:
                return None
            out[slot] = stage
        return out
    except Exception:
        return None


def find_current_fmv(rw: DolphinRW) -> Optional[int]:
    raw = rw.read_bytes(VIDEO_BUFFER_START, VIDEO_BUFFER_SIZE)
    for i in range(1, 17):
        if f"FMV{i:02d}".encode("ascii") in raw:
            return i
    return None


def active_stage_markers(rw: DolphinRW) -> str:
    chunks: List[str] = []
    for start, size in (
        (COOLBUS_TEXT_SCAN_START, COOLBUS_TEXT_SCAN_SIZE),
        (LEVEL_TEXT_SCAN_START, LEVEL_TEXT_SCAN_SIZE),
    ):
        try:
            chunks.append(rw.read_bytes(start, size).decode("latin-1", errors="ignore"))
        except Exception:
            continue
    return "\n".join(chunks)


def active_stage_from_text(text: str) -> Optional[str]:
    for marker, stage in LEVEL_MARKER_TO_STAGE:
        if marker in text:
            return stage
    return None


def _stage_text_present(text: str, stage: str, primary_marker: str = "") -> bool:
    if primary_marker and primary_marker in text:
        return True
    return any(marker in text and mapped_stage == stage for marker, mapped_stage in LEVEL_MARKER_TO_STAGE)


def active_stage_name(rw: DolphinRW) -> Optional[str]:
    return active_stage_from_text(active_stage_markers(rw))


def main_menu_signature_present(rw: DolphinRW) -> bool:
    try:
        raw = rw.read_bytes(MAIN_MENU_TEXT_SCAN_START, MAIN_MENU_TEXT_SCAN_SIZE)
    except Exception:
        return False
    text = raw.decode("latin-1", errors="ignore")
    # currentIndex_MainMenu is the strongest marker. The others are kept as a
    # fallback because this block can be slightly noisy depending on when the
    # client attaches.
    if "currentIndex_MainMenu" in text:
        return True
    return sum(1 for marker in MAIN_MENU_TEXT_MARKERS if marker in text) >= 2


def mirror_active(rw: DolphinRW, addr: int) -> bool:
    try:
        return rw.read_u8(addr) == 1 or rw.read_u32(addr) == 1
    except Exception:
        return False

# ---------------------------------------------------------------------------
# Item state + memory applier/blocker
# ---------------------------------------------------------------------------

class ItemState:
    def __init__(self, names: Iterable[str]):
        self.counts = Counter(names)

    def add(self, name: str) -> None:
        self.counts[name] += 1

    def has(self, name: str, count: int = 1) -> bool:
        return self.counts[name] >= count

    def count(self, name: str) -> int:
        return self.counts[name]

    def names(self) -> List[str]:
        out: List[str] = []
        for name, count in self.counts.items():
            out.extend([name] * count)
        return out



class N3MovementController:
    def __init__(self, rw: DolphinRW, item_state: ItemState):
        self.rw = rw
        self.items = item_state

        self.active_key: Optional[str] = None
        self.last_air: Optional[int] = None
        self.previous_air_for_transition: Optional[int] = None
        self.grounded_since: Optional[float] = None
        self.movement_armed = False

        self.airborne_session_active = False
        self.airborne_started_at = 0.0

        self.airborne_taps_used = 0
        self.armed_for_new_airborne_tap = False
        self.release_seen_at: Optional[float] = None
        self.allowed_tap_pass_until = 0.0

        self._last_status = 0.0
        self._last_report: Optional[Tuple[str, int, str]] = None
        self._last_l_allowed: Optional[bool] = None
        self.latched_air_addr: Optional[int] = None
        self.latched_glide_addr: Optional[int] = None
        self.air_candidate_stats: Dict[int, Dict[str, int]] = {}

    @staticmethod
    def _mode_for_count(count: int) -> str:
        if count <= 0:
            return "single_jump_only"
        if count == 1:
            return "double_jump_no_glide_1tap"
        return "full_movement"

    def reset_runtime(self) -> None:
        self.last_air = None
        self.previous_air_for_transition = None
        self.grounded_since = None
        self.movement_armed = False
        self.airborne_session_active = False
        self.airborne_started_at = 0.0
        self.airborne_taps_used = 0
        self.armed_for_new_airborne_tap = False
        self.release_seen_at = None
        self.allowed_tap_pass_until = 0.0
        self.latched_air_addr = None
        self.latched_glide_addr = None
        self.air_candidate_stats = {}

    def on_received_n3_movement(self) -> None:
        count = min(self.items.count("Move_N3_Progressive_Movement"), 2)
        mode = self._mode_for_count(count)
        self.reset_runtime()
        print(f"[N3] Move_N3_Progressive_Movement count is now {count}/2 ({mode}). Movement runtime reset.")

    def _detect_profile(self, text: str) -> Optional[N3StageProfile]:
        for profile in N3_STAGE_PROFILES:
            if profile.marker in text:
                return profile
        return None

    def _stat_for_air_addr(self, addr: int) -> Dict[str, int]:
        return self.air_candidate_stats.setdefault(
            addr,
            {
                "valid": 0,
                "invalid": 0,
                "seen0": 0,
                "seen1": 0,
                "saw01": 0,
                "clean_cycles": 0,
                "armed_landing": 0,
                "valid_streak": 0,
                "invalid_streak": 0,
                "last": -1,
            },
        )

    def _choose_air_glide_pair(
        self,
        profile: N3StageProfile,
        latest: Dict[int, int],
        glide_by_air: Dict[int, int],
    ) -> Optional[Tuple[int, int]]:
        strict_usable: List[int] = []
        fallback_usable: List[int] = []
        for air_addr, _glide_addr in profile.air_glide_pairs:
            value = latest.get(air_addr)
            stats = self._stat_for_air_addr(air_addr)
            if value not in (0, 1) or stats["valid"] < 2:
                continue
            if stats["invalid"] == 0:
                strict_usable.append(air_addr)
            # Safe fallback for Stage 6/10 candidate pools: if an address had a
            # transient invalid/string-like sample but is now repeatedly reading
            # 0/1 and has shown grounded 0, do not permanently disqualify it.
            elif stats.get("valid_streak", 0) >= N3_AIR_FALLBACK_VALID_STREAK and stats.get("seen0"):
                fallback_usable.append(air_addr)

        usable = strict_usable or fallback_usable
        if not usable:
            return None

        # Best proof: this candidate has shown an actual grounded->airborne transition.
        for air_addr in usable:
            stats = self._stat_for_air_addr(air_addr)
            if stats.get("saw01"):
                return air_addr, glide_by_air[air_addr]

        # Safe baseline fallback: allow a stable grounded candidate so the grounded
        # arming logic can start, but switch away later if another candidate proves 0->1.
        for air_addr in usable:
            if latest.get(air_addr) == 0:
                return air_addr, glide_by_air[air_addr]

        return None

    def _read_latched_air_and_glide(self, profile: N3StageProfile) -> Optional[Tuple[int, int, int]]:
        latest: Dict[int, int] = {}
        glide_by_air: Dict[int, int] = {}

        for air_addr, glide_addr in profile.air_glide_pairs:
            glide_by_air[air_addr] = glide_addr
            try:
                value = self.rw.read_u32(air_addr)
            except Exception:
                continue

            latest[air_addr] = value
            stats = self._stat_for_air_addr(air_addr)
            prev = stats.get("last", -1)
            if prev == 0 and value == 1:
                stats["saw01"] = 1
            stats["last"] = value
            if value in (0, 1):
                stats["valid"] += 1
                stats["valid_streak"] = stats.get("valid_streak", 0) + 1
                stats["invalid_streak"] = 0
                if value == 0:
                    stats["seen0"] = 1
                else:
                    stats["seen1"] = 1
            else:
                stats["invalid"] += 1
                stats["valid_streak"] = 0
                stats["invalid_streak"] = stats.get("invalid_streak", 0) + 1

        if not latest:
            return None

        # If the latched pair has a transient non-binary sample, keep the
        # latch. Stage 6 can briefly show values like 1496 on the correct
        # 0x81382374 tracker during streaming/load, then return to clean 0/1.
        # Only drop the latch after a long consecutive invalid streak.
        if self.latched_air_addr is not None:
            selected_value = latest.get(self.latched_air_addr)
            latched_stats = self._stat_for_air_addr(self.latched_air_addr)
            if selected_value not in (0, 1):
                invalid_streak = latched_stats.get("invalid_streak", 0)
                if invalid_streak >= N3_AIR_INVALID_UNLATCH_SAMPLES:
                    print(
                        f"[N3 AIR LATCH] 0x{self.latched_air_addr:08X} stayed invalid "
                        f"({selected_value}) for {invalid_streak} samples; reselecting."
                    )
                    self.latched_air_addr = None
                    self.latched_glide_addr = None
                else:
                    if invalid_streak in (1, 10, 30):
                        print(
                            f"[N3 AIR HOLD] 0x{self.latched_air_addr:08X} transient invalid "
                            f"({selected_value}); keeping latch {invalid_streak}/{N3_AIR_INVALID_UNLATCH_SAMPLES}."
                        )
                    return None
            else:
                # If another candidate has proven both 0 and 1 and the latched one has not,
                # switch to the proven candidate. This catches stale/stuck old addresses.
                latched_proven = bool(latched_stats.get("saw01"))
                if not latched_proven:
                    for air_addr, glide_addr in profile.air_glide_pairs:
                        if air_addr == self.latched_air_addr:
                            continue
                        stats = self._stat_for_air_addr(air_addr)
                        if stats.get("saw01"):
                            print(
                                f"[N3 AIR LATCH] switching from 0x{self.latched_air_addr:08X} "
                                f"to 0->1 proven candidate 0x{air_addr:08X}."
                            )
                            self.latched_air_addr = air_addr
                            self.latched_glide_addr = glide_addr
                            break

        if self.latched_air_addr is None or self.latched_glide_addr is None:
            chosen = self._choose_air_glide_pair(profile, latest, glide_by_air)
            if chosen is None:
                return None
            self.latched_air_addr, self.latched_glide_addr = chosen
            candidate_report = ", ".join(
                f"0x{air_addr:08X}={latest.get(air_addr, '??') if not isinstance(latest.get(air_addr), int) else f'{latest[air_addr]:08X}'}"
                for air_addr, _glide_addr in profile.air_glide_pairs
            )
            print(
                f"[N3 AIR LATCH] {profile.stage}: selected air 0x{self.latched_air_addr:08X} "
                f"-> glide 0x{self.latched_glide_addr:08X}; candidates: {candidate_report}"
            )

        selected_value = latest.get(self.latched_air_addr)
        if selected_value not in (0, 1):
            return None
        return self.latched_air_addr, self.latched_glide_addr, selected_value

    def tick(self, text: str) -> None:
        profile = self._detect_profile(text)
        if profile is None:
            if self.active_key is not None:
                print("[N3] Left supported N3 movement stage.")
            self.active_key = None
            self.reset_runtime()
            return

        if profile.key != self.active_key:
            self.active_key = profile.key
            self.reset_runtime()
            pair_list = ", ".join(
                f"air 0x{air:08X}->glide 0x{glide:08X}"
                for air, glide in profile.air_glide_pairs
            )
            print(
                f"[N3] Active movement profile: {profile.stage} "
                f"pairs=[{pair_list}], glide_value={profile.glide_block_value:08X}"
            )

        count = min(self.items.count("Move_N3_Progressive_Movement"), 2)
        mode = self._mode_for_count(count)

        report = (profile.key, count, mode)
        if report != self._last_report:
            print(f"[N3] Movement count {count}/2 -> {mode}")
            self._last_report = report

        # Lock-on/L is intentionally blocked until full N3 movement.
        if count < 2:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
            if self._last_l_allowed is not False:
                print(f"[N3 L BLOCK] count={count}/2; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_BLOCK_VALUE:08X}")
                self._last_l_allowed = False
        else:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_ALLOW_VALUE)
            if self._last_l_allowed is not True:
                print(f"[N3 L ALLOW] count=2/2; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_ALLOW_VALUE:08X}")
                self._last_l_allowed = True

        if mode == "full_movement":
            # Stop movement writes. Clear AE48 once in case we were previously holding it blocked.
            with contextlib.suppress(Exception):
                self.rw.write_u32(AE48_A_GATE_ADDR, PLAYER_A_VALUE)
            self.reset_runtime()
            return

        now = time.time()

        try:
            air_read = self._read_latched_air_and_glide(profile)
            ae48_value = self.rw.read_u32(AE48_A_GATE_ADDR)
        except Exception:
            return

        if air_read is None:
            # Wait until one of the candidate air trackers is stable enough. Do not write A/glide.
            return

        air_addr, glide_addr, air_value = air_read
        airborne = (air_value == 1)
        grounded = (air_value == 0)
        player_a = (ae48_value == PLAYER_A_VALUE)

        if air_value != self.last_air or air_addr != self.latched_air_addr:
            state = "AIRBORNE" if airborne else "GROUNDED" if grounded else "UNKNOWN"
            print(f"[N3 AIR] {profile.stage}: 0x{air_addr:08X} = {air_value:08X} ({state})")
            self.last_air = air_value

        # Grounded arming fix from N3 v3: never start writing until we see a clean grounded baseline.
        if grounded:
            if self.grounded_since is None:
                self.grounded_since = now
            elif not self.movement_armed and now - self.grounded_since >= N3_STABLE_GROUND_SECONDS:
                self.movement_armed = True
                print("[N3 ARM] Clean grounded baseline seen. Movement blocker armed.")
        else:
            self.grounded_since = None

        air_transition_0_to_1 = (self.previous_air_for_transition == 0 and air_value == 1)
        self.previous_air_for_transition = air_value

        if self.movement_armed and airborne and not self.airborne_session_active and air_transition_0_to_1:
            self.airborne_session_active = True
            self.airborne_started_at = now
            self.airborne_taps_used = 0
            self.armed_for_new_airborne_tap = False
            self.release_seen_at = None
            self.allowed_tap_pass_until = 0.0
            print("[N3 SESSION] Airborne session started.")

        if grounded and self.airborne_session_active:
            self.airborne_session_active = False
            self.airborne_taps_used = 0
            self.armed_for_new_airborne_tap = False
            self.release_seen_at = None
            self.allowed_tap_pass_until = 0.0
            print("[N3 SESSION] Landed. Session reset.")

        should_block_ae48 = False
        should_block_glide = False

        if self.movement_armed:
            if mode == "single_jump_only":
                should_block_glide = self.airborne_session_active
                if self.airborne_session_active and (now - self.airborne_started_at >= N3_LAUNCH_GRACE_SECONDS):
                    should_block_ae48 = True

            elif mode == "double_jump_no_glide_1tap":
                should_block_glide = self.airborne_session_active

                if self.airborne_session_active:
                    if not self.armed_for_new_airborne_tap:
                        if not player_a:
                            if self.release_seen_at is None:
                                self.release_seen_at = now
                            elif now - self.release_seen_at >= N3_RELEASE_STABLE_SECONDS:
                                self.armed_for_new_airborne_tap = True
                                self.release_seen_at = None
                                print("[N3 ARM] Airborne A release stable; next A tap can count.")
                        else:
                            self.release_seen_at = None

                    if self.armed_for_new_airborne_tap and player_a:
                        self.airborne_taps_used += 1
                        self.armed_for_new_airborne_tap = False
                        self.release_seen_at = None

                        if self.airborne_taps_used <= N3_AIRBORNE_TAPS_ALLOWED:
                            self.allowed_tap_pass_until = now + N3_ALLOWED_TAP_PASS_SECONDS
                            print(f"[N3 A TAP] Allowed airborne tap {self.airborne_taps_used}/{N3_AIRBORNE_TAPS_ALLOWED}.")
                        else:
                            print(f"[N3 A TAP] Blocking extra airborne tap {self.airborne_taps_used}/{N3_AIRBORNE_TAPS_ALLOWED}.")

                    in_allowed_pass = now < self.allowed_tap_pass_until
                    if not in_allowed_pass and self.airborne_taps_used >= N3_AIRBORNE_TAPS_ALLOWED:
                        should_block_ae48 = True

        if should_block_glide:
            self.rw.write_u32(glide_addr, profile.glide_block_value)

        if should_block_ae48:
            self.rw.write_u32(AE48_A_GATE_ADDR, A_BLOCK_VALUE)




class N4MovementController:
    def __init__(self, rw: DolphinRW, item_state: ItemState):
        self.rw = rw
        self.items = item_state
        self.active_key: Optional[str] = None
        self.last_air: Optional[int] = None
        self.last_air_addr: Optional[int] = None
        self.last_wall: Optional[int] = None
        self.airborne_session_active = False
        self.airborne_session_handled = False
        self.airborne_block_started_at = 0.0
        self.wall_grace_until = 0.0
        self._last_report: Optional[Tuple[str, bool]] = None
        self._last_l_allowed: Optional[bool] = None
        self.latched_air_addr: Optional[int] = None
        self.latched_glide_addr: Optional[int] = None
        self.air_candidate_stats: Dict[int, Dict[str, int]] = {}
        self.latched_air_addr: Optional[int] = None
        self.air_candidate_stats: Dict[int, Dict[str, int]] = {}
        self.air_latch_disagree_ticks = 0
        self.fallback_candidate_addr: Optional[int] = None
        self.fallback_candidate_streak = 0

    def reset_runtime(self) -> None:
        self.last_air = None
        self.last_air_addr = None
        self.last_wall = None
        self.airborne_session_active = False
        self.airborne_session_handled = False
        self.airborne_block_started_at = 0.0
        self.wall_grace_until = 0.0
        self.latched_air_addr = None
        self.air_candidate_stats = {}
        self.air_latch_disagree_ticks = 0
        self.fallback_candidate_addr = None
        self.fallback_candidate_streak = 0

    def on_received_n4_double(self) -> None:
        self.reset_runtime()
        print("[N4] Move_N4_DoubleJump owned. N4 movement runtime reset.")

    def _detect_profile(self, text: str) -> Optional[N4StageProfile]:
        for profile in N4_STAGE_PROFILES:
            if profile.marker in text:
                return profile
        return None

    def _stat_for_air_addr(self, addr: int) -> Dict[str, int]:
        return self.air_candidate_stats.setdefault(
            addr,
            {
                "valid": 0,
                "invalid": 0,
                "seen0": 0,
                "seen1": 0,
                "saw01": 0,
                "clean_cycles": 0,
                "armed_landing": 0,
                "valid_streak": 0,
                "last": -1,
            },
        )

    @staticmethod
    def _majority_air_value(latest: Dict[int, int]) -> Optional[int]:
        valid_values = [v for v in latest.values() if v in (0, 1)]
        if not valid_values:
            return None
        zeros = valid_values.count(0)
        ones = valid_values.count(1)
        if zeros > len(valid_values) / 2:
            return 0
        if ones > len(valid_values) / 2:
            return 1
        return None

    def _choose_air_addr(self, profile: N4StageProfile, latest: Dict[int, int]) -> Optional[int]:
        usable: List[int] = []
        for addr in profile.airborne_addrs:
            value = latest.get(addr)
            stats = self._stat_for_air_addr(addr)
            if (
                value in (0, 1)
                and stats["valid"] >= N4_AIR_LATCH_MIN_VALID_SAMPLES
                and stats["invalid"] == 0
                and stats.get("clean_cycles", 0) >= N4_AIR_LATCH_REQUIRED_CLEAN_CYCLES
            ):
                usable.append(addr)

        if not usable:
            return None

        # Only latch an address after repeated real airborne behavior:
        # grounded 0 -> airborne 1 -> grounded 0, multiple times.
        # Do not use a merely stable-grounded fallback; that let level-load flickers
        # and stuck values win too early in Stage 12.
        usable.sort(key=lambda addr: self._stat_for_air_addr(addr).get("clean_cycles", 0), reverse=True)
        return usable[0]

    def _choose_fallback_air_addr(self, profile: N4StageProfile, latest: Dict[int, int]) -> Optional[int]:
        """
        Slow safe fallback for Stage 12/Stage 5 sessions where the real air
        address gets one invalid/string-looking sample during load and therefore
        can never pass the strict invalid==0 latch.

        This still refuses stuck 0/stuck 1 addresses: the candidate must have
        shown both 0 and 1, must currently be a valid 0/1 value, and must remain
        the best candidate for 30 consecutive reads.
        """
        candidates: List[int] = []
        for addr in profile.airborne_addrs:
            value = latest.get(addr)
            stats = self._stat_for_air_addr(addr)
            if (
                value in (0, 1)
                and stats.get("valid", 0) >= N4_AIR_LATCH_MIN_VALID_SAMPLES
                and stats.get("seen0", 0)
                and stats.get("seen1", 0)
                and stats.get("valid_streak", 0) >= N4_AIR_FALLBACK_CONFIRM_SAMPLES
            ):
                candidates.append(addr)

        if not candidates:
            self.fallback_candidate_addr = None
            self.fallback_candidate_streak = 0
            return None

        candidates.sort(
            key=lambda addr: (
                self._stat_for_air_addr(addr).get("clean_cycles", 0),
                self._stat_for_air_addr(addr).get("valid_streak", 0),
                self._stat_for_air_addr(addr).get("valid", 0),
                -self._stat_for_air_addr(addr).get("invalid", 0),
            ),
            reverse=True,
        )
        best = candidates[0]
        if best == self.fallback_candidate_addr:
            self.fallback_candidate_streak += 1
        else:
            self.fallback_candidate_addr = best
            self.fallback_candidate_streak = 1

        if self.fallback_candidate_streak % N4_AIR_FALLBACK_REPORT_EVERY == 0:
            stats = self._stat_for_air_addr(best)
            print(
                f"[N4 AIR FALLBACK] {profile.stage}: 0x{best:08X} "
                f"confirm={self.fallback_candidate_streak}/{N4_AIR_FALLBACK_CONFIRM_SAMPLES}, "
                f"valid_streak={stats.get('valid_streak', 0)}, "
                f"clean_cycles={stats.get('clean_cycles', 0)}, "
                f"invalid={stats.get('invalid', 0)}"
            )

        if self.fallback_candidate_streak >= N4_AIR_FALLBACK_CONFIRM_SAMPLES:
            return best
        return None

    def _read_latched_air(self, profile: N4StageProfile) -> Optional[Tuple[int, int]]:
        latest: Dict[int, int] = {}
        for addr in profile.airborne_addrs:
            try:
                value = self.rw.read_u32(addr)
            except Exception:
                continue
            latest[addr] = value
            stats = self._stat_for_air_addr(addr)
            prev = stats.get("last", -1)
            if value in (0, 1):
                if prev == 0 and value == 1:
                    stats["saw01"] = 1
                    stats["armed_landing"] = 1
                elif prev == 1 and value == 0 and stats.get("armed_landing"):
                    stats["clean_cycles"] = stats.get("clean_cycles", 0) + 1
                    stats["armed_landing"] = 0
                    print(
                        f"[N4 AIR CYCLE] {profile.stage}: 0x{addr:08X} "
                        f"clean_cycles={stats['clean_cycles']}/{N4_AIR_LATCH_REQUIRED_CLEAN_CYCLES}"
                    )
                stats["last"] = value
                stats["valid"] += 1
                stats["valid_streak"] = stats.get("valid_streak", 0) + 1
                if value == 0:
                    stats["seen0"] = 1
                else:
                    stats["seen1"] = 1
            else:
                stats["last"] = value
                stats["armed_landing"] = 0
                stats["valid_streak"] = 0
                stats["invalid"] += 1

        if not latest:
            return None

        majority = self._majority_air_value(latest)

        if self.latched_air_addr is not None:
            selected_value = latest.get(self.latched_air_addr)
            if selected_value not in (0, 1):
                print(
                    f"[N4 AIR LATCH] 0x{self.latched_air_addr:08X} became invalid "
                    f"({selected_value}); reselecting."
                )
                self.latched_air_addr = None
                self.air_latch_disagree_ticks = 0
            else:
                latched_stats = self._stat_for_air_addr(self.latched_air_addr)
                latched_cycles = latched_stats.get("clean_cycles", 0)
                switched = False
                for addr in profile.airborne_addrs:
                    if addr == self.latched_air_addr:
                        continue
                    stats = self._stat_for_air_addr(addr)
                    cycles = stats.get("clean_cycles", 0)
                    if cycles >= N4_AIR_LATCH_REQUIRED_CLEAN_CYCLES and cycles > latched_cycles:
                        print(
                            f"[N4 AIR LATCH] switching from 0x{self.latched_air_addr:08X} "
                            f"to stronger clean-cycle candidate 0x{addr:08X} "
                            f"({cycles}>{latched_cycles})."
                        )
                        self.latched_air_addr = addr
                        self.air_latch_disagree_ticks = 0
                        switched = True
                        break

                if not switched:
                    # Once an N4 airborne address has proven real 0->1->0 clean cycles,
                    # keep it latched until the stage changes or the selected address becomes
                    # non-binary/invalid. A long run of 0 is normal grounded behavior, not a
                    # reason to unlatch. The older majority-disagreement reset could drop the
                    # correct Stage 5 address (0x81469754) while N4 stood grounded, because
                    # other candidate addresses were also 0 and outvoted the latched 1/0 signal.
                    self.air_latch_disagree_ticks = 0

        if self.latched_air_addr is None:
            chosen = self._choose_air_addr(profile, latest)
            if chosen is None:
                chosen = self._choose_fallback_air_addr(profile, latest)
                if chosen is None:
                    # Not enough stable 0/1 evidence yet. Do not guess and do not write CE50.
                    return None
                print(
                    f"[N4 AIR FALLBACK LATCH] {profile.stage}: selected 0x{chosen:08X} "
                    f"after {N4_AIR_FALLBACK_CONFIRM_SAMPLES} consecutive fallback confirmations."
                )
            self.latched_air_addr = chosen
            self.air_latch_disagree_ticks = 0
            self.fallback_candidate_addr = None
            self.fallback_candidate_streak = 0
            candidate_report = ", ".join(
                f"0x{addr:08X}={latest.get(addr, '??') if not isinstance(latest.get(addr), int) else f'{latest[addr]:08X}'}"
                for addr in profile.airborne_addrs
            )
            chosen_stats = self._stat_for_air_addr(chosen)
            print(
                f"[N4 AIR LATCH] {profile.stage}: selected 0x{chosen:08X} "
                f"after {chosen_stats.get('clean_cycles', 0)} clean cycles; candidates: {candidate_report}"
            )

        selected_value = latest.get(self.latched_air_addr)
        if selected_value not in (0, 1):
            return None
        return self.latched_air_addr, selected_value

    def tick(self, text: str) -> None:
        profile = self._detect_profile(text)
        if profile is None:
            if self.active_key is not None:
                print("[N4] Left supported N4 movement stage.")
            self.active_key = None
            self.reset_runtime()
            return

        if profile.key != self.active_key:
            self.active_key = profile.key
            self.reset_runtime()
            air_list = ", ".join(f"0x{addr:08X}" for addr in profile.airborne_addrs)
            print(f"[N4] Active movement profile: {profile.stage} air_candidates=[{air_list}]")

        has_double = self.items.has("Move_N4_DoubleJump")
        report = (profile.key, has_double)
        if report != self._last_report:
            print(f"[N4] DoubleJump owned={has_double}")
            self._last_report = report

        if not has_double:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
            if self._last_l_allowed is not False:
                print(f"[N4 L BLOCK] missing DoubleJump; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_BLOCK_VALUE:08X}")
                self._last_l_allowed = False
        else:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_ALLOW_VALUE)
            if self._last_l_allowed is not True:
                print(f"[N4 L ALLOW] DoubleJump owned; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_ALLOW_VALUE:08X}")
                self._last_l_allowed = True
            self.reset_runtime()
            return

        now = time.time()
        try:
            air_read = self._read_latched_air(profile)
            wall_value = self.rw.read_u32(WALL_CONTACT_ADDR)
        except Exception:
            return

        if air_read is None:
            # Wait until one of the candidate addresses proves stable.  Do not write CE50.
            return

        air_addr, air_value = air_read
        airborne = air_value == 1
        grounded = air_value == 0
        wall = wall_value == 1

        if air_value != self.last_air or air_addr != self.last_air_addr:
            print(
                f"[N4 AIR] {profile.stage}: 0x{air_addr:08X} = {air_value:08X} "
                f"({'AIRBORNE' if airborne else 'GROUNDED' if grounded else 'UNKNOWN'})"
            )
            self.last_air = air_value
            self.last_air_addr = air_addr

        if wall_value != self.last_wall:
            if wall:
                self.wall_grace_until = max(self.wall_grace_until, now + N4_WALL_CONTACT_GRACE_SECONDS)
                print(f"[N4 WALL] contact start; grace {N4_WALL_CONTACT_GRACE_SECONDS:.3f}s.")
            elif self.last_wall == 1:
                self.wall_grace_until = max(self.wall_grace_until, now + N4_POST_WALL_GRACE_SECONDS)
                print(f"[N4 WALL] contact end; post grace {N4_POST_WALL_GRACE_SECONDS:.3f}s.")
            self.last_wall = wall_value

        if grounded and self.airborne_session_handled:
            self.airborne_session_handled = False

        if airborne and not self.airborne_session_active and not self.airborne_session_handled:
            self.airborne_block_started_at = now
            self.airborne_session_active = True
            self.airborne_session_handled = True
            print("[N4 DOUBLE BLOCK] session on.")

        if self.airborne_session_active and (now - self.airborne_block_started_at >= N4_ALT_BLOCK_SECONDS):
            self.airborne_session_active = False

        if self.airborne_session_active and grounded:
            self.airborne_session_active = False

        wall_grace_active = wall or now < self.wall_grace_until
        should_write_ce50 = self.airborne_session_active and not wall_grace_active

        if should_write_ce50:
            self.rw.write_u32(CE50_JUMP_BLOCK_ADDR, CE50_BLOCK_VALUE)


class N5MovementController:
    """
    N5 movement blocker based on the standalone N5 v1 tester.

    v13 fix:
    - v12 ran this inside the shared 0.016s client loop, which was not tight enough.
    - This controller now writes CE50 aggressively any time N5 is airborne and
      DoubleJump is missing, instead of relying on a softer session edge.
    - WallJump blocking still uses the standalone wall contact / wall_block_until timing.
    """
    def __init__(self, rw: DolphinRW, item_state: ItemState):
        self.rw = rw
        self.items = item_state
        self.active_key: Optional[str] = None
        self.last_air: Optional[int] = None
        self.last_wall: Optional[int] = None
        self.wall_grace_until = 0.0
        self.wall_block_until = 0.0
        self._last_report: Optional[Tuple[str, bool, bool]] = None
        self._last_l_allowed: Optional[bool] = None
        self.latched_air_addr: Optional[int] = None
        self.air_last_by_addr: Dict[int, Optional[int]] = {}
        self._last_selected_air_addr: Optional[int] = None
        self._last_ce50_reason: Optional[str] = None
        # N5 uses the original standalone-style session block, not the hard
        # open-air CE50 spam used by the bad Easy Client integration.
        self.airborne_session_active = False
        self.airborne_session_handled = False
        self.airborne_block_started_at = 0.0

    def reset_runtime(self) -> None:
        self.last_air = None
        self.last_wall = None
        self.wall_grace_until = 0.0
        self.wall_block_until = 0.0
        self._last_ce50_reason = None
        self.latched_air_addr = None
        self.air_last_by_addr = {}
        self._last_selected_air_addr = None
        self.airborne_session_active = False
        self.airborne_session_handled = False
        self.airborne_block_started_at = 0.0

    def on_received_n5_move(self) -> None:
        self.reset_runtime()
        print(
            f"[N5] DoubleJump={self.items.has('Move_N5_DoubleJump')} "
            f"WallJump={self.items.has('Move_N5_WallJump')}. N5 runtime reset."
        )

    def _detect_profile(self, text: str) -> Optional[N5StageProfile]:
        for profile in N5_STAGE_PROFILES:
            if profile.marker in text:
                return profile
        return None

    def _read_airborne_candidate(self, profile: N5StageProfile) -> Optional[Tuple[int, int]]:
        readings: Dict[int, int] = {}
        for addr in profile.airborne_addrs:
            try:
                value = self.rw.read_u32(addr)
            except Exception:
                continue
            if value in (0, 1):
                readings[addr] = value
                last = self.air_last_by_addr.get(addr)
                # A real 0<->1 transition is the best evidence that this is the active air flag.
                if last is not None and last != value:
                    if self.latched_air_addr != addr:
                        print(f"[N5 AIR LATCH] {profile.stage}: 0x{addr:08X} selected after {last}->{value} transition.")
                    self.latched_air_addr = addr
                self.air_last_by_addr[addr] = value

        if self.latched_air_addr in readings:
            return self.latched_air_addr, readings[self.latched_air_addr]

        # Fallback for immediate testing: use the first currently-valid 0/1 candidate, but keep
        # watching for a transition so the resolver can latch the true active address.
        for addr in profile.airborne_addrs:
            if addr in readings:
                if self._last_selected_air_addr != addr:
                    print(f"[N5 AIR PENDING] {profile.stage}: using 0x{addr:08X} until a 0/1 transition latches a candidate.")
                    self._last_selected_air_addr = addr
                return addr, readings[addr]
        return None

    def tick(self, text: str) -> None:
        profile = self._detect_profile(text)
        if profile is None:
            if self.active_key is not None:
                print("[N5] Left supported N5 movement stage.")
            self.active_key = None
            self.reset_runtime()
            return

        if profile.key != self.active_key:
            self.active_key = profile.key
            self.reset_runtime()
            addrs = ", ".join(f"0x{a:08X}" for a in profile.airborne_addrs)
            print(f"[N5] Active movement profile: {profile.stage} air candidates=[{addrs}]")

        has_double = self.items.has("Move_N5_DoubleJump")
        has_wall = self.items.has("Move_N5_WallJump")
        report = (profile.key, has_double, has_wall)
        if report != self._last_report:
            print(f"[N5] DoubleJump={has_double} WallJump={has_wall}")
            self._last_report = report

        wants_double_block = not has_double
        wants_wall_block = not has_wall
        wants_l_block = not (has_double and has_wall)

        if wants_l_block:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_BLOCK_VALUE)
            if self._last_l_allowed is not False:
                print(f"[N5 L BLOCK] missing DoubleJump or WallJump; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_BLOCK_VALUE:08X}")
                self._last_l_allowed = False
        else:
            self.rw.write_u32(LOCK_ON_BLOCK_ADDR, LOCK_ON_ALLOW_VALUE)
            if self._last_l_allowed is not True:
                print(f"[N5 L ALLOW] both moves owned; 0x{LOCK_ON_BLOCK_ADDR:08X} = {LOCK_ON_ALLOW_VALUE:08X}")
                self._last_l_allowed = True
            self.reset_runtime()
            return

        now = time.time()
        try:
            air_read = self._read_airborne_candidate(profile)
            wall_value = self.rw.read_u32(WALL_CONTACT_ADDR)
        except Exception:
            return
        if air_read is None:
            return
        air_addr, air_value = air_read

        airborne = air_value == 1
        wall = wall_value == 1

        if air_value != self.last_air:
            print(f"[N5 AIR] {profile.stage}: 0x{air_addr:08X} = {air_value:08X} ({'AIRBORNE' if airborne else 'GROUNDED' if air_value == 0 else 'UNKNOWN'})")
            self.last_air = air_value

        if wall_value != self.last_wall:
            if wall:
                self.wall_grace_until = max(self.wall_grace_until, now + N5_WALL_CONTACT_GRACE_SECONDS)
                print(f"[N5 WALL] contact start; grace {N5_WALL_CONTACT_GRACE_SECONDS:.3f}s.")
                if wants_wall_block:
                    self.wall_block_until = max(self.wall_block_until, now + N5_WALL_BLOCK_SECONDS)
                    print(f"[N5 WALL BLOCK] start {N5_WALL_BLOCK_SECONDS:.3f}s.")
            elif self.last_wall == 1:
                self.wall_grace_until = max(self.wall_grace_until, now + N5_POST_WALL_GRACE_SECONDS)
                print(f"[N5 WALL] contact end; post grace {N5_POST_WALL_GRACE_SECONDS:.3f}s.")
            self.last_wall = wall_value

        if wants_wall_block and wall and N5_EXTEND_WHILE_WALL_CONTACT:
            self.wall_block_until = max(self.wall_block_until, now + N5_WALL_BLOCK_SECONDS)

        wall_block_active = wants_wall_block and (now < self.wall_block_until)
        wall_grace_active = wall or now < self.wall_grace_until

        # Original N5 standalone-style double-jump block:
        # start one CE50 block session when the airborne flag changes to 1,
        # then stop on ground or after the timer. Do NOT hard-hold CE50 just
        # because the airborne read remains 1; that can prevent normal jumping.
        grounded = air_value == 0

        if grounded and self.airborne_session_handled:
            self.airborne_session_handled = False

        if wants_double_block and airborne and not self.airborne_session_active and not self.airborne_session_handled:
            self.airborne_block_started_at = now
            self.airborne_session_active = True
            self.airborne_session_handled = True
            print("[N5 DOUBLE BLOCK] session on.")

        if self.airborne_session_active and (now - self.airborne_block_started_at >= N5_ALT_BLOCK_SECONDS):
            self.airborne_session_active = False

        if self.airborne_session_active and grounded:
            self.airborne_session_active = False

        double_block_active = wants_double_block and self.airborne_session_active and not wall_grace_active
        should_write_ce50 = double_block_active or wall_block_active

        if should_write_ce50:
            self.rw.write_u32(CE50_JUMP_BLOCK_ADDR, CE50_BLOCK_VALUE)
            reason = "double_session" if double_block_active else "wall"
            if reason != self._last_ce50_reason:
                print(f"[N5 CE50 BLOCK] reason={reason}; 0x{CE50_JUMP_BLOCK_ADDR:08X} = {CE50_BLOCK_VALUE:08X}")
                self._last_ce50_reason = reason
        else:
            self._last_ce50_reason = None


class MemoryApplier:
    def __init__(self, rw: DolphinRW, item_state: ItemState, roadmap_slot_order: Optional[Dict[int, str]] = None):
        self.rw = rw
        self.items = item_state
        self.roadmap_slot_order = dict(roadmap_slot_order or {})
        # Keep both names.  RC6.45's Slot-1 hold accidentally referenced
        # self.slot_to_stage without defining it; that made continuous_apply()
        # throw before N2/N3/N4/N5 blockers could run.
        self.slot_to_stage = self.roadmap_slot_order
        self.stage_to_slot = {stage: slot for slot, stage in self.roadmap_slot_order.items()}
        self._stage_unlock_noop_reported: Set[str] = set()
        self._stage_unlock_missing_reported: Set[str] = set()
        self._last_n1_stage: Optional[str] = None
        self._grappluh_reset_done = False
        self._last_status = 0.0
        self._last_y_status: Optional[Tuple[str, bool]] = None
        self._last_fire_status: Optional[Tuple[str, bool, str]] = None
        self._n1_bad_grappluh_addrs: Set[int] = set()
        self._n1_last_grappluh_write_status: Optional[Tuple[str, str, Tuple[int, ...]]] = None
        self._n3 = N3MovementController(rw, item_state)
        self._n4 = N4MovementController(rw, item_state)
        self._n5 = N5MovementController(rw, item_state)
        self._smellmet_local_crafted = False
        self._last_smellmet_flag_state: Optional[bool] = None

    def _write_stage_unlock_for_target_item(self, item_name: str, quiet: bool = False) -> bool:
        target_stage = STAGE_UNLOCK_TO_STAGE.get(item_name)
        if not target_stage:
            return False

        # RC6.39: received AP Stage_X_Unlock items now write their corrected
        # direct native unlock byte.  The previous roadmap/previous-slot
        # translation could reopen the old off-by-one behavior, e.g. receiving
        # Stage_11_Cavity_Cave_Unlock could write/open Stage 10's byte.
        # Roadmap/visual slot locking can be handled separately; the item
        # applier must make the named AP stage's native unlock flag true.
        target_slot = self.stage_to_slot.get(target_stage) if self.stage_to_slot else None

        addr = STAGE_UNLOCK_ADDR.get(item_name)

        # RC6.43: Slot 1/start should be kept visually/native-locked on hook/load.
        # The start stage is already playable through AP setup, but its native
        # unlock byte can be borrowed by Credits/vanilla next-stage behavior and
        # make Slot 2 or another menu entry look open.  So for the current Slot 1
        # stage, write the direct native flag to 0 instead of skipping the write.
        if target_slot == 1:
            if addr is not None:
                self.rw.write_u8(addr, 0)
                if not quiet:
                    print(f"[APPLY] {item_name}: Slot 01/start; locked native 0x{addr:08X} = 00 for {target_stage}")
            elif not quiet:
                print(f"[APPLY] {item_name}: Slot 01/start; no direct native byte known to lock for {target_stage}")
            return True

        if addr is None:
            if not quiet and item_name not in self._stage_unlock_missing_reported:
                print(f"[STAGE UNLOCK] {item_name}: no direct native unlock byte is known; no write.")
                self._stage_unlock_missing_reported.add(item_name)
            return True

        self.rw.write_u8(addr, 1)
        if not quiet:
            slot_note = f" Slot {target_slot:02d};" if target_slot is not None else ""
            print(f"[APPLY] {item_name}:{slot_note} direct {target_stage} unlock -> 0x{addr:08X} = 01")
        return True

    def apply_received_once(self, item_name: str) -> None:
        self._write_stage_unlock_for_target_item(item_name, quiet=False)
        if item_name == "Move_N1_Grappluh":
            self._grappluh_reset_done = False
            print("[APPLY] Move_N1_Grappluh owned; N1 Grappluh sabotage will clear/reset once on N1 stage entry.")
        if item_name == "Move_N3_Progressive_Movement":
            self._n3.on_received_n3_movement()
        if item_name == "Move_N4_DoubleJump":
            self._n4.on_received_n4_double()
        if item_name in ("Move_N5_DoubleJump", "Move_N5_WallJump"):
            self._n5.on_received_n5_move()

    def apply_initial_stage_unlocks_once(self) -> None:
        for item_name in STAGE_UNLOCK_TO_STAGE:
            if self.items.has(item_name):
                with contextlib.suppress(Exception):
                    self._write_stage_unlock_for_target_item(item_name, quiet=False)

    def _hold_slot1_native_unlock_locked(self) -> None:
        """Continuously keep the current Slot 1 stage's native unlock byte at 0.

        Slot 1 is already playable through the AP starting setup.  Its native
        unlock byte can be reused/borrowed by the game's Credits/next-slot
        behavior and can visually open later slots again after our one-shot
        startup lock.  Holding only the Slot 1 stage's direct native byte at 0
        prevents those phantom Slot 2/Slot 3 opens without changing AP access.
        """
        if not self.slot_to_stage:
            return
        stage = self.slot_to_stage.get(1)
        if not stage:
            return
        item_name = f"{stage}_Unlock"
        addr = STAGE_UNLOCK_ADDR.get(item_name)
        if addr is None:
            return
        with contextlib.suppress(Exception):
            self.rw.write_u8(addr, 0)

    def continuous_apply(self) -> None:
        # Stage unlock bytes are intentionally mostly one-shot.  The exception is
        # Slot 1: its native flag can be borrowed by Credits/next-slot behavior,
        # so we continuously hold the current Slot 1 stage's direct native byte
        # at 0 to stop phantom later slots from appearing open.
        self._hold_slot1_native_unlock_locked()

        # Keep normal weapon-start flags on; AP permission comes from Y blockers.
        for _item_name, addr in NORMAL_WEAPON_FLAG.items():
            with contextlib.suppress(Exception):
                self.rw.write_u8(addr, 1)

        # N2 0..N progressives + native 0/1 online toggles.
        for prog_item, (addr, max_value) in COOLBUS_PROGRESSIVE_ADDR.items():
            count = min(self.items.count(prog_item), max_value)
            with contextlib.suppress(Exception):
                self.rw.write_u32(addr, count)

        for online_item, (flag_addr, prog_item, _key, max_value) in N2_WEAPON_SYSTEM_FLAG.items():
            complete = self.items.has(online_item)
            with contextlib.suppress(Exception):
                self.rw.write_u8(flag_addr, 1 if complete else 0)

        text = active_stage_markers(self.rw)
        self._apply_smellmet_crafted_flag(text)
        self._apply_n1_grappluh(text)
        self._apply_y_blockers(text)
        self._n3.tick(text)
        self._n4.tick(text)
        self._n5.tick(text)

    def _read_stage3_spare_parts_reached_3(self) -> Tuple[bool, str]:
        values: List[Tuple[int, int]] = []
        for addr in SMELLMET_SPARE_PART_ADDRS:
            try:
                v = int(self.rw.read_u8(addr))
            except Exception:
                continue
            if 0 <= v <= 3:
                values.append((addr, v))
        detail = ", ".join(f"0x{addr:08X}={v}" for addr, v in values)
        return any(v >= 3 for _addr, v in values), detail

    def _apply_smellmet_crafted_flag(self, text: str) -> None:
        # Stage 3 / Boogification Smellmet is not a normal gun/Unjammed weapon.
        # Keep the native mask flag OFF until the in-level spare-parts crafting
        # condition is actually met.  Do not turn this on just because AP owns the
        # matching item name; that can make Stage 3 start with Smellmet already
        # formed and prevent the Stage_03_Boogification_Smellmet_Crafted check
        # from being legitimately triggered.
        in_stage3 = SMELLMET_STAGE_MARKER in text or "Stage_03_Boogification" in text
        if not self._smellmet_local_crafted and in_stage3:
            reached, detail = self._read_stage3_spare_parts_reached_3()
            if reached:
                self._smellmet_local_crafted = True
                print(f"[SMELLMET FLAG] local crafted condition met; {detail}")

        allow = self._smellmet_local_crafted
        try:
            self.rw.write_u8(SMELLMET_CRAFTED_FLAG_ADDR, 1 if allow else 0)
        except Exception:
            return

        if allow != self._last_smellmet_flag_state:
            reason = "local crafted condition met" if allow else "not locally crafted yet"
            print(
                f"[SMELLMET FLAG] {reason}; "
                f"0x{SMELLMET_CRAFTED_FLAG_ADDR:08X} = {1 if allow else 0}"
            )
            self._last_smellmet_flag_state = allow

    def _safe_n1_grappluh_writes(self, stage: str, addrs: Tuple[int, ...], value: int, reason: str) -> None:
        written: List[int] = []
        failed: List[int] = []
        for addr in addrs:
            if addr in self._n1_bad_grappluh_addrs:
                continue
            try:
                self.rw.write_u32(addr, value)
                written.append(addr)
            except Exception:
                failed.append(addr)
                self._n1_bad_grappluh_addrs.add(addr)
        status = (stage, reason, tuple(written))
        if status != self._n1_last_grappluh_write_status:
            wtxt = ", ".join(f"0x{a:08X}" for a in written) or "none"
            ftxt = ", ".join(f"0x{a:08X}" for a in failed) or "none"
            print(f"[N1 GRAPPLUH] {stage}: {reason}; wrote {value:08X} to [{wtxt}], failed/skipped [{ftxt}]")
            self._n1_last_grappluh_write_status = status

    def _apply_n1_grappluh(self, text: str) -> None:
        active: Optional[Tuple[str, Tuple[int, ...]]] = None
        for stage, (marker, addrs) in N1_GRAPPLUH_STAGE.items():
            if marker in text:
                active = (stage, addrs)
                break
        if active is None:
            self._last_n1_stage = None
            self._grappluh_reset_done = False
            self._n1_last_grappluh_write_status = None
            return
        stage, addrs = active
        if stage != self._last_n1_stage:
            addr_list = ", ".join(f"0x{addr:08X}" for addr in addrs)
            print(f"[N1] Active Grappluh stage: {stage} addrs=[{addr_list}]")
            self._last_n1_stage = stage
            self._grappluh_reset_done = False
            self._n1_last_grappluh_write_status = None
        if not self.items.has("Move_N1_Grappluh"):
            self._safe_n1_grappluh_writes(stage, addrs, GRAPPLUH_MISSING_VALUE, "missing Grappluh")
        elif not self._grappluh_reset_done:
            self._safe_n1_grappluh_writes(stage, addrs, GRAPPLUH_OWNED_RESET_VALUE, "owned reset once")
            self._grappluh_reset_done = True

    def _apply_y_blockers(self, text: str) -> None:
        """
        Corrected weapon-fire rule:

        - 0x8076CE44 is the actual Y/fire/use gate.
          Gecko equivalent: 0476CE44 00000000

        - N1:
          mirror-only suppress through 0x807319D8, matching the standalone N1 tester.
          This avoids CE44 blocking both N1 actions.

        - N3:
          keep the existing CE44 mirror behavior for now; do not touch unless testing proves broken.

        - N4:
          mirror-only suppress through 0x807319D8. Do not write CE44 for N4.

        - N2:
          no mirror. While in the N2 vehicle stage, keep CE44 = 0 until the
          respective AP N2 Weapons System Online item says it is allowed. Progressives only set shot level.
        """

        # N2 / CoolBus: hard block CE44 while missing.
        for prof in N2_WEAPON_PROFILES:
            if not _stage_text_present(text, prof.stage, prof.marker):
                continue

            complete = self.items.has(prof.online_item)
            status = (prof.stage, complete, "n2")

            if not complete:
                self.rw.write_u32(Y_FIRE_BLOCK_ADDR, Y_FIRE_BLOCK_VALUE)
                if status != self._last_fire_status:
                    print(
                        f"[N2 FIRE BLOCK] {prof.stage}: missing {prof.online_item} / "
                        f"{prof.progressive_item} {self.items.count(prof.progressive_item)}/{prof.max_value}; "
                        f"0x{Y_FIRE_BLOCK_ADDR:08X} = {Y_FIRE_BLOCK_VALUE:08X}"
                    )
                    self._last_fire_status = status
                return

            self.rw.write_u32(Y_FIRE_BLOCK_ADDR, Y_FIRE_ALLOW_VALUE)
            if status != self._last_fire_status:
                print(
                    f"[N2 FIRE ALLOW] {prof.stage}: N2 weapon/system allowed; "
                    f"0x{Y_FIRE_BLOCK_ADDR:08X} = {Y_FIRE_ALLOW_VALUE:08X}"
                )
                self._last_fire_status = status
            return

        # N1/N3/N4: mirror-only weapon checks. N1/N4 use tested 319D8 suppress path; N3 keeps CE44.
        active_profile: Optional[WeaponProfile] = None
        for prof in WEAPON_PROFILES:
            if prof.marker in text:
                active_profile = prof
                break

        if active_profile is None:
            self._last_fire_status = None
            return

        owned = self.items.has(active_profile.item)
        active = mirror_active(self.rw, active_profile.mirror)

        # N1 and N4 are special. Their standalone-tested path suppresses Y through
        # 0x807319D8, mirror-only, and does not use CE44 as the block.  CE44 can
        # bleed into broader action behavior for these characters.
        if active_profile.stage in (
            "Stage_02_Donutty", "Stage_07_Spankarific", "Stage_11_Cavity_Cave",
            "Stage_05_Spank_Happy", "Stage_12_Overflow",
        ):
            family = "N1" if active_profile.stage in ("Stage_02_Donutty", "Stage_07_Spankarific", "Stage_11_Cavity_Cave") else "N4"
            if active and not owned:
                self.rw.write_u32(Y_ACTION_SUPPRESS_ADDR, Y_ACTION_SUPPRESS_VALUE)
                status = (active_profile.stage, False, f"{family.lower()}_mirror_319d8")
                if status != self._last_fire_status:
                    print(
                        f"[{family} Y SUPPRESS] {active_profile.stage}: mirror active and missing {active_profile.item}; "
                        f"0x{Y_ACTION_SUPPRESS_ADDR:08X} = {Y_ACTION_SUPPRESS_VALUE:08X}; CE44 untouched"
                    )
                    self._last_fire_status = status
                return

            status = (active_profile.stage, True, f"{family.lower()}_mirror_319d8")
            if status != self._last_fire_status:
                reason = "owned" if owned else "mirror inactive"
                print(f"[{family} Y IDLE] {active_profile.stage}: {reason}; 319D8 not forced, CE44 untouched")
                self._last_fire_status = status
            return

        # N3: CE44 mirror block only. Do not change N3 until testing proves it is broken.
        if active and not owned:
            self.rw.write_u32(Y_FIRE_BLOCK_ADDR, Y_FIRE_BLOCK_VALUE)
            status = (active_profile.stage, False, "mirror")
            if status != self._last_fire_status:
                print(
                    f"[FIRE BLOCK] {active_profile.stage}: mirror active and missing {active_profile.item}; "
                    f"0x{Y_FIRE_BLOCK_ADDR:08X} = {Y_FIRE_BLOCK_VALUE:08X}"
                )
                self._last_fire_status = status
            return

        # Do not leave CE44 latched at 0 after the mirror deactivates or the weapon is owned.
        self.rw.write_u32(Y_FIRE_BLOCK_ADDR, Y_FIRE_ALLOW_VALUE)
        status = (active_profile.stage, True, "mirror")
        if status != self._last_fire_status:
            reason = "owned" if owned else "mirror inactive"
            print(
                f"[FIRE ALLOW] {active_profile.stage}: {reason}; "
                f"0x{Y_FIRE_BLOCK_ADDR:08X} = {Y_FIRE_ALLOW_VALUE:08X}"
            )
            self._last_fire_status = status


# ---------------------------------------------------------------------------
# Location watcher
# ---------------------------------------------------------------------------

class ProgressWatcher:
    def __init__(self, rw: DolphinRW, item_state: ItemState):
        self.rw = rw
        self.items = item_state
        self._flag_seen: Set[str] = set()
        # Sent/credited monkey highwater is capped by AP cappers.
        self._monkey_highwater: Dict[str, int] = {}
        # Highest vanilla tier observed before capper suppression/clamping.
        self._monkey_observed_highest: Dict[str, int] = {}
        self._monkey_last: Dict[str, int] = {}
        self._monkey_baseline: Dict[str, int] = {}
        self._last_active_stage: Optional[str] = None
        self._last_fmv: Optional[int] = None
        self._weapon_last_active: Dict[str, bool] = {}
        self._weapon_sent: Set[str] = set()
        self._smellmet_crafted_sent = False
        # Sooper flags can fail the normal active-stage text gate, especially if
        # the marker is stale or the client was started mid-stage. Watch the
        # confirmed Sooper flag addresses globally/statefully, then delay the
        # vanilla flag reset until the main-menu signature appears.
        self._sooper_last_active: Dict[str, bool] = {}
        self._sooper_pending_reset: Set[str] = set()

    @staticmethod
    def _clamp_tier(v: int) -> int:
        return 0 if v < 0 else 4 if v > 4 else v

    def _allowed_monkey_tier(self, stage: str) -> int:
        operative = MONKEY_STAGE_OPERATIVE.get(stage)
        if not operative:
            return 4
        capper_item = MONKEY_CAPPER_ITEM.get(operative)
        if not capper_item:
            return 4
        return self._clamp_tier(1 + self.items.count(capper_item))

    def _monkey_suffixes(self, stage: str) -> Dict[int, str]:
        if stage == "Stage_15_Credits":
            return {1: "10", 2: "20", 3: "30", 4: "40"}
        return {1: "25", 2: "50", 3: "75", 4: "100"}

    def _clamp_monkey_tier_after_completion(self, stage: str) -> None:
        addr = MONKEY_TIER_ADDR.get(stage)
        if addr is None:
            return
        allowed = self._allowed_monkey_tier(stage)
        try:
            current = self._clamp_tier(self.rw.read_u8(addr))
        except Exception:
            return
        if current > allowed:
            try:
                self.rw.write_u8(addr, allowed)
                print(
                    f"[MONKEY CAP] {stage}: vanilla tier {current} exceeded AP cap {allowed}; "
                    f"clamped 0x{addr:08X} back to {allowed} after completion"
                )
            except Exception as e:
                print(f"[MONKEY CAP] {stage}: failed to clamp 0x{addr:08X}: {e}")

    def poll(self) -> List[str]:
        out: List[str] = []
        out.extend(self._poll_fmv_completion())
        out.extend(self._poll_sooper_flags())
        out.extend(self._poll_flags())
        out.extend(self._poll_stage3_smellmet_crafted())
        out.extend(self._poll_monkeys())
        out.extend(self._poll_weapon_checks())
        return out

    def _poll_fmv_completion(self) -> List[str]:
        out: List[str] = []
        try:
            fmv = find_current_fmv(self.rw)
        except Exception:
            return out
        if fmv is None:
            self._last_fmv = None
            return out
        if fmv == self._last_fmv:
            return out
        self._last_fmv = fmv
        slot = FMV_TO_COMPLETE_SLOT.get(fmv)
        if slot is None:
            return out
        order = read_current_slot_order(self.rw)
        if not order:
            return out
        stage = order.get(slot)
        if not stage:
            return out
        loc = f"{stage}_Complete"
        print(f"[FMV] FMV{fmv:02d} => Slot {slot:02d} => {loc}")
        self._clamp_monkey_tier_after_completion(stage)
        out.append(loc)
        return out

    def _current_active_stage(self) -> Optional[str]:
        text = active_stage_markers(self.rw)
        stage = active_stage_from_text(text)
        if stage != self._last_active_stage:
            if stage:
                print(f"[WATCH] Active stage for location polling: {stage}")
            self._last_active_stage = stage
        return stage

    @staticmethod
    def _location_stage_prefix(loc: str) -> Optional[str]:
        m = re.match(r"^(Stage_\d{2}_[A-Za-z_]+)", loc)
        return m.group(1) if m else None

    def _poll_flags(self) -> List[str]:
        out: List[str] = []
        current_stage = self._current_active_stage()
        if not current_stage:
            return out
        for loc, addrs in FLAG_LOCATIONS.items():
            loc_stage = self._location_stage_prefix(loc)
            if loc_stage and loc_stage != current_stage:
                continue
            # Sooper Secret outfit flags are handled by _poll_sooper_flags().
            # That watcher does not depend entirely on active-stage text, so it
            # can catch Stage 3 / CoolBus-style stale marker cases more reliably.
            if loc in SOOPER_SECRET_FLAG_LOCATIONS:
                continue

            if loc in self._flag_seen:
                continue

            try:
                active = any(self.rw.read_u8(a) != 0 for a in addrs)
            except Exception:
                continue

            if not active:
                continue

            self._flag_seen.add(loc)
            out.append(loc)
        return out

    def _read_sooper_flag_active(self, addr: int) -> bool:
        # RC6.40: these outfit/Sooper flags are aligned 32-bit big-endian words
        # in Dolphin memory view, e.g. 0x807716A0 displays 00000001.  Reading
        # only read_u8(addr) sees the high byte (0), so the client missed real
        # collected Soopers.  Accept either the full word, the low byte, or an
        # old byte-style write as active for safety.
        try:
            if self.rw.read_u32(addr) != 0:
                return True
        except Exception:
            pass
        try:
            if self.rw.read_u8(addr + 3) != 0:
                return True
        except Exception:
            pass
        try:
            return self.rw.read_u8(addr) != 0
        except Exception:
            return False

    def _reset_pending_soopers_if_main_menu(self) -> None:
        if not self._sooper_pending_reset:
            return
        if not main_menu_signature_present(self.rw):
            return

        for loc in list(self._sooper_pending_reset):
            addr = SOOPER_SECRET_FLAG_LOCATIONS.get(loc)
            if addr is None:
                self._sooper_pending_reset.discard(loc)
                continue
            try:
                if self._read_sooper_flag_active(addr):
                    self.rw.write_u32(addr, 0)
                    print(f"[SOOPER SUPPRESS] {loc}: returned to menu; wrote word flag back to 0 at 0x{addr:08X}")
                else:
                    print(f"[SOOPER SUPPRESS] {loc}: returned to menu; flag already 0 at 0x{addr:08X}")
                self._sooper_pending_reset.discard(loc)
            except Exception:
                continue

    def _poll_sooper_flags(self) -> List[str]:
        out: List[str] = []

        for loc, addr in SOOPER_SECRET_FLAG_LOCATIONS.items():
            active = self._read_sooper_flag_active(addr)

            self._sooper_last_active[loc] = active

            if not active:
                continue

            # Sooper Secret outfit flags are state-based and retryable.  If the
            # flag is still 1 in Dolphin, keep offering the AP location check every
            # poll until the outer AP send loop/server-confirmed sent list accepts
            # it.  Do not let this watcher's local _flag_seen cache suppress a
            # real retry; older builds could mark it locally before AP counted it.
            self._sooper_pending_reset.add(loc)
            if loc not in self._flag_seen:
                with contextlib.suppress(Exception):
                    word_value = self.rw.read_u32(addr)
                    print(f"[SOOPER] {loc}: word=0x{word_value:08X} at 0x{addr:08X}; offering AP check, reset delayed until menu")
                self._flag_seen.add(loc)
            out.append(loc)

        self._reset_pending_soopers_if_main_menu()
        return out

    def _poll_stage3_smellmet_crafted(self) -> List[str]:
        out: List[str] = []
        if self._smellmet_crafted_sent:
            return out
        stage = self._current_active_stage()
        if stage != "Stage_03_Boogification":
            return out

        values: List[Tuple[int, int]] = []
        for addr in SMELLMET_SPARE_PART_ADDRS:
            try:
                v = int(self.rw.read_u8(addr))
            except Exception:
                continue
            if 0 <= v <= 3:
                values.append((addr, v))

        if any(v >= 3 for _addr, v in values):
            self._smellmet_crafted_sent = True
            detail = ", ".join(f"0x{addr:08X}={v}" for addr, v in values)
            print(f"[SMELLMET CRAFTED] spare parts reached 3; {detail}")
            out.append(SMELLMET_CRAFTED_LOCATION)

        return out

    def _poll_monkeys(self) -> List[str]:
        out: List[str] = []
        stage = self._current_active_stage()
        if not stage:
            return out
        addr = MONKEY_TIER_ADDR.get(stage)
        if addr is None:
            return out
        try:
            tier = self._clamp_tier(self.rw.read_u8(addr))
        except Exception:
            return out

        self._monkey_last[stage] = tier

        # State-based monkey tier reporting.  Do NOT require catching the exact
        # 0->1/2/3/4 transition: if the active stage's native tier value is
        # already sitting at a tier and AP has not been credited this client
        # session, send all capper-allowed tiers up to that value.
        #
        # Native tier values:
        #   0 = none, 1 = 25, 2 = 50, 3 = 75, 4 = 100
        # AP capper rule:
        #   0 cappers -> max tier 1 / 25
        #   1 capper  -> max tier 2 / 50
        #   2 cappers -> max tier 3 / 75
        #   3 cappers -> max tier 4 / 100
        if stage not in self._monkey_baseline:
            self._monkey_baseline[stage] = tier
            if tier:
                print(f"[MONKEY STATE] {stage}: first seen native tier={tier}; will report allowed unsent tiers.")

        baseline = self._monkey_baseline.get(stage, 0)
        observed_hi = max(self._monkey_observed_highest.get(stage, baseline), tier)
        self._monkey_observed_highest[stage] = observed_hi

        allowed = self._allowed_monkey_tier(stage)
        eligible_hi = min(observed_hi, allowed)
        sent_hi = self._monkey_highwater.get(stage, 0)

        if eligible_hi > sent_hi:
            suffixes = self._monkey_suffixes(stage)

            if stage == "Stage_15_Credits":
                # V0 rule: Credits first tier is also completion.
                if sent_hi < 1 <= eligible_hi:
                    out.append("Stage_15_Credits_Complete")

            for t in range(sent_hi + 1, eligible_hi + 1):
                sfx = suffixes.get(t)
                if sfx:
                    out.append(f"{stage}_Secret_{sfx}_Monkeys")

            self._monkey_highwater[stage] = eligible_hi

        # Do not live-edit GoldenMonkeys/current count. The only write is the
        # after-completion clamp in _clamp_monkey_tier_after_completion().
        return out

    def _poll_weapon_checks(self) -> List[str]:
        out: List[str] = []
        text = active_stage_markers(self.rw)
        for prof in WEAPON_PROFILES:
            if prof.location in self._weapon_sent:
                continue
            if prof.marker not in text:
                self._weapon_last_active[prof.location] = False
                continue
            if not self.items.has(prof.item):
                self._weapon_last_active[prof.location] = False
                continue
            active = mirror_active(self.rw, prof.mirror)
            last = self._weapon_last_active.get(prof.location, False)
            self._weapon_last_active[prof.location] = active
            if active and not last:
                self._weapon_sent.add(prof.location)
                print(f"[WEAPON CHECK] First active weapon mirror after AP item: {prof.location}")
                out.append(prof.location)
        return out

# ---------------------------------------------------------------------------
# AP runtime
# ---------------------------------------------------------------------------

async def _send(ws, obj: Dict[str, Any]) -> None:
    await ws.send(json.dumps([obj]))


def normalize_url(connect: str) -> str:
    return normalize_server_input(connect)


def _item_name_table(game_dp: Dict[str, Any]) -> Dict[int, str]:
    item_name_to_id: Dict[str, int] = game_dp.get("item_name_to_id", {}) or {}
    return {int(v): k for k, v in item_name_to_id.items()}


async def run_client(connect: str, player: str, password: str, profile_override: str = "", ap_output_dir: str = "", active_game_dir: str = "", archive_runs_dir: str = "") -> None:
    url = normalize_url(connect)
    ssl_ctx = ssl.create_default_context() if url.startswith("wss://") else None
    rw = DolphinRW()

    # Safe to call twice; it skips sources already processed. This keeps direct callers working too.
    integrated_easy_run_prepare(ap_output_dir, active_game_dir, archive_runs_dir)

    print(f"[VERSION] {VERSION}")
    print(f"[AP] Connecting to parsed URL: {url} as '{player}'")
    async with websockets.connect(url, ping_interval=None, ping_timeout=None, ssl=ssl_ctx) as ws:
        roominfo = None
        while roominfo is None:
            msgs = json.loads(await ws.recv())
            roominfo = next((m for m in msgs if m.get("cmd") == "RoomInfo"), None)

        seed_key = _seed_fingerprint(roominfo or {}, url)
        profile_path = _profile_state_path(player, seed_key, profile_override)
        state = ensure_state(profile_path)
        client_uuid = str(state["uuid"])
        # Local sent-location state is only a cache. The AP server's checked_locations
        # list is the source of truth after reconnect.  If an older client marked a
        # location locally before AP actually counted it, keeping the stale cache would
        # suppress future retries forever; this especially affected Sooper Secret flags
        # that stayed at 1 in Dolphin but never appeared in AP.
        cached_sent_location_names: Set[str] = set(str(x) for x in state.get("sent_location_names", []))
        sent_location_names: Set[str] = set()
        received_initial: List[str] = list(str(x) for x in state.get("received_items", []))
        last_idx = int(state.get("last_item_index", -1))

        print(f"[STATE] Profile: {profile_path.name}")
        print(f"[STATE] Seed key: {seed_key}")

        version = roominfo.get("version") or {"major": 0, "minor": 6, "build": 5, "class": "Version"}
        await _send(ws, {
            "cmd": "Connect",
            "password": password or "",
            "game": GAME_NAME,
            "name": player,
            "uuid": client_uuid,
            "version": version,
            "items_handling": ITEMS_HANDLING,
            "tags": CLIENT_TAGS,
            "slot_data": True,
        })

        pending_msgs: List[Dict[str, Any]] = []
        connected_msg: Dict[str, Any] = {}
        while True:
            msgs = json.loads(await ws.recv())
            refused = next((m for m in msgs if m.get("cmd") == "ConnectionRefused"), None)
            if refused:
                raise RuntimeError(f"ConnectionRefused: {refused.get('errors')}")
            connected = next((m for m in msgs if m.get("cmd") == "Connected"), None)
            if connected:
                connected_msg = connected
                pending_msgs.extend([m for m in msgs if m is not connected])
                print(f"[AP] Connected! team={connected.get('team')} slot={connected.get('slot')}")
                break
            pending_msgs.extend(msgs)

        await _send(ws, {"cmd": "GetDataPackage"})
        datapkg = None
        while datapkg is None:
            msgs = json.loads(await ws.recv())
            dp = next((m for m in msgs if m.get("cmd") == "DataPackage"), None)
            if dp:
                pending_msgs.extend([m for m in msgs if m is not dp])
                datapkg = dp.get("data")
            else:
                pending_msgs.extend(msgs)

        game_dp = (datapkg or {}).get("games", {}).get(GAME_NAME, {})
        location_name_to_id: Dict[str, int] = game_dp.get("location_name_to_id", {}) or {}
        item_id_to_name = _item_name_table(game_dp)
        print(f"[AP] DataPackage ok. locations={len(location_name_to_id)} unique_items={len(item_id_to_name)}")

        checked_ids = set(int(x) for x in connected_msg.get("checked_locations", []) or [])
        id_to_location: Dict[int, str] = {int(v): k for k, v in location_name_to_id.items()}
        for loc_id in checked_ids:
            loc_name = id_to_location.get(loc_id)
            if loc_name:
                sent_location_names.add(loc_name)
        stale_cached = cached_sent_location_names - sent_location_names
        if stale_cached:
            print(f"[STATE] Ignoring {len(stale_cached)} locally cached sent check(s) not confirmed by AP server: {sorted(stale_cached)[:8]}")
        state["sent_location_names"] = sorted(sent_location_names)
        _save_json(profile_path, state)

        roadmap_order: Optional[Dict[int, str]] = None
        roadmap_source = ""
        try:
            roadmap_order, roadmap_source = resolve_roadmap_slot_order(connected_msg.get("slot_data"), ap_output_dir)
            if roadmap_order:
                print(f"[ROADMAP] Loaded slot order from {roadmap_source}.")
                for slot in range(1, 16):
                    print(f"[ROADMAP] Slot {slot:02d}: {roadmap_order[slot]}")
            else:
                print("[ROADMAP] No slot order source found. Stage unlock writes will use old direct fallback bytes.")
        except Exception as e:
            print(f"[ROADMAP] Slot order pusher/translation disabled: {e}")

        item_state = ItemState(received_initial)
        applier = MemoryApplier(rw, item_state, roadmap_order)
        watcher = ProgressWatcher(rw, item_state)

        def process_received_items_msg(msg: Dict[str, Any], source: str) -> None:
            nonlocal last_idx
            start_index = int(msg.get("index", 0))
            items = msg.get("items", []) or []
            if not items:
                return
            print(f"[ITEMS] Processing {len(items)} item(s) from {source}, index={start_index}")
            for i, net_item in enumerate(items):
                item_index = start_index + i
                if item_index <= last_idx:
                    continue
                item_id = int(net_item.get("item"))
                item_name = item_id_to_name.get(item_id, f"ItemID_{item_id}")
                print(f"[ITEM] idx={item_index} {item_name}")
                item_state.add(item_name)
                if rw.ensure_hooked():
                    with contextlib.suppress(Exception):
                        applier.apply_received_once(item_name)
                last_idx = item_index
            state["last_item_index"] = int(last_idx)
            state["received_items"] = item_state.names()
            _save_json(profile_path, state)

        if pending_msgs:
            print(f"[AP] Processing {len(pending_msgs)} buffered early message(s).")
            for msg in pending_msgs:
                if msg.get("cmd") == "ReceivedItems":
                    process_received_items_msg(msg, "buffered")

        print("[DOLPHIN] Waiting for Dolphin hook...")
        while not rw.ensure_hooked():
            await asyncio.sleep(0.5)
        print("[DOLPHIN] Hooked! Ready to play.")
        print("[APPLY] Applying already-owned/precollected stage unlocks once after hook.")
        applier.apply_initial_stage_unlocks_once()

        roadmap_task: Optional[asyncio.Task] = None
        if roadmap_order:
            roadmap_task = asyncio.create_task(RoadmapPusher(rw, roadmap_order, roadmap_source).run_loop())

        async def location_watch_loop() -> None:
            nonlocal sent_location_names
            while True:
                try:
                    if not rw.ensure_hooked():
                        await asyncio.sleep(0.5)
                        continue
                    names = watcher.poll()
                    if names:
                        ids: List[int] = []
                        for name in names:
                            is_sooper_retry = name in SOOPER_SECRET_FLAG_LOCATIONS
                            # RC6.42: checked_locations from the AP server is treated as
                            # truth on connect, so it is now safe to stop retrying once
                            # this run has successfully sent/recorded the check.  Older
                            # RC6.39-style hard retry spammed Sooper checks every poll
                            # while the flag stayed at 1.
                            if name in sent_location_names:
                                continue
                            loc_id = location_name_to_id.get(name)
                            if loc_id is None:
                                log.info(f"[NEED] Location name not in DataPackage: {name}")
                                if is_sooper_retry:
                                    print(f"[SOOPER DEBUG] {name} flag is active but location is not in DataPackage")
                                continue
                            if is_sooper_retry:
                                print(f"[SOOPER SEND] Offering {name} as location id {int(loc_id)}")
                            sent_location_names.add(name)
                            ids.append(int(loc_id))
                        if ids:
                            await _send(ws, {"cmd": "LocationChecks", "locations": ids})
                            state["sent_location_names"] = sorted(sent_location_names)
                            _save_json(profile_path, state)
                            print(f"[CHECK] Sent {len(ids)} check(s): {[id_to_location.get(i, i) for i in ids]}")
                    await asyncio.sleep(POLL_LOCATION_SECONDS)
                except asyncio.CancelledError:
                    return
                except Exception as e:
                    log.info(f"[WATCH] retry after error: {e}")
                    await asyncio.sleep(0.5)

        async def memory_apply_loop() -> None:
            last_apply_error: Optional[str] = None
            while True:
                try:
                    if rw.ensure_hooked():
                        applier.continuous_apply()
                    await asyncio.sleep(POLL_BLOCK_SECONDS)
                except asyncio.CancelledError:
                    return
                except Exception as e:
                    msg = f"{type(e).__name__}: {e}"
                    if msg != last_apply_error:
                        print(f"[APPLY ERROR] memory/blocker loop failed: {msg}")
                        last_apply_error = msg
                    await asyncio.sleep(0.25)

        watch_task = asyncio.create_task(location_watch_loop())
        apply_task = asyncio.create_task(memory_apply_loop())

        print("[KND] Running. Leave this window open while you play.")
        try:
            async for raw in ws:
                msgs = json.loads(raw)
                for msg in msgs:
                    cmd = msg.get("cmd")
                    if cmd == "ReceivedItems":
                        process_received_items_msg(msg, "live")
                    elif cmd == "RoomUpdate":
                        if "checked_locations" in msg:
                            for loc_id in msg.get("checked_locations", []) or []:
                                loc_name = id_to_location.get(int(loc_id))
                                if loc_name:
                                    sent_location_names.add(loc_name)
                            state["sent_location_names"] = sorted(sent_location_names)
                            _save_json(profile_path, state)
                    elif cmd == "PrintJSON":
                        print(f"[MSG] {msg.get('type')}: {msg.get('data')}")
        finally:
            for task in (watch_task, apply_task, roadmap_task):
                if task:
                    task.cancel()
                    with contextlib.suppress(BaseException):
                        await task


def main() -> None:
    try:
        settings = prompt_settings()
        integrated_easy_run_prepare(
            settings.get("ap_output_dir", ""),
            settings.get("active_game_dir", ""),
            settings.get("archive_runs_dir", ""),
        )
        asyncio.run(run_client(
            settings["connect"],
            settings["player"],
            settings.get("password", ""),
            settings.get("profile_override", ""),
            settings.get("ap_output_dir", ""),
            settings.get("active_game_dir", ""),
            settings.get("archive_runs_dir", ""),
        ))
    except KeyboardInterrupt:
        pass
    except SystemExit:
        raise
    except Exception as e:
        print(f"\n[ERROR] {e}")
        input("Press Enter to close...")


if __name__ == "__main__":
    main()
