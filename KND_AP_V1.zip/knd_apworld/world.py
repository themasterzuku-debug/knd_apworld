# world.py
# KND (GameCube) Archipelago world - Core world glue
#
# This file:
# - Builds regions (via regions.py)
# - Adds locations (via locations.py)
# - Creates item pool (via items.py)
# - Applies access rules (difficulty + fixed/loose behaviors)
# - Locks Victory onto Stage_14_Lunarumble_Complete
#
# V0 DESIGN NOTE:
# The client/game side is moving toward a randomized campaign-slot model:
#   - AP still exposes Stage_X_Unlock item names for compatibility.
#   - In practice, those unlocks may correspond to randomized stage slots in the client/patch.
#   - Completion detection is handled by the client via stage/cutscene/roadmap state, not by vanilla slot-unlock bytes.
#
# IMPORTANT:
# - This is “full world.py” for the AP side.
# - It does NOT patch the GameCube ROM or enforce in-game routing. That is client/patch work.
# - It DOES define the logic graph + item placement + completion condition.

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import re

from BaseClasses import MultiWorld, Region, Location
from worlds.AutoWorld import World, WebWorld
from worlds.generic.Rules import set_rule, add_item_rule

from .regions import create_regions, STAGE_REGIONS, REGION_MENU
from .locations import LOCATION_DATA, LOCATION_ID_TABLE, LocationData
from .items import (
    ITEM_DATA,
    ITEM_ID_TABLE,
    ItemData,
    make_item,
)
from .options import KNDOptions, LogicMode, DifficultyAssumption, BossKeyMode


# -------------------------
# World metadata
# -------------------------

class KNDWeb(WebWorld):
    theme = "party"
    tutorials = []


class KNDLocation(Location):
    game = "Codename: Kids Next Door (GC)"


class KNDWorld(World):
    """
    Codename: Kids Next Door (GC) Archipelago world.
    """
    game = "Codename: Kids Next Door (GC)"
    web = KNDWeb()

    options_dataclass = KNDOptions  # type: ignore
    options: KNDOptions

    # AP expects these for ID lookup
    item_name_to_id = ITEM_ID_TABLE
    location_name_to_id = LOCATION_ID_TABLE

    # Item groups for hints/tracker clarity.
    item_name_groups: Dict[str, List[str]] = {
        "Operatives": [
            "Operative_N1", "Operative_N2", "Operative_N3", "Operative_N4", "Operative_N5",
        ],
        "Moves": [
            "Move_N1_Grappluh",
            "Move_N3_Progressive_Movement",
            "Move_N4_DoubleJump",
            "Move_N5_DoubleJump", "Move_N5_WallJump",
        ],
        "Rainbow Monkey Cappers": [
            "Progressive_Rainbow_Monkey_Capper_N1",
            "Progressive_Rainbow_Monkey_Capper_N2",
            "Progressive_Rainbow_Monkey_Capper_N3",
            "Progressive_Rainbow_Monkey_Capper_N4",
            "Progressive_Rainbow_Monkey_Capper_N5",
        ],
        "Stage Unlocks": [
            "Stage_01_Tutorial_Unlock", "Stage_02_Donutty_Unlock", "Stage_03_Boogification_Unlock",
            "Stage_04_SnotBomber_Unlock", "Stage_05_Spank_Happy_Unlock", "Stage_06_Hamsterama_Unlock",
            "Stage_07_Spankarific_Unlock", "Stage_08_Tarpoon_Unlock", "Stage_09_Ship_Shape_Unlock",
            "Stage_10_Brush_Off_Unlock", "Stage_11_Cavity_Cave_Unlock", "Stage_12_Overflow_Unlock",
            "Stage_13_MoonTrip_Unlock", "Stage_14_Lunarumble_Unlock", "Stage_15_Credits_Unlock",
        ],
        "Weapons": [
            "Gumzooka_Unjammed", "Scampp_Unjammed", "Bajooka_Unjammed",
            "2x4_N2_SnotBomber_Weapons_System_Online", "2x4_N2_Tarpoon_Weapons_System_Online",
            "2x4_N2_MoonTrip_Weapons_System_Online",
            "2x4_N5_Boogification_Smellmet_Crafted", "Frappe_Unjammed", "Thumper_Unjammed",
            "Splanker_Unjammed", "Sluggah_Unjammed",
        ],
        "CoolBus Progressives": [
            "2x4_N2_SnotBomber_Progressive_Upgrade",
            "2x4_N2_Tarpoon_Progressive_Upgrade",
            "2x4_N2_MoonTrip_Progressive_Upgrade",
        ],
        "Boss Keys": ["BossKey"],
    }

    # Stage -> operative mapping (per your confirmed mapping)
    STAGE_TO_OPERATIVE: Dict[str, str] = {
        "Stage_01_Tutorial": "Operative_N1",
        "Stage_02_Donutty": "Operative_N1",
        "Stage_03_Boogification": "Operative_N5",
        "Stage_04_SnotBomber": "Operative_N2",
        "Stage_05_Spank_Happy": "Operative_N4",
        "Stage_06_Hamsterama": "Operative_N3",
        "Stage_07_Spankarific": "Operative_N1",
        "Stage_08_Tarpoon": "Operative_N2",
        "Stage_09_Ship_Shape": "Operative_N5",
        "Stage_10_Brush_Off": "Operative_N3",
        "Stage_11_Cavity_Cave": "Operative_N1",
        "Stage_12_Overflow": "Operative_N4",
        "Stage_13_MoonTrip": "Operative_N2",
        "Stage_14_Lunarumble": "Operative_N1",  # you said “we’ll say N1”
        "Stage_15_Credits": "Operative_N2",
    }

    OPERATIVE_TO_MONKEY_CAPPER: Dict[str, str] = {
        "Operative_N1": "Progressive_Rainbow_Monkey_Capper_N1",
        "Operative_N2": "Progressive_Rainbow_Monkey_Capper_N2",
        "Operative_N3": "Progressive_Rainbow_Monkey_Capper_N3",
        "Operative_N4": "Progressive_Rainbow_Monkey_Capper_N4",
        "Operative_N5": "Progressive_Rainbow_Monkey_Capper_N5",
    }

    # Weapon_Check logic rule:
    # A Weapon_Check is credited by first successful Y/stage-weapon activation,
    # so AP must not consider that check reachable until the matching weapon/Y
    # unblock item is owned. This prevents a stage unlock or other progression
    # item from landing behind a Weapon_Check that the player cannot trigger yet.
    WEAPON_CHECK_TO_WEAPON_ITEM: Dict[str, str] = {
        "Stage_02_Donutty_Gumzooka_Unjammed": "Gumzooka_Unjammed",
        
        "Stage_04_SnotBomber_Weapon_Check": "2x4_N2_SnotBomber_Weapons_System_Online",
        "Stage_05_Spank_Happy_Splanker_Unjammed": "Splanker_Unjammed",
        "Stage_06_Hamsterama_Frappe_Unjammed": "Frappe_Unjammed",
        "Stage_07_Spankarific_Scampp_Unjammed": "Scampp_Unjammed",
        "Stage_08_Tarpoon_Weapon_Check": "2x4_N2_Tarpoon_Weapons_System_Online",
        "Stage_10_Brush_Off_Thumper_Unjammed": "Thumper_Unjammed",
        "Stage_11_Cavity_Cave_Bajooka_Unjammed": "Bajooka_Unjammed",
        "Stage_12_Overflow_Sluggah_Unjammed": "Sluggah_Unjammed",
        "Stage_13_MoonTrip_Weapon_Check": "2x4_N2_MoonTrip_Weapons_System_Online",
    }

    # Rainbow Monkey capper logic rule:
    # Base access allows the first monkey tier only. Each capper raises the AP
    # location cap by one tier: 50, 75, then 100. Credits uses its own 10/20/30/40
    # numbers, mapped onto the same four tiers.
    MONKEY_THRESHOLD_TO_CAPPER_COUNT: Dict[int, int] = {
        10: 0, 20: 1, 30: 2, 40: 3,
        25: 0, 50: 1, 75: 2, 100: 3,
    }

    # Custom OR requirements that LocationData's simple tuple model cannot express.
    # These are ANDed with any normal requirements/capper requirements, then at
    # least one listed alternative must be satisfied.
    LOCATION_OR_REQUIREMENTS_BY_DIFFICULTY: Dict[str, Dict[str, Tuple[Tuple[str, ...], ...]]] = {
        # Stage 3 / Boogification: Hard/Expert can use either N5 movement ability.
        "Stage_03_Boogification_Complete": {
            "hard": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
            "expert": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
        },
        "Stage_03_Boogification_Secret_50_Monkeys": {
            "hard": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
            "expert": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
        },
        "Stage_03_Boogification_Secret_75_Monkeys": {
            "hard": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
            "expert": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
        },
        "Stage_03_Boogification_Secret_100_Monkeys": {
            "hard": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
            "expert": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
        },
        "Stage_03_Boogification_SooperSecret_2": {
            "hard": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
            "expert": (("Move_N5_DoubleJump",), ("Move_N5_WallJump",)),
        },
        # Stage_03_Boogification_Smellmet_Crafted is intentionally not in this OR table:
        # it specifically requires Move_N5_DoubleJump because one of the three spare parts
        # cannot be reached with WallJump alone.

        # Stage 6 / Hamsterama: Complete and 75 can be done with Glide OR Frappe.
        "Stage_06_Hamsterama_Complete": {
            "standard": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "moderate": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "hard": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "expert": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
        },
        "Stage_06_Hamsterama_Secret_75_Monkeys": {
            "standard": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "moderate": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "hard": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
            "expert": (("Move_N3_Progressive_Movement", "Move_N3_Progressive_Movement"), ("Frappe_Unjammed",)),
        },
    }


    # Region name -> Stage unlock item.
    # V0 compatibility note:
    # These are still named Stage_X_Unlock so existing items.py/locations.py/client code does not break.
    # The client/patch may interpret them as randomized slot unlocks once the roadmap shuffle is wired.
    STAGE_TO_UNLOCK_ITEM: Dict[str, str] = {
        "Stage_01_Tutorial": "Stage_01_Tutorial_Unlock",
        "Stage_02_Donutty": "Stage_02_Donutty_Unlock",
        "Stage_03_Boogification": "Stage_03_Boogification_Unlock",
        "Stage_04_SnotBomber": "Stage_04_SnotBomber_Unlock",
        "Stage_05_Spank_Happy": "Stage_05_Spank_Happy_Unlock",
        "Stage_06_Hamsterama": "Stage_06_Hamsterama_Unlock",
        "Stage_07_Spankarific": "Stage_07_Spankarific_Unlock",
        "Stage_08_Tarpoon": "Stage_08_Tarpoon_Unlock",
        "Stage_09_Ship_Shape": "Stage_09_Ship_Shape_Unlock",
        "Stage_10_Brush_Off": "Stage_10_Brush_Off_Unlock",
        "Stage_11_Cavity_Cave": "Stage_11_Cavity_Cave_Unlock",
        "Stage_12_Overflow": "Stage_12_Overflow_Unlock",
        "Stage_13_MoonTrip": "Stage_13_MoonTrip_Unlock",
        "Stage_14_Lunarumble": "Stage_14_Lunarumble_Unlock",
        "Stage_15_Credits": "Stage_15_Credits_Unlock",
    }

    # Fixed BossKey placements (your “toilet key + boss keys tied to specific stages” baseline)
    # 8 total: Tutorial Toilet Secret + Stage clears for 2,4,5,7,9,11,12
    FIXED_BOSSKEY_LOCATIONS: Tuple[str, ...] = (
        "Stage_01_Tutorial_Secret",         # Toilet secret -> BossKey (hilarious, as requested)
        "Stage_02_Donutty_Complete",        # Stuffum
        "Stage_04_SnotBomber_Complete",     # Common Cold
        "Stage_05_Spank_Happy_Complete",    # Vampire KND
        "Stage_07_Spankarific_Complete",    # Count Spankulot
        "Stage_09_Ship_Shape_Complete",     # Stickybeard
        "Stage_11_Cavity_Cave_Complete",    # Knightbrace
        "Stage_12_Overflow_Complete",       # Toiletnator
    )

    # Victory location name (event)
    VICTORY_LOCATION = "Stage_14_Lunarumble_Complete"

    # “Gate” items for final stage (tuned later if you add options)
    FINAL_REQUIRED_BOSSKEYS = len(FIXED_BOSSKEY_LOCATIONS)
    FINAL_REQUIRED_COSMETIC = "Outfit_N1_N86"

    ALL_OPERATIVES_REQUIRED: Tuple[str, ...] = (
        "Operative_N1",
        "Operative_N2",
        "Operative_N3",
        "Operative_N4",
        "Operative_N5",
    )

    # "All Levels Unlocked" gate. This is AP-side logic; the Dolphin client still
    # handles the actual roadmap/native unlock writes.
    ALL_STAGE_UNLOCK_ITEMS: Tuple[str, ...] = tuple(STAGE_TO_UNLOCK_ITEM.values())

    # Credits should not be playable just because Stage_15_Credits_Unlock appears.
    # It also requires every previous level's unlock, so finding Credits cannot
    # accidentally open a previous stage/slot out of order.
    CREDITS_PREVIOUS_UNLOCK_ITEMS: Tuple[str, ...] = tuple(
        unlock
        for stage, unlock in STAGE_TO_UNLOCK_ITEM.items()
        if stage != "Stage_15_Credits"
    )

    # Credits is genuinely late: it requires all previous stage unlocks.
    # Therefore, do not allow stage unlocks that are part of the Credits
    # access gate to be placed inside Credits itself. That creates a logical
    # fill choke/circle while still preserving the real in-game Credits gate.
    # N2 is also banned because Credits requires Operative_N2 to enter.
    CREDITS_BANNED_ITEM_PLACEMENTS: Tuple[str, ...] = tuple(STAGE_TO_UNLOCK_ITEM.values()) + (
        "Operative_N2",
    )

    # -------------------------
    # AP lifecycle
    # -------------------------

    def create_regions(self) -> None:
        # Build regions + Menu->Stage entrances
        self._regions = create_regions(self)

        # Attach locations to regions
        for loc in LOCATION_DATA:
            region = self._regions[loc.region]
            loc_obj = KNDLocation(self.player, loc.name, LOCATION_ID_TABLE[loc.name], region)
            region.locations.append(loc_obj)

    def create_items(self) -> None:
        # Determine bosskey placement behavior.
        # Your requested behavior: in Loose logic, allow “fixed” to be included in pool.
        bosskey_mode = self.options.bosskey_mode.value

        if self.options.logic_mode.value == LogicMode.option_loose and self.options.include_fixed_items_in_pool_when_loose.value:
            # Override for fun: loose logic defaults to shuffled pool behavior.
            bosskey_mode = BossKeyMode.option_shuffle

        # Build the pool
        pool = []

        # Starting stage unlocks + required operatives are precollected, so
        # they must be removed from the random pool and replaced with filler.
        # Otherwise a start item can appear again in the spoiler as if it were
        # still progression.
        starting_required_skips = Counter(self._starting_required_pool_omissions())
        skipped_starting_required_count = 0

        # One starting bonus item is granted and omitted from the pool to keep
        # location/item counts balanced after removing outfit rewards.
        # Normal starts grant the first operative's Rainbow Monkey Capper.
        # Special case: N5 starting in Stage 3 / Boogification needs movement
        # access, so it grants either N5 DoubleJump or N5 WallJump instead.
        starting_bonus_skip = self._starting_bonus_pool_skip()
        skipped_starting_bonus = False

        for it in ITEM_DATA:
            # Victory is an event: never in pool (we place it directly on Stage 14 completion)
            if it.name == "Victory":
                continue

            # If BossKeys are fixed, do not add them to the pool (they are lock-placed).
            if it.name == "BossKey" and bosskey_mode == BossKeyMode.option_fixed:
                continue

            # Add N copies for counted items
            copies = max(1, it.count)

            # Remove any start-stage unlock/operator items from the pool.
            # Replace them with filler after the loop so item/location counts stay balanced.
            required_skip_count = min(copies, starting_required_skips.get(it.name, 0))
            if required_skip_count:
                copies -= required_skip_count
                starting_required_skips[it.name] -= required_skip_count
                skipped_starting_required_count += required_skip_count

            if it.name == starting_bonus_skip and not skipped_starting_bonus:
                copies -= 1
                skipped_starting_bonus = True

            for _ in range(max(0, copies)):
                pool.append(make_item(it.name, self.player))

        for _ in range(skipped_starting_required_count):
            pool.append(make_item("Rainbow_Monkey", self.player))

        self.multiworld.itempool += pool

    def set_rules(self) -> None:
        # Difficulty key for requires_by_difficulty
        diff_key = self._difficulty_key()

        # 1) Stage entrance rules (Menu -> Stage_X)
        # AP-side rule: you need the stage/slot unlock item AND the correct operative.
        # Game-side enforcement/slot routing is handled by the Dolphin client/patch.
        menu = self._regions[REGION_MENU]
        for stage_region_name in STAGE_REGIONS:
            # Find the entrance created in regions.py:
            # name is "Menu -> {stage}"
            entrance_name = f"Menu -> {stage_region_name}"
            entrance = next(e for e in menu.exits if e.name == entrance_name)

            unlock_item = self.STAGE_TO_UNLOCK_ITEM[stage_region_name]
            operative_item = self.STAGE_TO_OPERATIVE[stage_region_name]

            # Base: need both stage unlock + correct operative.
            # Stage 3 / Boogification is not useful with 0 N5 movement upgrades:
            # even the 25-monkey check is effectively unreachable, and Smellmet
            # Crafted separately requires N5 Double Jump.  Preserve Stage 3 as a
            # possible starting stage by granting a starting N5 movement bonus, but
            # do not let a non-start Stage 3 unlock count as progression space until
            # either N5 movement upgrade is owned.
            if stage_region_name == "Stage_03_Boogification":
                def _base_stage_rule(state, u=unlock_item, op=operative_item):
                    return (
                        state.has(u, self.player)
                        and state.has(op, self.player)
                        and (
                            state.has("Move_N5_DoubleJump", self.player)
                            or state.has("Move_N5_WallJump", self.player)
                        )
                    )
            else:
                def _base_stage_rule(state, u=unlock_item, op=operative_item):
                    return state.has(u, self.player) and state.has(op, self.player)

            set_rule(entrance, _base_stage_rule)

        # 2) Final stage extra gates (bosskeys + N86 outfit)
        # Keep these as local closure values instead of helper/class lookups.
        # Archipelago calls access rules through AutoWorld, and missing helper/class
        # attributes can surface as opaque AttributeError crashes during fill.
        final_entrance = next(e for e in self._regions[REGION_MENU].exits if e.name == "Menu -> Stage_14_Lunarumble")
        all_stage_unlock_items = tuple(self.STAGE_TO_UNLOCK_ITEM.values())
        all_operatives_required = (
            "Operative_N1",
            "Operative_N2",
            "Operative_N3",
            "Operative_N4",
            "Operative_N5",
        )
        final_required_cosmetic = "Outfit_N1_N86"
        final_required_bosskeys = len(self.FIXED_BOSSKEY_LOCATIONS)

        def _final_rule(state):
            return (
                state.has(self.STAGE_TO_UNLOCK_ITEM["Stage_14_Lunarumble"], self.player)
                and all(state.has(item_name, self.player) for item_name in all_stage_unlock_items)
                and all(state.has(item_name, self.player) for item_name in all_operatives_required)
                and state.has(final_required_cosmetic, self.player)
                and state.has("BossKey", self.player, final_required_bosskeys)
            )

        set_rule(final_entrance, _final_rule)

        # 2b) Credits extra gate.
        # Credits needs its own unlock, N2, and every previous level unlock.
        # This prevents Stage_15_Credits_Unlock from being enough to enter Credits
        # while earlier stages/slots are still unavailable.
        credits_entrance = next(e for e in self._regions[REGION_MENU].exits if e.name == "Menu -> Stage_15_Credits")
        credits_previous_unlock_items = tuple(
            unlock_item
            for stage_name, unlock_item in self.STAGE_TO_UNLOCK_ITEM.items()
            if stage_name != "Stage_15_Credits"
        )

        def _credits_rule(state):
            return (
                state.has(self.STAGE_TO_UNLOCK_ITEM["Stage_15_Credits"], self.player)
                and state.has(self.STAGE_TO_OPERATIVE["Stage_15_Credits"], self.player)
                and all(state.has(item_name, self.player) for item_name in credits_previous_unlock_items)
            )

        set_rule(credits_entrance, _credits_rule)

        # Credits placement safety:
        # Keep the accurate late Credits access rule, but do not let items that
        # unlock Credits itself be placed inside Credits. This avoids
        # restrictive-fill failures such as a required Stage_X_Unlock ending up
        # with only Credits locations left as candidates. Non-gate progression
        # like BossKeys, N86, cappers, or weapons may still appear here if the
        # normal location rules allow them.
        credits_banned_items = tuple(self.CREDITS_BANNED_ITEM_PLACEMENTS)
        for credits_loc_name in (
            "Stage_15_Credits_Complete",
            "Stage_15_Credits_Secret_10_Monkeys",
            "Stage_15_Credits_Secret_20_Monkeys",
            "Stage_15_Credits_Secret_30_Monkeys",
            "Stage_15_Credits_Secret_40_Monkeys",
        ):
            credits_loc = self.multiworld.get_location(credits_loc_name, self.player)
            add_item_rule(
                credits_loc,
                lambda item, banned=credits_banned_items: item.name not in banned,
            )

        # 3) Location rules (difficulty requirements + unconditional requires)
        for loc in LOCATION_DATA:
            loc_obj = self.multiworld.get_location(loc.name, self.player)

            req_all: List[str] = list(loc.requires)

            if loc.requires_by_difficulty:
                req_all.extend(list(loc.requires_by_difficulty.get(diff_key, ())))

            # Weapon_Checks need the matching weapon/Y unblock item because the
            # runtime check is first successful stage-weapon activation.
            weapon_item = self.WEAPON_CHECK_TO_WEAPON_ITEM.get(loc.name)
            if weapon_item:
                req_all.append(weapon_item)

                # Belt-and-suspenders: do not allow a weapon's own AP item on
                # the Weapon_Check that requires it. The access rule should
                # already prevent this for progression fill, but this makes the
                # intent explicit for every generator/accessibility mode.
                add_item_rule(
                    loc_obj,
                    lambda item, banned_weapon=weapon_item: item.name != banned_weapon,
                )

            # Rainbow Monkey secret checks are capped per operative.
            # Example: 75 monkeys requires two matching Progressive Cappers.
            capper_req = self._monkey_capper_requirement(loc.name, loc.region)
            if capper_req:
                capper_item, count = capper_req
                req_all.extend([capper_item] * count)

            alt_reqs = self.LOCATION_OR_REQUIREMENTS_BY_DIFFICULTY.get(loc.name, {}).get(diff_key, ())

            if req_all or alt_reqs:
                set_rule(loc_obj, self._items_required_rule(tuple(req_all), tuple(alt_reqs)))

        # 4) Completion condition: obtain Victory (placed on Stage 14 completion location)
        self.multiworld.completion_condition[self.player] = lambda state: state.has("Victory", self.player)

    def generate_basic(self) -> None:
        """
        Locked placements + starting items (safe, deterministic AP-side behaviors).
        """
        # Place Victory on Stage 14 completion
        victory_loc = self.multiworld.get_location(self.VICTORY_LOCATION, self.player)
        victory_loc.place_locked_item(make_item("Victory", self.player))

        # BossKey placement policy
        bosskey_mode = self.options.bosskey_mode.value
        if self.options.logic_mode.value == LogicMode.option_loose and self.options.include_fixed_items_in_pool_when_loose.value:
            bosskey_mode = BossKeyMode.option_shuffle

        if bosskey_mode == BossKeyMode.option_fixed:
            # Lock place 8 BossKeys on your chosen “fixed” locations
            for loc_name in self.FIXED_BOSSKEY_LOCATIONS:
                self.multiworld.get_location(loc_name, self.player).place_locked_item(make_item("BossKey", self.player))

        # Starting slots: precollect stage unlock + operative for the starting playable stages.
        # In V0, these still use stage-named unlocks; the client/patch can translate them to randomized slots.
        self._grant_starting_slots()


    def write_spoiler(self, spoiler_handle) -> None:
        """
        Adds KND-specific routing notes to the AP spoiler log.
        This does not currently generate a full randomized slot table; it documents
        the fixed/canon constraints that the AP logic is enforcing.
        """
        spoiler_handle.write("\n\nKND V1 Slot / Canon Routing Notes:\n")
        spoiler_handle.write("  Campaign flow is treated as linear Slot 1 -> Slot 15.\n")
        spoiler_handle.write("  Canon/fixed chain slots:\n")
        spoiler_handle.write("    Slot 7  = Stage_07_Spankarific chain, then 7B, then Slot 8.\n")
        spoiler_handle.write("    Slot 10 = Stage_10_Brush_Off chain, then 10B, then Slot 11.\n")
        spoiler_handle.write("    Slot 11 = Stage_11_Cavity_Cave chain, then 11B, then Slot 12.\n")
        spoiler_handle.write("    Slot 14 = Stage_14_Lunarumble / final.\n")
        spoiler_handle.write("  Single-start Slot 1 exclusions: Stage 2, Stage 7, Stage 10, Stage 11, Stage 14, Stage 15.\n")
        spoiler_handle.write("  Multi-start note: Stage 2/7/10/11 may be extra starting unlocks when Starting Stage Slots >= 2.\n")
        spoiler_handle.write("  Canon-slot guard thresholds:\n")
        spoiler_handle.write("    Stage_07_Spankarific requires 7 total stage unlocks before AP logic treats it as reachable.\n")
        spoiler_handle.write("    Stage_10_Brush_Off requires 10 total stage unlocks before AP logic treats it as reachable.\n")
        spoiler_handle.write("    Stage_11_Cavity_Cave requires 11 total stage unlocks before AP logic treats it as reachable.\n")
        spoiler_handle.write("  Final lock: Lunarumble requires all Stage Unlocks, all Operatives, N86, and all BossKeys.\n")
        spoiler_handle.write("  Credits lock: Credits requires Stage_15_Credits_Unlock plus all previous stage unlocks.\n")
        spoiler_handle.write("  Credits placement safety: Stage unlocks and Operative_N2 cannot be placed inside Credits.\n")
        spoiler_handle.write("  Stage 3 / Boogification access requires N5 plus either N5 WallJump or N5 DoubleJump; Smellmet Crafted specifically requires N5 DoubleJump.\n")
        spoiler_handle.write("  Sooper Secret locations exist only in Stages 1, 3, 5, 6, and 7.\n")
        spoiler_handle.write("  Item pool note: Sooper/costume rewards were removed; N86 remains as a cheat-code outfit gate.\n")
        spoiler_handle.write("  Starting stage unlock(s) + operative(s) are precollected and replaced by filler in the pool.\n")
        spoiler_handle.write("  One bonus for the first starting stage is precollected and omitted from the pool.\n")
        spoiler_handle.write("  Note: this world.py does not yet emit a true randomized roadmap/slot table.\n")
        spoiler_handle.write("        It documents AP-side access assumptions only.\n")

    # -------------------------
    # Helpers
    # -------------------------

    def _monkey_capper_requirement(self, location_name: str, stage_region_name: str) -> Optional[Tuple[str, int]]:
        """
        Returns (capper_item, count_needed) for Rainbow Monkey tier locations.

        Base/0 cappers reaches the first tier only. The first, second, and third
        matching cappers unlock the second, third, and fourth monkey tiers.
        """
        if "Monkeys" not in location_name:
            return None

        match = re.search(r"_(\d+)_Monkeys$", location_name)
        if not match:
            return None

        threshold = int(match.group(1))
        count_needed = self.MONKEY_THRESHOLD_TO_CAPPER_COUNT.get(threshold)
        if count_needed is None or count_needed <= 0:
            return None

        operative = self.STAGE_TO_OPERATIVE.get(stage_region_name)
        if not operative:
            return None

        capper_item = self.OPERATIVE_TO_MONKEY_CAPPER.get(operative)
        if not capper_item:
            return None

        return capper_item, count_needed

    def _difficulty_key(self) -> str:
        # Map options enum -> string key used in locations.py
        val = self.options.difficulty_assumption.value
        if val == DifficultyAssumption.option_standard:
            return "standard"
        if val == DifficultyAssumption.option_moderate:
            return "moderate"
        if val == DifficultyAssumption.option_hard:
            return "hard"
        return "expert"

    def _items_required_rule(self, required: Tuple[str, ...], alternatives: Tuple[Tuple[str, ...], ...] = ()):  # AND requirements + optional OR alternatives
        required_counts = Counter(required)
        alternative_counts = tuple(Counter(alt) for alt in alternatives)

        def rule(state):
            if not all(
                state.has(name, self.player, count)
                for name, count in required_counts.items()
            ):
                return False

            if alternative_counts and not any(
                all(state.has(name, self.player, count) for name, count in alt_counts.items())
                for alt_counts in alternative_counts
            ):
                return False

            return True

        return rule

    def _has_all_items(self, state, item_names: Tuple[str, ...]) -> bool:
        """Return True if the player owns every item in the given tuple/list."""
        return all(state.has(name, self.player) for name in item_names)

    def _get_starting_stages(self) -> List[str]:
        """
        Cached starting-stage picker so create_items() and generate_basic() agree.

        V1 starting-slot safety rules:
        - Slot 1 must be a clean single-start stage.
        - Stage 2 / Donutty is excluded only from Slot 1 because it behaves
          weirdly when it is the first loaded stage, but it is allowed as an
          extra starting unlock when Starting Stage Slots >= 2.
        - Stages 7, 10, and 11 are fixed/locked-chain stages. They are not
          allowed as the sole Slot 1 start, but they are allowed as extra
          starting unlocks when the player opted into multiple starting stages.
        - Stage 14 stays final and never starts.
        - Stage 15 / Credits is not used as a starting stage for V1 because
          real Credits access still depends on the previous campaign unlocks.
        """
        cached = getattr(self, "_knd_cached_starting_stages", None)
        if cached is not None:
            return list(cached)

        count = int(self.options.starting_stage_slots.value)

        # These cannot be the actual Slot 1 / single-start stage.
        slot1_blocked_stages = {
            "Stage_02_Donutty",
            "Stage_07_Spankarific",
            "Stage_10_Brush_Off",
            "Stage_11_Cavity_Cave",
            "Stage_14_Lunarumble",
            "Stage_15_Credits",
        }

        # These cannot be starting unlocks at all in V1.
        # 7/10/11 and Donutty are allowed here for multi-start, but not Slot 1.
        always_blocked_starting_stages = {
            "Stage_14_Lunarumble",
            "Stage_15_Credits",
        }

        slot1_candidates = [
            s for s in STAGE_REGIONS
            if s not in slot1_blocked_stages
        ]

        if not slot1_candidates:
            self._knd_cached_starting_stages = tuple()
            return []

        first_stage = self.random.choice(slot1_candidates)

        if count <= 1:
            chosen = [first_stage]
        else:
            extra_candidates = [
                s for s in STAGE_REGIONS
                if s != first_stage and s not in always_blocked_starting_stages
            ]
            extra_count = min(count - 1, len(extra_candidates))
            chosen = [first_stage] + self.random.sample(extra_candidates, k=extra_count)

        self._knd_cached_starting_stages = tuple(chosen)
        return list(chosen)

    def _starting_required_pool_omissions(self) -> Tuple[str, ...]:
        """
        Return unique start-stage unlock/operative items that are precollected
        and should therefore be removed from the random item pool.

        These are replaced with Rainbow_Monkey filler in create_items() so the
        item/location count stays stable while the spoiler no longer shows the
        player's starting stage or operative as later progression.
        """
        chosen = self._get_starting_stages()
        result: List[str] = []
        seen = set()

        for stage in chosen:
            unlock_item = self.STAGE_TO_UNLOCK_ITEM[stage]
            op_item = self.STAGE_TO_OPERATIVE[stage]

            for item_name in (unlock_item, op_item):
                if item_name not in seen:
                    result.append(item_name)
                    seen.add(item_name)

        return tuple(result)

    def _starting_bonus_pool_skip(self) -> Optional[str]:
        """
        Return the single starting bonus item that should be precollected and
        omitted from the pool so the total item/location count stays balanced.

        Normal behavior:
            first starting operative gets one matching Rainbow Monkey Capper.

        Special case:
            If the first starting stage is Stage 3 / Boogification, N5 can be
            trapped before enough monkeys/checks without at least one movement
            upgrade. In that case, do not grant the starting N5 capper. Grant
            one N5 movement upgrade instead: either DoubleJump or WallJump.
        """
        cached = getattr(self, "_knd_cached_starting_bonus_item", None)
        if cached is not None:
            return cached

        chosen = self._get_starting_stages()
        if not chosen:
            self._knd_cached_starting_bonus_item = None
            return None

        first_stage = chosen[0]
        if first_stage == "Stage_03_Boogification":
            # Both are valid: WallJump is the intended route and DoubleJump can
            # bypass the opening section. Pick deterministically from this seed.
            item = self.random.choice(("Move_N5_DoubleJump", "Move_N5_WallJump"))
            self._knd_cached_starting_bonus_item = item
            return item

        if first_stage == "Stage_09_Ship_Shape":
            item = "Move_N5_WallJump"
            self._knd_cached_starting_bonus_item = item
            return item

        if first_stage == "Stage_06_Hamsterama":
            # Frappe can substitute for Glide for completion and 75 monkeys.
            item = "Frappe_Unjammed"
            self._knd_cached_starting_bonus_item = item
            return item

        if first_stage == "Stage_12_Overflow" and self._difficulty_key() in ("standard", "moderate"):
            item = "Move_N4_DoubleJump"
            self._knd_cached_starting_bonus_item = item
            return item

        op_item = self.STAGE_TO_OPERATIVE[first_stage]
        item = self.OPERATIVE_TO_MONKEY_CAPPER.get(op_item)
        self._knd_cached_starting_bonus_item = item
        return item

    def _grant_starting_slots(self) -> None:
        """
        Grants starting Stage unlock(s) + required operative(s) so the player is never softlocked.
        Excludes canon-chain stages 7, 10, 11 and final stage 14 from being starting picks.

        Also grants one starting bonus item. Normally this is the first starting
        operative's Rainbow Monkey Capper. If the first starting stage is
        Stage 3 / Boogification, this is an N5 movement upgrade instead.
        """
        chosen = self._get_starting_stages()

        pushed = set()
        for stage in chosen:
            unlock_item = self.STAGE_TO_UNLOCK_ITEM[stage]
            op_item = self.STAGE_TO_OPERATIVE[stage]

            for item_name in (unlock_item, op_item):
                if item_name not in pushed:
                    self.multiworld.push_precollected(make_item(item_name, self.player))
                    pushed.add(item_name)

        starting_bonus = self._starting_bonus_pool_skip()
        if starting_bonus:
            self.multiworld.push_precollected(make_item(starting_bonus, self.player))
